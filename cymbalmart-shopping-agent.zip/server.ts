import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Lazy Gemini client helper
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// Health check endpoint
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    hasApiKey: !!process.env.GEMINI_API_KEY,
    time: new Date().toISOString(),
  });
});

// Endpoint: Generate Full Party Shopping Plan
app.post("/api/agent/generate-plan", async (req, res) => {
  try {
    const {
      name,
      eventType,
      theme,
      vibe,
      adults = 10,
      kids = 0,
      durationHours = 3,
      budgetLimit = 250,
      venueType = "indoor-home",
      dietaryRestrictions = [],
      customNotes = "",
      servingStyle = "buffet", // buffet, sit-down, finger-foods-only, bar-snacks
    } = req.body;

    const numAdults = Number(adults);
    const numKids = Number(kids);
    const totalGuests = numAdults + numKids;
    const isOutdoor = ["backyard", "park-outdoor", "beach", "rooftop"].includes(venueType) || (eventType || "").toLowerCase().includes("outdoor") || (eventType || "").toLowerCase().includes("bbq") || (eventType || "").toLowerCase().includes("picnic");
    const isCorporate = (eventType || "").toLowerCase().includes("corporate") || (eventType || "").toLowerCase().includes("office") || (eventType || "").toLowerCase().includes("team") || (eventType || "").toLowerCase().includes("networking") || vibe === "corporate-professional" || venueType === "office-corporate";
    const hasKids = numKids > 0 || (eventType || "").toLowerCase().includes("kids") || vibe === "family-friendly";

    const ai = getGeminiClient();

    const prompt = `You are the CymbalMart Shopping Agent, an expert Party Planner & Shopping Logistics AI. Create a comprehensive, realistic, and highly organized party plan and shopping list for this event:

Event Specifications:
- Event Name: ${name || "Party Celebration"}
- Event Type: ${eventType || "Casual Gathering"}
- Theme & Decor: ${theme || "Classic Social"}
- Atmosphere/Vibe: ${vibe || "festive"}
- Guest Count: ${numAdults} Adults, ${numKids} Kids (Total: ${totalGuests} guests)
- Party Duration: ${durationHours} hours
- Venue Style: ${venueType} (Is Outdoor: ${isOutdoor})
- Target Budget: $${budgetLimit} USD
- Dietary Restrictions / Allergies to cater for: ${dietaryRestrictions.length ? dietaryRestrictions.join(", ") : "None specified"}
- Serving Style: ${servingStyle}
- Special Notes / Host Requests: ${customNotes || "None"}

CRITICAL PLANNING & VERIFICATION MANDATES:
1. AGE-APPROPRIATENESS & QUANTITY VERIFICATION:
${hasKids ? `- This event includes ${numKids} children. You MUST include kid-appropriate foods (finger foods, fruit skewers, mini pizza bagels/sliders, mac & cheese cups, nut-free snacks) and non-alcoholic beverages (100% organic juice pouches/boxes: 2-3 per child, water boxes, lemonade). Tableware must include kid-safe cups and colorful napkins. If adults=0, ZERO alcohol. If adults>0, scale alcoholic beverages strictly for the ${numAdults} adults only.` : `- Adult-only event (${numAdults} adults). Include sophisticated appetizers, curated wine/craft beer/cocktail mixers, and adult portions.`}

2. CORPORATE-APPROPRIATENESS & REALISTIC BUDGET ESTIMATES:
${isCorporate ? `- This is a corporate / office / networking event. You MUST include corporate-appropriate items: artisan grab-and-go sandwich & wrap platters (turkey havarti, roast beef, caprese), gourmet cheese/charcuterie skewers, fresh seasonal fruit platters, a complete premium coffee & tea station (coffee traveler carafes, assorted herbal/black teas, oat milk & dairy creamers, raw sugars/sweeteners, wooden stir sticks, hot cups with sleeves), sparkling water (San Pellegrino / LaCroix), upscale compostable bamboo/palm plates, linen-feel napkins, and badge lanyards/name tents. Provide realistic corporate budget estimates ($20-$45/person).` : `- Non-corporate social event. Focus on theme-matched social catering.`}

3. OUTDOOR-SPECIFIC ITEMS (WEATHER PROTECTION & OUTDOOR SEATING):
${isOutdoor ? `- This is an OUTDOOR event (${venueType}). You MUST include outdoor weather protection items in the shopping list (10x10 ft pop-up shade canopy tent, canopy sandbag leg weights/stakes to prevent wind blowaway, heavy-duty windproof tablecloth clamps, pop-up mesh food fly covers to protect buffet food from flies/bees, citronella insect repellent torches/spray, and broad-spectrum SPF 50 sunscreen dispenser) AND outdoor seating & comfort (heavy-duty portable folding lawn chairs, waterproof picnic blankets, heavy-duty rolling cooler with drain plug, +25-30% extra party ice buffer for outdoor sun melting, and 30-55 gal outdoor lawn trash bags). Categorize these under 'outdoor-gear' or 'ice-coolers-cleaning'.` : `- Indoor venue. Weather protection and outdoor lawn seating not required.`}

Please calculate realistic food & drink portion formulas:
- Appetizers: typically 4-6 pieces per guest for cocktail/buffet or 8-10 if heavy.
- Main course proteins: approx 0.5 - 0.75 lb per adult; 0.3 - 0.5 lb per kid.
- Drinks: 1-2 drinks per adult per hour; 1 drink/juice box per kid per hour.
- Ice: 1.2 to 1.5 lbs of ice per guest indoors, or 1.8 to 2.0 lbs per guest outdoors for chilling + ice buckets.
- Tableware: 1.5 plates and cups per guest + generous napkins (3-4 per guest).

Output a structured JSON response following this exact format:
{
  "name": "${name || theme + ' Party'}",
  "theme": "${theme}",
  "eventType": "${eventType}",
  "vibe": "${vibe}",
  "guestCount": { "adults": ${numAdults}, "kids": ${numKids}, "total": ${totalGuests} },
  "durationHours": ${durationHours},
  "budgetLimit": ${budgetLimit},
  "venueType": "${venueType}",
  "dietaryRestrictions": ${JSON.stringify(dietaryRestrictions)},
  "customNotes": "${customNotes}",
  "portionsBreakdown": {
    "appetizersTotalPieces": number,
    "appetizersPerPerson": number,
    "mainCourseServings": number,
    "sidesTotalLbsOrServings": number,
    "alcoholicDrinksCount": number,
    "nonAlcoholicDrinksCount": number,
    "iceLbsNeeded": number,
    "dessertServings": number,
    "cupsPlatesNapkinsCount": number,
    "calculationExplanation": "Detailed explanation of formulas used for ${totalGuests} guests over ${durationHours} hours"
  },
  "menuHighlights": [
    {
      "course": "Appetizer" | "Main" | "Side" | "Dessert" | "Signature Drink",
      "dishName": string,
      "description": string,
      "dietaryTags": ["Vegetarian", etc]
    }
  ],
  "items": [
    {
      "id": string (unique like item-1, item-2),
      "name": string,
      "category": "produce" | "meat-seafood" | "bakery" | "dairy-chilled" | "pantry-dry" | "beverages-alcohol" | "beverages-soft" | "snacks-sweets" | "tableware-supplies" | "decor-lighting" | "ice-coolers-cleaning" | "outdoor-gear" | "activities-favors",
      "quantity": number,
      "unit": string (e.g. "lbs", "bottles", "packs", "boxes", "bags", "cans", "items", "tents", "chairs"),
      "estimatedPriceMin": number,
      "estimatedPriceMax": number,
      "storeType": "Supermarket / Grocery" | "Wholesale Club (Costco/Sam's)" | "Liquor & Wine Store" | "Party & Craft Store" | "Dollar Store / Discount" | "Bakery / Specialty" | "Outdoor / Hardware Store",
      "dietaryTags": string[],
      "isPerishable": boolean,
      "priority": "must-have" | "recommended" | "optional-upgrade",
      "checked": false,
      "notesOrBrand": string,
      "substitutionAdvice": string
    }
  ],
  "budgetAnalysis": {
    "totalEstimatedCostMin": number,
    "totalEstimatedCostMax": number,
    "costPerGuest": number,
    "budgetStatus": "under" | "on-target" | "over",
    "savingsTips": [string, string, string],
    "categoryDistribution": {
      "produce": number,
      "meat-seafood": number,
      "bakery": number,
      "dairy-chilled": number,
      "pantry-dry": number,
      "beverages-alcohol": number,
      "beverages-soft": number,
      "snacks-sweets": number,
      "tableware-supplies": number,
      "decor-lighting": number,
      "ice-coolers-cleaning": number,
      "outdoor-gear": number,
      "activities-favors": number
    }
  },
  "storeRoutes": [
    {
      "storeType": string,
      "recommendedStoreName": string,
      "itemCount": number,
      "estimatedCost": number,
      "keyAisles": [string],
      "proTip": string
    }
  ],
  "timeline": [
    {
      "timeframe": "1 Week Before" | "2-3 Days Before" | "1 Day Before" | "Day of Party (Morning)" | "2 Hours Before",
      "title": string,
      "tasks": [string]
    }
  ]
}`;

    if (!ai) {
      // Fallback deterministic party generator if no key provided
      const fallbackPlan = generateFallbackPlan({
        name,
        eventType,
        theme,
        vibe,
        adults: numAdults,
        kids: numKids,
        durationHours,
        budgetLimit,
        venueType,
        dietaryRestrictions,
        customNotes,
      });
      return res.json(fallbackPlan);
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        systemInstruction:
          "You are the world's best Party Planner & Shopping Logistics Agent. You calculate exact culinary, beverage, and party supply quantities without under-buying or wasting budget. Always ensure dietary requirements, age appropriateness, corporate standards, and outdoor weather protections are strictly verified and included. Output strictly valid JSON.",
      },
    });

    const text = response.text || "{}";
    const parsed = JSON.parse(text);
    return res.json(parsed);
  } catch (error) {
    console.error("Error in /api/agent/generate-plan:", error);
    // Fallback on error so the user never gets a broken UI
    const fallbackPlan = generateFallbackPlan(req.body);
    return res.json(fallbackPlan);
  }
});

// Endpoint: Agent Chat Assistant (Conversational Customer Concierge & List Editor)
app.post("/api/agent/chat", async (req, res) => {
  try {
    const { message, currentPlan, chatHistory = [] } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.json({
        reply: `Hi there! I am your CymbalMart Assistant. I received your request: "${message}". To unlock live portion formulas, AI aisle mapping, and automatic shopping list edits, ensure your Gemini API key is configured. You can also customize your items and budget directly in the CymbalMart dashboard!`,
        action: null,
      });
    }

    const adults = currentPlan?.guestCount?.adults || 10;
    const kids = currentPlan?.guestCount?.kids || 0;
    const venue = currentPlan?.venueType || "indoor-home";
    const eventType = currentPlan?.eventType || "Party";
    const isOutdoor = ["backyard", "park-outdoor", "beach", "rooftop"].includes(venue) || (eventType || "").toLowerCase().includes("outdoor") || (eventType || "").toLowerCase().includes("bbq") || (eventType || "").toLowerCase().includes("picnic");
    const isCorporate = (eventType || "").toLowerCase().includes("corporate") || (eventType || "").toLowerCase().includes("office") || (eventType || "").toLowerCase().includes("team") || (eventType || "").toLowerCase().includes("networking");

    const prompt = `You are the CymbalMart Assistant, an intelligent, friendly, and expert customer service and party shopping AI assistant for CymbalMart. You interact with customers to help them plan parties, verify shopping lists, update grocery items, calculate accurate portions (food, drinks, ice, tableware), accommodate dietary needs (vegan, gluten-free, nut allergies, halal, kosher), find budget-friendly swaps, and dynamically manage their shopping list.

Current Customer Party & Shopping Plan:
- Event Name: ${currentPlan?.name || "My Party"}
- Event Type: ${eventType}
- Theme & Style: ${currentPlan?.theme || "General"}
- Venue Style: ${venue} (Outdoor: ${isOutdoor})
- Headcount: ${adults} Adults, ${kids} Kids (${currentPlan?.guestCount?.total || adults + kids} total guests)
- Budget Ceiling: $${currentPlan?.budgetLimit || 250}
- Current Estimated Cost: $${currentPlan?.budgetAnalysis?.totalEstimatedCostMin || 150} - $${currentPlan?.budgetAnalysis?.totalEstimatedCostMax || 220}
- Current Items in List: ${currentPlan?.items?.length || 0} items (${currentPlan?.items?.map((i: any) => `${i.name} (${i.quantity} ${i.unit})`).slice(0, 15).join(", ")})

VERIFICATION & LIST UPDATE CAPABILITIES:
1. AGE-APPROPRIATENESS:
   - When asked to verify age appropriateness or when reviewing items for events with kids (${kids} kids): verify that child-safe foods (pizza bagels, sliders, fruit skewers, nut-free snacks), 100% juice boxes/pouches (2-3 per child), child-safe cups, and favors/activities are present. If alcohol is present, ensure it is scaled only to the ${adults} adults and that kid-only parties have zero alcohol.
2. CORPORATE-APPROPRIATENESS & REALISTIC BUDGET:
   - When asked to verify corporate suitability or for corporate/office events (${isCorporate ? "YES" : "NO"}): verify artisan grab-and-go sandwich/wrap platters, cheese/charcuterie skewers, fruit platters, complete coffee & tea bar (coffee box traveler, assorted teas, oat milk & creamers, sugars, stirrers, cups), sparkling water, compostable bamboo/palm plates, napkins, and name tags/tents. Confirm realistic corporate budget ($20-$45/guest).
3. OUTDOOR READINESS (WEATHER PROTECTION & SEATING):
   - When asked to verify outdoor items or for outdoor events (${isOutdoor ? "YES" : "NO"}): verify pop-up shade canopy tent (10x10 ft), canopy leg sandbag weights/stakes (to prevent wind blowaway), heavy-duty windproof tablecloth clamps, pop-up mesh food fly covers (protecting food from flies/bees), citronella insect repellent, SPF 50 sunscreen, folding lawn chairs, picnic blankets, outdoor cooler with drain plug, and +25-30% extra ice buffer for outdoor heat.
4. DYNAMIC SHOPPING LIST UPDATES:
   - When the customer asks you to add, remove, swap, or update items, or when verification reveals missing essential items, emit the appropriate "action" object (e.g. "type": "add_items") with all required item fields so the CymbalMart shopping list and budget totals update instantly.

Customer's Message: "${message}"

Respond in a helpful, warm, professional customer-assistant voice with a structured JSON object:
{
  "reply": "Friendly, conversational, concise answer addressing customer questions, providing suggestions, verification findings, portion calculations, or party advice.",
  "action": null | {
    "type": "add_items" | "remove_items" | "modify_item" | "update_budget" | "update_guests" | "swap_items",
    "description": "Short explanation of list modification for the customer",
    "itemsToAdd": [
      {
        "id": "new-${Date.now()}-1",
        "name": string,
        "category": "produce" | "meat-seafood" | "bakery" | "dairy-chilled" | "pantry-dry" | "beverages-alcohol" | "beverages-soft" | "snacks-sweets" | "tableware-supplies" | "decor-lighting" | "ice-coolers-cleaning" | "outdoor-gear" | "activities-favors",
        "quantity": number,
        "unit": string,
        "estimatedPriceMin": number,
        "estimatedPriceMax": number,
        "storeType": string,
        "dietaryTags": string[],
        "isPerishable": boolean,
        "priority": "must-have" | "recommended" | "optional-upgrade",
        "checked": false,
        "notesOrBrand": string,
        "substitutionAdvice": string
      }
    ],
    "itemIdsToRemove": string[],
    "itemModifications": [
      {
        "id": string,
        "quantity": number,
        "notesOrBrand": string
      }
    ],
    "newBudgetLimit": number (optional),
    "newGuestCount": { "adults": number, "kids": number } (optional)
  },
  "suggestedFollowUps": ["Customer suggestion 1", "Customer suggestion 2", "Customer suggestion 3"]
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        systemInstruction:
          "You are the CymbalMart Assistant. You provide world-class, cheerful customer service for grocery and party shopping. You answer questions directly, recommend items from CymbalMart aisles, calculate portion sizes, suggest recipes or drinks, perform list verifications (age-appropriate, corporate standards, outdoor shelter/seating), and execute list updates when requested. Always output valid JSON.",
      },
    });

    const parsed = JSON.parse(response.text || "{}");
    return res.json(parsed);
  } catch (error) {
    console.error("Error in /api/agent/chat:", error);
    return res.json({
      reply: "I had a momentary hitch analyzing that request. As your CymbalMart Assistant, how can I help you verify your shopping list, calculate drinks and ice, or find product alternatives?",
      action: null,
      suggestedFollowUps: ["Verify age-appropriate items", "Verify outdoor weather & seating", "Verify corporate budget estimates"],
    });
  }
});

// Endpoint: Smart Item Suggestion / Price Estimator
app.post("/api/agent/suggest-item", async (req, res) => {
  try {
    const { query, partyTheme, guestCount = 12 } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.json({
        name: query,
        category: "snacks-sweets",
        quantity: 2,
        unit: "packs",
        estimatedPriceMin: 5,
        estimatedPriceMax: 10,
        storeType: "Supermarket / Grocery",
        dietaryTags: [],
        isPerishable: false,
        priority: "recommended",
      });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: `Suggest shopping details for adding "${query}" to a party with ${guestCount} guests (Theme: ${partyTheme || "Party"}).
Return JSON:
{
  "name": string,
  "category": "produce" | "meat-seafood" | "bakery" | "dairy-chilled" | "pantry-dry" | "beverages-alcohol" | "beverages-soft" | "snacks-sweets" | "tableware-supplies" | "decor-lighting" | "ice-coolers-cleaning" | "activities-favors",
  "quantity": number,
  "unit": string (e.g. "lbs", "packs", "bottles", "bags", "boxes"),
  "estimatedPriceMin": number,
  "estimatedPriceMax": number,
  "storeType": "Supermarket / Grocery" | "Wholesale Club (Costco/Sam's)" | "Liquor & Wine Store" | "Party & Craft Store" | "Dollar Store / Discount" | "Bakery / Specialty",
  "dietaryTags": string[],
  "isPerishable": boolean,
  "priority": "must-have" | "recommended" | "optional-upgrade",
  "notesOrBrand": string,
  "substitutionAdvice": string
}`,
      config: { responseMimeType: "application/json" },
    });

    return res.json(JSON.parse(response.text || "{}"));
  } catch (error) {
    return res.json({
      name: req.body.query,
      category: "pantry-dry",
      quantity: 1,
      unit: "pack",
      estimatedPriceMin: 4,
      estimatedPriceMax: 8,
      storeType: "Supermarket / Grocery",
      dietaryTags: [],
      isPerishable: false,
      priority: "recommended",
    });
  }
});

// Fallback Plan Generator
function generateFallbackPlan(params: any) {
  const adults = Number(params.adults || 12);
  const kids = Number(params.kids || 0);
  const totalGuests = adults + kids;
  const duration = Number(params.durationHours || 3);
  const budget = Number(params.budgetLimit || 250);
  const eventName = params.name || `${params.theme || "Celebration"} Bash`;
  const theme = params.theme || "Casual Celebration";
  const venueType = params.venueType || "indoor-home";
  const eventType = params.eventType || "Social Gathering";
  const vibe = params.vibe || "festive";

  const isOutdoor = ["backyard", "park-outdoor", "beach", "rooftop"].includes(venueType) || eventType.toLowerCase().includes("outdoor") || eventType.toLowerCase().includes("bbq") || eventType.toLowerCase().includes("picnic");
  const isCorporate = eventType.toLowerCase().includes("corporate") || eventType.toLowerCase().includes("office") || eventType.toLowerCase().includes("team") || eventType.toLowerCase().includes("networking") || vibe === "corporate-professional" || venueType === "office-corporate";
  const hasKids = kids > 0 || eventType.toLowerCase().includes("kids") || vibe === "family-friendly";

  const appetizersPieces = totalGuests * 5;
  const drinksCount = adults * duration * 1.5 + kids * duration;
  const iceLbs = Math.round(totalGuests * (isOutdoor ? 1.8 : 1.2));
  const platesCups = Math.round(totalGuests * 1.5);

  const items: any[] = [];
  let itemIdCounter = 1;

  if (isCorporate) {
    items.push({
      id: `item-${itemIdCounter++}`,
      name: "Artisan Grab-and-Go Wrap & Sandwich Platter (Turkey, Roast Beef, Caprese)",
      category: "bakery",
      quantity: Math.max(2, Math.ceil(totalGuests / 6)),
      unit: "large platters (24 halves)",
      estimatedPriceMin: 35,
      estimatedPriceMax: 50,
      storeType: "Bakery / Specialty",
      dietaryTags: ["Vegetarian Option"],
      isPerishable: true,
      priority: "must-have",
      checked: false,
      notesOrBrand: "Individually wrapped halves labeled with dietary stickers",
      substitutionAdvice: "Gourmet mini slider box",
    });
    items.push({
      id: `item-${itemIdCounter++}`,
      name: "Artisan Coffee Box Traveler & Gourmet Tea Bar with Creamers & Sugars",
      category: "beverages-soft",
      quantity: Math.max(1, Math.ceil(totalGuests / 10)),
      unit: "traveler boxes (96 oz each)",
      estimatedPriceMin: 20,
      estimatedPriceMax: 30,
      storeType: "Bakery / Specialty",
      dietaryTags: ["Vegan", "Gluten-Free"],
      isPerishable: false,
      priority: "must-have",
      checked: false,
      notesOrBrand: "Includes dairy whole milk, oat milk creamer, raw sugar, stevia, wooden stirrers & insulated hot cups",
      substitutionAdvice: "Cold brew growlers and iced tea dispenser",
    });
    items.push({
      id: `item-${itemIdCounter++}`,
      name: "San Pellegrino & Flavored Sparkling Waters",
      category: "beverages-soft",
      quantity: 2,
      unit: "12-packs (24 cans)",
      estimatedPriceMin: 14,
      estimatedPriceMax: 20,
      storeType: "Supermarket / Grocery",
      dietaryTags: ["Vegan", "Gluten-Free"],
      isPerishable: false,
      priority: "must-have",
      checked: false,
      notesOrBrand: "Assorted lemon, blood orange, and grapefruit",
      substitutionAdvice: "Large mineral water bottles with sliced fresh citrus",
    });
    items.push({
      id: `item-${itemIdCounter++}`,
      name: "Upscale Compostable Palm Leaf Plates & Linen-Feel Napkins",
      category: "tableware-supplies",
      quantity: 1,
      unit: "executive pack (50 ct)",
      estimatedPriceMin: 16,
      estimatedPriceMax: 24,
      storeType: "Party & Craft Store",
      dietaryTags: [],
      isPerishable: false,
      priority: "must-have",
      checked: false,
      notesOrBrand: "Heavy-duty compostable plates and pre-rolled cutlery kits",
      substitutionAdvice: "Heavyweight recycled paper plates",
    });
  } else {
    items.push({
      id: `item-${itemIdCounter++}`,
      name: "Brioche Slider Buns",
      category: "bakery",
      quantity: 2,
      unit: "packs (24 total)",
      estimatedPriceMin: 8,
      estimatedPriceMax: 12,
      storeType: "Supermarket / Grocery",
      dietaryTags: ["Vegetarian"],
      isPerishable: false,
      priority: "must-have",
      checked: false,
      notesOrBrand: "King's Hawaiian or Brioche brand",
      substitutionAdvice: "Standard mini potato rolls",
    });
    items.push({
      id: `item-${itemIdCounter++}`,
      name: "Lean Ground Beef / Turkey / Veggie Patties",
      category: "meat-seafood",
      quantity: Math.max(3, Math.round(totalGuests * 0.3)),
      unit: "lbs",
      estimatedPriceMin: 18,
      estimatedPriceMax: 26,
      storeType: "Supermarket / Grocery",
      dietaryTags: [],
      isPerishable: true,
      priority: "must-have",
      checked: false,
      notesOrBrand: "80/20 ground chuck or pre-formed sliders",
      substitutionAdvice: "Portobello mushroom caps or Impossible meat",
    });
  }

  // Kid-specific items if kids are present
  if (hasKids) {
    items.push({
      id: `item-${itemIdCounter++}`,
      name: "Organic 100% Juice Pouches (Apple & Berry Blend)",
      category: "beverages-soft",
      quantity: Math.max(2, Math.ceil((kids * 2.5) / 10)),
      unit: "boxes (20-30 pouches)",
      estimatedPriceMin: 10,
      estimatedPriceMax: 16,
      storeType: "Wholesale Club (Costco/Sam's)",
      dietaryTags: ["Nut-Free", "Vegan", "Gluten-Free"],
      isPerishable: false,
      priority: "must-have",
      checked: false,
      notesOrBrand: "Honest Kids or Capri Sun 100% Juice (2-3 per child)",
      substitutionAdvice: "Large drink dispenser with fruit lemonade",
    });
    items.push({
      id: `item-${itemIdCounter++}`,
      name: "Rainbow Fresh Fruit Skewers / Pre-Cut Fruit Platter",
      category: "produce",
      quantity: 2,
      unit: "party containers (strawberries, grapes, pineapple)",
      estimatedPriceMin: 12,
      estimatedPriceMax: 18,
      storeType: "Supermarket / Grocery",
      dietaryTags: ["Nut-Free", "Vegan", "Gluten-Free"],
      isPerishable: true,
      priority: "must-have",
      checked: false,
      notesOrBrand: "Kid-safe wooden bamboo picks with sweet fruit",
      substitutionAdvice: "Canned mandarin oranges and fruit cups",
    });
    items.push({
      id: `item-${itemIdCounter++}`,
      name: "Certified Nut-Free Birthday Cupcakes / Treats",
      category: "bakery",
      quantity: 2,
      unit: "dozens (24 cupcakes)",
      estimatedPriceMin: 16,
      estimatedPriceMax: 24,
      storeType: "Bakery / Specialty",
      dietaryTags: ["Nut-Free", "Vegetarian"],
      isPerishable: true,
      priority: "must-have",
      checked: false,
      notesOrBrand: "Check allergen label for school/kid safety",
      substitutionAdvice: "Home-baked Funfetti cupcakes with sprinkles",
    });
    items.push({
      id: `item-${itemIdCounter++}`,
      name: "Party Favors & Glow Bracelets Kit (50 ct)",
      category: "activities-favors",
      quantity: 1,
      unit: "pack",
      estimatedPriceMin: 10,
      estimatedPriceMax: 15,
      storeType: "Dollar Store / Discount",
      dietaryTags: [],
      isPerishable: false,
      priority: "recommended",
      checked: false,
      notesOrBrand: "Multi-color connectors for necklaces and bracelets",
      substitutionAdvice: "Bubble bottles and stickers",
    });
  }

  // Outdoor specific items (Weather protection & Outdoor seating)
  if (isOutdoor) {
    items.push({
      id: `item-${itemIdCounter++}`,
      name: "Pop-Up Shade Canopy Shelter Tent (10x10 ft) with Sandbag Leg Weights",
      category: "outdoor-gear",
      quantity: 1,
      unit: "canopy tent set",
      estimatedPriceMin: 45,
      estimatedPriceMax: 75,
      storeType: "Outdoor / Hardware Store",
      dietaryTags: [],
      isPerishable: false,
      priority: "must-have",
      checked: false,
      notesOrBrand: "Instant pop-up with UV 50+ shade protection and 4 wind anchor sandbags",
      substitutionAdvice: "Borrow 10x10 canopy or set up under park pavilion trees",
    });
    items.push({
      id: `item-${itemIdCounter++}`,
      name: "Heavy-Duty Windproof Tablecloth Clamps & Mesh Food Fly Covers",
      category: "tableware-supplies",
      quantity: 1,
      unit: "set (8 clamps + 4 mesh food tents)",
      estimatedPriceMin: 9,
      estimatedPriceMax: 15,
      storeType: "Dollar Store / Discount",
      dietaryTags: [],
      isPerishable: false,
      priority: "must-have",
      checked: false,
      notesOrBrand: "Keeps table covers anchored against gusts and protects buffet from outdoor insects",
      substitutionAdvice: "Foil wrap over platters and heavy stone corner weights",
    });
    items.push({
      id: `item-${itemIdCounter++}`,
      name: "Citronella Insect Repellent Torches & Broad-Spectrum SPF 50 Sunscreen Pump",
      category: "outdoor-gear",
      quantity: 1,
      unit: "combo set",
      estimatedPriceMin: 12,
      estimatedPriceMax: 18,
      storeType: "Supermarket / Grocery",
      dietaryTags: [],
      isPerishable: false,
      priority: "must-have",
      checked: false,
      notesOrBrand: "DEET-free plant-based bug spray plus SPF 50 sunscreen for guest comfort",
      substitutionAdvice: "Citronella candles and personal bug wipes",
    });
    items.push({
      id: `item-${itemIdCounter++}`,
      name: "Heavy-Duty Portable Folding Lawn Chairs & Waterproof Picnic Blankets",
      category: "outdoor-gear",
      quantity: Math.max(2, Math.ceil(totalGuests / 4)),
      unit: "chairs + blanket set",
      estimatedPriceMin: 24,
      estimatedPriceMax: 40,
      storeType: "Outdoor / Hardware Store",
      dietaryTags: [],
      isPerishable: false,
      priority: "recommended",
      checked: false,
      notesOrBrand: "Compact folding chairs with cup holders & fleece waterproof ground mats",
      substitutionAdvice: "Ask guests to BYO lawn chair",
    });
  }

  // Common Party Staples
  items.push({
    id: `item-${itemIdCounter++}`,
    name: "Artisan Cheese Selection (Cheddar, Gouda, Brie)",
    category: "dairy-chilled",
    quantity: 2,
    unit: "blocks/wedges",
    estimatedPriceMin: 12,
    estimatedPriceMax: 18,
    storeType: "Wholesale Club (Costco/Sam's)",
    dietaryTags: ["Vegetarian"],
    isPerishable: true,
    priority: "must-have",
    checked: false,
    notesOrBrand: "Costco cheese sampler platter",
    substitutionAdvice: "Pre-sliced party variety pack",
  });

  items.push({
    id: `item-${itemIdCounter++}`,
    name: `Fresh Party Ice (+${isOutdoor ? "30% Outdoor Heat Buffer" : "Chilling Buffer"})`,
    category: "ice-coolers-cleaning",
    quantity: Math.max(2, Math.ceil(iceLbs / 10)),
    unit: "bags (10 lbs each)",
    estimatedPriceMin: 6,
    estimatedPriceMax: 10,
    storeType: "Supermarket / Grocery",
    dietaryTags: [],
    isPerishable: true,
    priority: "must-have",
    checked: false,
    notesOrBrand: isOutdoor ? "Store in heavy-duty rolling cooler with drain plug closed" : "Buy day of event",
    substitutionAdvice: "Fill freezer trays 3 days prior",
  });

  // Adult alcohol ONLY if adults > 0 and not kids-only
  if (adults > 0 && !eventType.toLowerCase().includes("kids birthday")) {
    items.push({
      id: `item-${itemIdCounter++}`,
      name: "Assorted Craft Beers & Seltzers (for Adults)",
      category: "beverages-alcohol",
      quantity: Math.max(1, Math.round(adults * 0.8)),
      unit: "12-packs",
      estimatedPriceMin: 22,
      estimatedPriceMax: 34,
      storeType: "Liquor & Wine Store",
      dietaryTags: [],
      isPerishable: false,
      priority: "must-have",
      checked: false,
      notesOrBrand: "Mix of IPA, crisp lager, and hard seltzers",
      substitutionAdvice: "Domestic 24-pack for budget saving",
    });
  }

  if (!isCorporate) {
    items.push({
      id: `item-${itemIdCounter++}`,
      name: "Sparkling Water & Artisanal Sodas",
      category: "beverages-soft",
      quantity: 2,
      unit: "12-packs",
      estimatedPriceMin: 10,
      estimatedPriceMax: 16,
      storeType: "Supermarket / Grocery",
      dietaryTags: ["Vegan", "Gluten-Free"],
      isPerishable: false,
      priority: "must-have",
      checked: false,
      notesOrBrand: "LaCroix / Spindrift / Ginger Beer",
      substitutionAdvice: "Store brand club soda + fresh lime juice",
    });

    items.push({
      id: `item-${itemIdCounter++}`,
      name: "Eco-Friendly Party Plates & Cutlery Kit",
      category: "tableware-supplies",
      quantity: 1,
      unit: "combo pack (50 ct)",
      estimatedPriceMin: 12,
      estimatedPriceMax: 18,
      storeType: "Dollar Store / Discount",
      dietaryTags: [],
      isPerishable: false,
      priority: "must-have",
      checked: false,
      notesOrBrand: "Compostable palm leaf or heavy duty paper",
      substitutionAdvice: "Standard dollar store paper plates",
    });
  }

  items.push({
    id: `item-${itemIdCounter++}`,
    name: "Party Cups & Cocktail Napkins",
    category: "tableware-supplies",
    quantity: 1,
    unit: "pack (100 ct)",
    estimatedPriceMin: 7,
    estimatedPriceMax: 11,
    storeType: "Dollar Store / Discount",
    dietaryTags: [],
    isPerishable: false,
    priority: "must-have",
    checked: false,
    notesOrBrand: "Clear 12oz cups + 3-ply napkins",
    substitutionAdvice: "Red solo cups",
  });

  const totalMin = items.reduce((acc, i) => acc + (i.estimatedPriceMin || 0), 0);
  const totalMax = items.reduce((acc, i) => acc + (i.estimatedPriceMax || i.estimatedPriceMin || 0), 0);

  return {
    name: eventName,
    theme: theme,
    eventType: eventType,
    vibe: vibe,
    guestCount: { adults, kids, total: totalGuests },
    durationHours: duration,
    budgetLimit: budget,
    venueType: venueType,
    dietaryRestrictions: params.dietaryRestrictions || [],
    customNotes: params.customNotes || "",
    portionsBreakdown: {
      appetizersTotalPieces: appetizersPieces,
      appetizersPerPerson: 5,
      mainCourseServings: totalGuests,
      sidesTotalLbsOrServings: Math.round(totalGuests * 0.4),
      alcoholicDrinksCount: Math.round(adults * duration * 1.2),
      nonAlcoholicDrinksCount: Math.round(totalGuests * duration * 0.8),
      iceLbsNeeded: iceLbs,
      dessertServings: totalGuests,
      cupsPlatesNapkinsCount: platesCups,
      calculationExplanation: `Verified calculation for ${totalGuests} guests (${adults} adults, ${kids} kids) over ${duration} hours: ~5 appetizer bites per person, 1.2-1.5 drinks/hr, ${iceLbs} lbs of ice (${isOutdoor ? "+30% outdoor heat buffer" : "chilling"}), plus 50% buffer on cups and tableware.`,
    },
    menuHighlights: [
      {
        course: "Appetizer",
        dishName: isCorporate ? "Gourmet Charcuterie & Cheese Skewers" : "Artisanal Charcuterie & Dip Board",
        description: isCorporate ? "Individual skewers of aged cheddar, cured salami, kalamata olives, and fresh rosemary." : "Gourmet cheeses, cured meats, crackers, grapes, and hummus.",
        dietaryTags: ["Vegetarian Option"],
      },
      {
        course: "Main",
        dishName: isCorporate ? "Artisan Wrap & Ciabatta Sandwich Selection" : "Gourmet Slider Trio / Grill Spread",
        description: isCorporate ? "Roast turkey havarti, Italian prosciutto, and grilled caprese vegetarian wraps." : "Tender sliders with brioche buns, melted cheddar, and crisp toppings.",
        dietaryTags: [],
      },
      {
        course: "Signature Drink",
        dishName: isCorporate ? "San Pellegrino Citrus Spritz & Fresh Brewed Coffee" : (hasKids ? "Rainbow Cosmic Fruit Punch & Craft Lemonade" : "Sparkling Citrus Punch"),
        description: isCorporate ? "Premium roast coffee carafe bar with oat milk, plus chilled blood orange sparkling mineral waters." : "Prosecco or ginger ale base with fresh blood oranges, mint, and berries.",
        dietaryTags: ["Vegan", "Gluten-Free"],
      },
      {
        course: "Dessert",
        dishName: hasKids ? "Nut-Free Celebration Cupcakes & Fruit Skewers" : "Mini Dessert Bites & Cupcakes",
        description: "Bite-sized brownies, macarons, and frosted celebration cupcakes.",
        dietaryTags: ["Vegetarian"],
      },
    ],
    items: items,
    budgetAnalysis: {
      totalEstimatedCostMin: totalMin,
      totalEstimatedCostMax: totalMax,
      costPerGuest: Math.round(((totalMin + totalMax) / 2) / Math.max(1, totalGuests)),
      budgetStatus: totalMax <= budget ? "under" : totalMin > budget ? "over" : "on-target",
      savingsTips: [
        "Buy beverages and snacks in bulk at Costco/Wholesale store to save 25-35%.",
        isOutdoor ? "Consider borrowing a 10x10 canopy or lawn chairs from neighbors to save $60+ on outdoor gear." : "Prep slider patties at home rather than pre-packaged gourmet sliders.",
        "Get tableware and napkins from a discount dollar store for identical quality at half the price.",
      ],
      categoryDistribution: {
        produce: 15,
        "meat-seafood": 35,
        bakery: 18,
        "dairy-chilled": 16,
        "pantry-dry": 8,
        "beverages-alcohol": adults > 0 ? 35 : 0,
        "beverages-soft": 20,
        "snacks-sweets": 14,
        "tableware-supplies": 20,
        "decor-lighting": 14,
        "ice-coolers-cleaning": 10,
        "outdoor-gear": isOutdoor ? 45 : 0,
        "activities-favors": hasKids ? 12 : 5,
      },
    },
    storeRoutes: [
      {
        storeType: "Wholesale Club (Costco/Sam's)",
        recommendedStoreName: "Costco / Sam's Club",
        itemCount: 4,
        estimatedCost: Math.round(totalMax * 0.45),
        keyAisles: ["Juice & Beverage Depot", "Refrigerated Cheeses", "Paper Goods", "Snack Aisle"],
        proTip: "Great for bulk juice boxes, cheese samplers, and bulk cups/plates.",
      },
      {
        storeType: "Supermarket / Grocery",
        recommendedStoreName: "Local Supermarket / Trader Joe's",
        itemCount: 4,
        estimatedCost: Math.round(totalMax * 0.35),
        keyAisles: ["Bakery", "Meat Counter", "Produce", "Frozen/Ice"],
        proTip: "Pick up fresh buns, proteins, and produce 24-48 hours before.",
      },
      {
        storeType: "Dollar Store / Discount",
        recommendedStoreName: "Dollar Tree / Target Discount",
        itemCount: 2,
        estimatedCost: Math.round(totalMax * 0.12),
        keyAisles: ["Party Supplies", "Disposable Tableware", "Decor"],
        proTip: "Never overpay for solid-color napkins, table runners, or wind clamps.",
      },
    ],
    timeline: [
      {
        timeframe: "1 Week Before",
        title: "Tableware, Gear & Non-Perishables",
        tasks: [
          isOutdoor ? "Inspect pop-up canopy, wind weights, and fold-out lawn chairs." : "Purchase plates, cups, cutlery, napkins, and decorations.",
          "Inventory coolers, drink dispensers, and serving bowls.",
          "Finalize RSVP headcounts and any dietary restrictions.",
        ],
      },
      {
        timeframe: "2-3 Days Before",
        title: "Beverages & Dry Goods",
        tasks: [
          "Buy beer, wine, seltzers, juice boxes, sodas, and cocktail mixers.",
          "Purchase dry snacks, chips, canned goods, and condiments.",
          "Test audio/playlist and check indoor/outdoor lighting.",
        ],
      },
      {
        timeframe: "1 Day Before",
        title: "Fresh Groceries & Meal Prep",
        tasks: [
          "Buy fresh meats, bakery buns, cheeses, and produce.",
          "Marinate proteins or prepare pasta salad and dips in advance.",
          "Pre-chill all beverages in refrigerators or coolers.",
        ],
      },
      {
        timeframe: "Day of Party (Morning)",
        title: "Ice, Setup & Fresh Items",
        tasks: [
          isOutdoor ? "Erect pop-up canopy shelter and secure with sandbag weights." : "Set up buffet stations, tableware, and trash/recycling bins.",
          "Pick up fresh ice bags and fill drink coolers (+30% buffer).",
          "Slice garnishes (lemons, limes) and set out chips/dips.",
        ],
      },
      {
        timeframe: "2 Hours Before",
        title: "Final Polish & Atmosphere",
        tasks: [
          "Fire up the grill or warm food in chafing dishes / platters.",
          "Start the party playlist at a pleasant ambient volume.",
          "Light candles or citronella torches, and greet early arrivals with a drink!",
        ],
      },
    ],
  };
}

// Start Server & Vite Integration
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`CymbalMart Shopping Agent running on http://localhost:${PORT}`);
  });
}

startServer();
