export type EventType =
  | "Birthday Party"
  | "BBQ & Cookout"
  | "Cocktail & Mixer"
  | "Dinner Party"
  | "Kids Birthday"
  | "Kids Birthday Party"
  | "Corporate & Office Mixer"
  | "Team Offsite & Networking"
  | "Outdoor Picnic & Cookout"
  | "Game Night & Snacks"
  | "Taco & Margarita Fiesta"
  | "Brunch & Mimosas"
  | "Holiday / Seasonal"
  | "Graduation / Milestone"
  | "Baby / Bridal Shower"
  | "Family Gathering"
  | "Casual Hangout";

export type PartyVibe =
  | "casual"
  | "festive"
  | "chic-upscale"
  | "family-friendly"
  | "budget-saver"
  | "themed-immersive"
  | "corporate-professional";

export type VenueType =
  | "indoor-home"
  | "backyard"
  | "park-outdoor"
  | "rented-venue"
  | "rooftop"
  | "beach"
  | "office-corporate";

export type ItemCategory =
  | "produce"
  | "meat-seafood"
  | "bakery"
  | "dairy-chilled"
  | "pantry-dry"
  | "beverages-alcohol"
  | "beverages-soft"
  | "snacks-sweets"
  | "tableware-supplies"
  | "decor-lighting"
  | "ice-coolers-cleaning"
  | "outdoor-gear"
  | "activities-favors";

export type StoreType =
  | "Supermarket / Grocery"
  | "Wholesale Club (Costco/Sam's)"
  | "Liquor & Wine Store"
  | "Party & Craft Store"
  | "Dollar Store / Discount"
  | "Bakery / Specialty"
  | "Outdoor / Hardware Store";

export type ItemPriority = "must-have" | "recommended" | "optional-upgrade";

export interface ShoppingItem {
  id: string;
  name: string;
  category: ItemCategory;
  quantity: number;
  unit: string;
  estimatedPriceMin: number;
  estimatedPriceMax: number;
  storeType: StoreType;
  dietaryTags: string[];
  isPerishable: boolean;
  priority: ItemPriority;
  checked: boolean;
  purchasedPrice?: number;
  notesOrBrand?: string;
  substitutionAdvice?: string;
}

export interface PortionsBreakdown {
  appetizersTotalPieces: number;
  appetizersPerPerson: number;
  mainCourseServings: number;
  sidesTotalLbsOrServings: number;
  alcoholicDrinksCount: number;
  nonAlcoholicDrinksCount: number;
  iceLbsNeeded: number;
  dessertServings: number;
  cupsPlatesNapkinsCount: number;
  calculationExplanation: string;
}

export interface MenuHighlight {
  course: string;
  dishName: string;
  description: string;
  dietaryTags: string[];
}

export interface BudgetAnalysis {
  totalEstimatedCostMin: number;
  totalEstimatedCostMax: number;
  costPerGuest: number;
  budgetStatus: "under" | "on-target" | "over";
  savingsTips: string[];
  categoryDistribution: Record<string, number>;
}

export interface StoreRoute {
  storeType: string;
  recommendedStoreName: string;
  itemCount: number;
  estimatedCost: number;
  keyAisles: string[];
  proTip: string;
}

export interface TimelineStep {
  timeframe: string;
  title: string;
  tasks: string[];
}

export interface PartyPlan {
  id: string;
  name: string;
  theme: string;
  eventType: EventType | string;
  vibe: PartyVibe;
  guestCount: {
    adults: number;
    kids: number;
    total: number;
  };
  durationHours: number;
  budgetLimit: number;
  venueType: VenueType;
  dietaryRestrictions: string[];
  customNotes?: string;
  eventDate?: string;
  hostSecurityPin?: string;
  guestAccessCode?: string;
  memories?: PartyMemory[];
  createdAt: string;
  portionsBreakdown: PortionsBreakdown;
  menuHighlights: MenuHighlight[];
  items: ShoppingItem[];
  budgetAnalysis: BudgetAnalysis;
  storeRoutes: StoreRoute[];
  timeline: TimelineStep[];
}

export interface PartyMemory {
  id: string;
  authorName: string;
  role: "host" | "guest";
  imageUrl?: string;
  note: string;
  category?: "photo" | "toast" | "highlight" | "memory";
  timestamp: string;
  likes: number;
}

export interface ScratchReward {
  id: string;
  title: string;
  badge: string;
  provider: "CymbalMart" | "Flipkart" | "CymbalPlus" | "BakeryVault" | "WholesaleClub";
  headline: string;
  discountDescription: string;
  promoCode: string;
  expiryDate: string;
  isScratched: boolean;
  terms: string;
  iconType: "percent" | "gift" | "crown" | "cake" | "truck";
  colorTheme: string;
}

export interface AgentMessage {
  id: string;
  sender: "user" | "agent";
  timestamp: string;
  text: string;
  agentActions?: {
    type: "portion_calc" | "store_optimization" | "substitutions" | "list_updated" | "item_added" | "budget_cut";
    title: string;
    details?: string;
  }[];
  suggestedFollowUps?: string[];
}

export interface FilterState {
  searchQuery: string;
  category: ItemCategory | "all";
  storeType: StoreType | "all";
  dietaryTag: string | "all";
  priority: ItemPriority | "all";
  status: "all" | "pending" | "completed";
}
