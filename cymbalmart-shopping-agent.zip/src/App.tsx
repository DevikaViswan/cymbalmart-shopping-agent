import React, { useState, useEffect } from "react";
import {
  Sparkles,
  ShoppingBag,
  Calculator,
  PieChart,
  Clock,
  UtensilsCrossed,
  Bot,
  Plus,
  ArrowRight,
  SlidersHorizontal,
  Share2,
  RefreshCw,
  Mic,
  QrCode,
  Gift,
  Flame,
} from "lucide-react";
import { PartyPlan, ShoppingItem, AgentMessage, PartyMemory } from "./types";
import { PRESET_PARTY_PLANS } from "./data/presets";
import { Header } from "./components/Header";
import { PartySetupModal } from "./components/PartySetupModal";
import { ShoppingListView } from "./components/ShoppingListView";
import { PortionEstimatorCard } from "./components/PortionEstimatorCard";
import { BudgetAndStoreOptimizer } from "./components/BudgetAndStoreOptimizer";
import { TimelineView } from "./components/TimelineView";
import { MenuHighlightsCard } from "./components/MenuHighlightsCard";
import { AgentChatDrawer } from "./components/AgentChatDrawer";
import { MobileShoppingMode } from "./components/MobileShoppingMode";
import { VoiceAssistantModal } from "./components/VoiceAssistantModal";
import { CountdownCard } from "./components/CountdownCard";
import { MemoryShareModal } from "./components/MemoryShareModal";
import { ScratchGiftsModal } from "./components/ScratchGiftsModal";
import { recalculatePortions, calculateBudgetAnalysis } from "./utils/portionCalculator";
import { formatPlanAsText, exportPlanAsCSV } from "./utils/exportUtils";

const STORAGE_KEY_PLANS = "party_planner_plans_v1";
const STORAGE_KEY_ACTIVE_ID = "party_planner_active_id_v1";

type ActiveTab = "list" | "portions" | "budget" | "timeline" | "menu" | "countdown";

export default function App() {
  // Load saved plans or default to preset
  const [plans, setPlans] = useState<PartyPlan[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_PLANS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn("Could not load saved plans:", e);
    }
    return PRESET_PARTY_PLANS;
  });

  const [activePlanId, setActivePlanId] = useState<string>(() => {
    try {
      const savedId = localStorage.getItem(STORAGE_KEY_ACTIVE_ID);
      if (savedId) return savedId;
    } catch (e) {}
    return PRESET_PARTY_PLANS[0].id;
  });

  const [activeTab, setActiveTab] = useState<ActiveTab>("list");
  const [isSetupOpen, setIsSetupOpen] = useState(false);
  const [isAgentOpen, setIsAgentOpen] = useState(false);
  const [isMobileModeOpen, setIsMobileModeOpen] = useState(false);
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [isMemoryModalOpen, setIsMemoryModalOpen] = useState(false);
  const [isScratchGiftsOpen, setIsScratchGiftsOpen] = useState(false);
  const [agentPresetPrompt, setAgentPresetPrompt] = useState<string | undefined>(undefined);

  // Chat agent message history per session
  const [messages, setMessages] = useState<AgentMessage[]>([
    {
      id: "msg-welcome",
      sender: "agent",
      timestamp: new Date().toISOString(),
      text: "👋 Hello! I'm your CymbalMart Assistant. I'm here to help you shop, calculate food & drink portions, adjust budgets, find ingredients, or answer any customer questions for your event. How can I assist you today?",
      suggestedFollowUps: [
        "How much ice & beer do I need?",
        "Suggest budget-friendly party food",
        "Find dairy-free & vegan alternatives",
        "Help me trim $30 from this budget",
      ],
    },
  ]);
  const [isThinking, setIsThinking] = useState(false);

  // Active plan reference
  const currentPlan = plans.find((p) => p.id === activePlanId) || plans[0] || PRESET_PARTY_PLANS[0];

  // Save to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_PLANS, JSON.stringify(plans));
      localStorage.setItem(STORAGE_KEY_ACTIVE_ID, activePlanId);
    } catch (e) {
      console.warn("Failed to persist plans:", e);
    }
  }, [plans, activePlanId]);

  // Update helper for active plan
  const updateCurrentPlan = (updater: (prev: PartyPlan) => PartyPlan) => {
    setPlans((prevPlans) =>
      prevPlans.map((p) => {
        if (p.id === currentPlan.id) {
          const updated = updater(p);
          // Recalculate budget analysis automatically whenever items or plan updates
          const ba = calculateBudgetAnalysis(updated.items, updated.budgetLimit, updated.guestCount.total);
          return {
            ...updated,
            budgetAnalysis: {
              ...updated.budgetAnalysis,
              ...ba,
            },
          };
        }
        return p;
      })
    );
  };

  // Item Handlers
  const handleToggleItem = (id: string) => {
    updateCurrentPlan((p) => ({
      ...p,
      items: p.items.map((item) => (item.id === id ? { ...item, checked: !item.checked } : item)),
    }));
  };

  const handleDeleteItem = (id: string) => {
    updateCurrentPlan((p) => ({
      ...p,
      items: p.items.filter((item) => item.id !== id),
    }));
  };

  const handleAddItem = (newItem: ShoppingItem) => {
    updateCurrentPlan((p) => ({
      ...p,
      items: [newItem, ...p.items],
    }));
  };

  const handleUpdateItem = (updatedItem: ShoppingItem) => {
    updateCurrentPlan((p) => ({
      ...p,
      items: p.items.map((i) => (i.id === updatedItem.id ? updatedItem : i)),
    }));
  };

  const handleBulkCheck = (checked: boolean) => {
    updateCurrentPlan((p) => ({
      ...p,
      items: p.items.map((i) => ({ ...i, checked })),
    }));
  };

  const handlePlanGenerated = (newPlan: PartyPlan) => {
    setPlans((prev) => [newPlan, ...prev.filter((p) => p.id !== newPlan.id)]);
    setActivePlanId(newPlan.id);
    setActiveTab("list");

    // Add agent message welcoming the new plan
    setMessages((prev) => [
      ...prev,
      {
        id: `msg-${Date.now()}`,
        sender: "agent",
        timestamp: new Date().toISOString(),
        text: `🎉 Generated new shopping plan for "${newPlan.name}" (${newPlan.guestCount.total} guests, $${newPlan.budgetLimit} budget). I've grouped ${newPlan.items.length} items across ${newPlan.storeRoutes.length} stores!`,
        suggestedFollowUps: [
          "Explain the portion formulas used",
          "What should I buy first this week?",
          "Can we add gluten-free appetizers?",
        ],
      },
    ]);
  };

  const handleUpdateGuestsLive = (adults: number, kids: number, duration: number) => {
    updateCurrentPlan((p) => {
      const newPortions = recalculatePortions(adults, kids, duration);
      return {
        ...p,
        guestCount: { adults, kids, total: adults + kids },
        durationHours: duration,
        portionsBreakdown: newPortions,
      };
    });
  };

  const handleUpdateEventDate = (newDateStr: string) => {
    updateCurrentPlan((p) => ({
      ...p,
      eventDate: newDateStr,
    }));
  };

  const handleUpdateMemories = (newMemories: PartyMemory[]) => {
    updateCurrentPlan((p) => ({
      ...p,
      memories: newMemories,
    }));
  };

  // Agent Chat Interaction
  const handleSendMessage = async (text: string) => {
    const userMsg: AgentMessage = {
      id: `msg-user-${Date.now()}`,
      sender: "user",
      timestamp: new Date().toISOString(),
      text,
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsThinking(true);

    try {
      const res = await fetch("/api/agent/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: text,
          currentPlan,
          chatHistory: messages.slice(-6),
        }),
      });

      const data = await res.json();
      const actionsList: any[] = [];

      // If agent returned structured action, apply it to the shopping plan!
      if (data.action) {
        if (data.action.type === "add_items" && data.action.itemsToAdd?.length > 0) {
          data.action.itemsToAdd.forEach((item: ShoppingItem) => {
            handleAddItem(item);
          });
          actionsList.push({
            type: "item_added",
            title: `Added ${data.action.itemsToAdd.length} items to shopping list`,
            details: data.action.description || data.action.itemsToAdd.map((i: any) => i.name).join(", "),
          });
        }

        if (data.action.itemIdsToRemove?.length > 0) {
          data.action.itemIdsToRemove.forEach((id: string) => {
            handleDeleteItem(id);
          });
          actionsList.push({
            type: "list_updated",
            title: `Removed items as requested`,
            details: data.action.description,
          });
        }

        if (data.action.newBudgetLimit) {
          updateCurrentPlan((p) => ({ ...p, budgetLimit: data.action.newBudgetLimit }));
          actionsList.push({
            type: "budget_cut",
            title: `Updated budget limit to $${data.action.newBudgetLimit}`,
          });
        }
      }

      const agentReplyMsg: AgentMessage = {
        id: `msg-agent-${Date.now()}`,
        sender: "agent",
        timestamp: new Date().toISOString(),
        text: data.reply || "I've reviewed your request and updated your party planner notes.",
        agentActions: actionsList,
        suggestedFollowUps: data.suggestedFollowUps || [
          "Check budget health",
          "What stores are in my route?",
          "Review ice calculations",
        ],
      };

      setMessages((prev) => [...prev, agentReplyMsg]);
    } catch (err) {
      console.error("Agent chat error:", err);
      setMessages((prev) => [
        ...prev,
        {
          id: `msg-agent-${Date.now()}`,
          sender: "agent",
          timestamp: new Date().toISOString(),
          text: "I've noted that! For full interactive AI agent responses and real-time recipe formulas, make sure your Gemini API key is configured in settings.",
          suggestedFollowUps: ["How much ice do I need?", "Help me save $30"],
        },
      ]);
    } finally {
      setIsThinking(false);
    }
  };

  const handleOpenAgentWithPrompt = (prompt: string) => {
    setAgentPresetPrompt(prompt);
    setIsAgentOpen(true);
  };

  const handleCopyChecklist = () => {
    const txt = formatPlanAsText(currentPlan);
    navigator.clipboard.writeText(txt);
  };

  const handleExportCSV = () => {
    exportPlanAsCSV(currentPlan);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 flex flex-col font-sans">
      {/* Top Header */}
      <Header
        currentPlan={currentPlan}
        onOpenSetup={() => setIsSetupOpen(true)}
        onOpenAgentChat={() => setIsAgentOpen(true)}
        onOpenMobileMode={() => setIsMobileModeOpen(true)}
        onOpenVoiceControl={() => setIsVoiceModalOpen(true)}
        onOpenCountdown={() => setActiveTab("countdown")}
        onOpenMemoryShare={() => setIsMemoryModalOpen(true)}
        onOpenScratchGifts={() => setIsScratchGiftsOpen(true)}
        onExportCSV={handleExportCSV}
        onCopyText={handleCopyChecklist}
        onPrint={handlePrint}
        savedPlans={plans}
        onSelectPlan={(plan) => setActivePlanId(plan.id)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto pb-1 scrollbar-none no-print border-b border-stone-800/80">
          <button
            onClick={() => setActiveTab("list")}
            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === "list"
                ? "bg-amber-500 text-stone-950 shadow-md shadow-amber-500/20"
                : "bg-stone-900 text-stone-400 hover:text-stone-200 hover:bg-stone-800 border border-stone-800"
            }`}
            id="tab-btn-shopping-list"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Shopping List ({currentPlan.items.length})</span>
          </button>

          <button
            onClick={() => setActiveTab("countdown")}
            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === "countdown"
                ? "bg-amber-500 text-stone-950 shadow-md shadow-amber-500/20"
                : "bg-stone-900 text-stone-400 hover:text-stone-200 hover:bg-stone-800 border border-stone-800"
            }`}
            id="tab-btn-countdown-tab"
          >
            <Clock className="w-4 h-4 text-orange-400" />
            <span>Party Countdown & Moments</span>
          </button>

          <button
            onClick={() => setActiveTab("portions")}
            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === "portions"
                ? "bg-amber-500 text-stone-950 shadow-md shadow-amber-500/20"
                : "bg-stone-900 text-stone-400 hover:text-stone-200 hover:bg-stone-800 border border-stone-800"
            }`}
            id="tab-btn-portion-math"
          >
            <Calculator className="w-4 h-4" />
            <span>Portion Calculator</span>
          </button>

          <button
            onClick={() => setActiveTab("budget")}
            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === "budget"
                ? "bg-amber-500 text-stone-950 shadow-md shadow-amber-500/20"
                : "bg-stone-900 text-stone-400 hover:text-stone-200 hover:bg-stone-800 border border-stone-800"
            }`}
            id="tab-btn-budget-stores"
          >
            <PieChart className="w-4 h-4" />
            <span>Budget & Store Routes</span>
          </button>

          <button
            onClick={() => setActiveTab("timeline")}
            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === "timeline"
                ? "bg-amber-500 text-stone-950 shadow-md shadow-amber-500/20"
                : "bg-stone-900 text-stone-400 hover:text-stone-200 hover:bg-stone-800 border border-stone-800"
            }`}
            id="tab-btn-timeline"
          >
            <Clock className="w-4 h-4" />
            <span>Prep Timeline</span>
          </button>

          <button
            onClick={() => setActiveTab("menu")}
            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === "menu"
                ? "bg-amber-500 text-stone-950 shadow-md shadow-amber-500/20"
                : "bg-stone-900 text-stone-400 hover:text-stone-200 hover:bg-stone-800 border border-stone-800"
            }`}
            id="tab-btn-menu-bar"
          >
            <UtensilsCrossed className="w-4 h-4" />
            <span>Menu & Bar Pairing</span>
          </button>
        </div>

        {/* Tab 1: Primary Shopping List */}
        {activeTab === "list" && (
          <div className="space-y-6">
            {/* Quick Hero Banner with AI Summary & Countdown Shortcut */}
            <div className="bg-gradient-to-r from-amber-500/10 via-orange-500/5 to-transparent border border-amber-500/20 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-bold text-stone-100 font-display">
                    {currentPlan.name}
                  </h2>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-medium border border-amber-500/30">
                    {currentPlan.vibe} vibe
                  </span>
                </div>
                <p className="text-xs text-stone-400 max-w-2xl leading-relaxed">
                  Calculated for <strong className="text-stone-200">{currentPlan.guestCount.total} guests</strong> ({currentPlan.guestCount.adults} adults, {currentPlan.guestCount.kids} kids) for a {currentPlan.durationHours}-hour event.
                  Target budget: <strong className="text-amber-300">${currentPlan.budgetLimit}</strong>.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
                <button
                  onClick={() => setIsVoiceModalOpen(true)}
                  className="px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm group"
                  id="btn-list-voice-assistant"
                >
                  <Mic className="w-3.5 h-3.5 text-amber-400 group-hover:scale-110 transition-transform" />
                  <span>Hands-Free Voice</span>
                </button>

                <button
                  onClick={() => setIsScratchGiftsOpen(true)}
                  className="px-3.5 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-700 text-xs font-semibold flex items-center gap-1.5 transition-all"
                  title="Claim 25% off booking & Flipkart gifts"
                >
                  <Gift className="w-3.5 h-3.5 text-rose-400" />
                  <span>Scratch Gifts</span>
                </button>

                <button
                  onClick={() => setIsMobileModeOpen(true)}
                  className="px-3.5 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm"
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span>Store Mode</span>
                </button>

                <button
                  onClick={() => handleOpenAgentWithPrompt("Review my shopping list and suggest missing essentials")}
                  className="px-3.5 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-amber-300 border border-stone-700 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
                  title="Ask CymbalMart Assistant to review"
                >
                  <Bot className="w-3.5 h-3.5" />
                  <span>Ask Assistant</span>
                </button>
              </div>
            </div>

            {/* Shopping List Component */}
            <ShoppingListView
              plan={currentPlan}
              onToggleItem={handleToggleItem}
              onDeleteItem={handleDeleteItem}
              onAddItem={handleAddItem}
              onUpdateItem={handleUpdateItem}
              onBulkCheck={handleBulkCheck}
            />
          </div>
        )}

        {/* Tab 2: Party Countdown & Memory Sharing Hub */}
        {activeTab === "countdown" && (
          <div className="space-y-6">
            <CountdownCard
              currentPlan={currentPlan}
              onUpdateEventDate={handleUpdateEventDate}
              onOpenMemoryShare={() => setIsMemoryModalOpen(true)}
              onOpenScratchGifts={() => setIsScratchGiftsOpen(true)}
            />

            {/* Quick Feature Cards under Countdown */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* QR Memory Card */}
              <div className="bg-stone-900 border border-stone-800 rounded-3xl p-5 flex flex-col justify-between space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-sky-500/10 text-sky-400 border border-sky-500/20 flex items-center justify-center flex-shrink-0">
                    <QrCode className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-stone-100 font-display">
                      Guest QR Code Memory Sharing
                    </h3>
                    <p className="text-xs text-stone-400 mt-1 leading-relaxed">
                      Generate printable and scannable QR codes for table centerpieces. VIP security check gives exclusive upload access to invited guests and host.
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-stone-800">
                  <span className="text-xs text-stone-500">Security Gate: Protected</span>
                  <button
                    onClick={() => setIsMemoryModalOpen(true)}
                    className="px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-stone-950 font-bold text-xs flex items-center gap-1.5 transition-colors"
                  >
                    <span>Open Memory Wall & QR</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Scratch Gifts Card */}
              <div className="bg-stone-900 border border-stone-800 rounded-3xl p-5 flex flex-col justify-between space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center justify-center flex-shrink-0">
                    <Gift className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-stone-100 font-display">
                      Party Scratch Rewards & Vouchers
                    </h3>
                    <p className="text-xs text-stone-400 mt-1 leading-relaxed">
                      Scratch to reveal 25% off party bookings, ₹500 Flipkart shopping vouchers, and 1 month free CymbalMart Plus subscriptions!
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-stone-800">
                  <span className="text-xs text-amber-400 font-semibold">4 Rewards Available</span>
                  <button
                    onClick={() => setIsScratchGiftsOpen(true)}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-stone-950 font-bold text-xs flex items-center gap-1.5 transition-colors"
                  >
                    <span>Scratch Gifts Now</span>
                    <Flame className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Portion Calculator */}
        {activeTab === "portions" && (
          <div className="space-y-6">
            <PortionEstimatorCard
              plan={currentPlan}
              onUpdateGuests={handleUpdateGuestsLive}
            />
          </div>
        )}

        {/* Tab 4: Budget & Store Routes */}
        {activeTab === "budget" && (
          <div className="space-y-6">
            <BudgetAndStoreOptimizer
              plan={currentPlan}
              onOpenAgentWithPrompt={handleOpenAgentWithPrompt}
            />
          </div>
        )}

        {/* Tab 5: Timeline */}
        {activeTab === "timeline" && (
          <div className="space-y-6">
            <TimelineView plan={currentPlan} />
          </div>
        )}

        {/* Tab 6: Menu & Drinks */}
        {activeTab === "menu" && (
          <div className="space-y-6">
            <MenuHighlightsCard
              plan={currentPlan}
              onOpenAgentForRecipe={handleOpenAgentWithPrompt}
            />
          </div>
        )}
      </main>

      {/* Floating Action Buttons Cluster (Bottom Right) */}
      <div className="fixed bottom-6 right-6 z-30 flex items-center gap-3 no-print">
        {/* Hands-Free Voice Control Button */}
        <button
          onClick={() => setIsVoiceModalOpen(true)}
          className="px-4 py-3.5 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-stone-950 font-bold text-sm flex items-center gap-2 shadow-2xl shadow-amber-500/30 transition-all hover:scale-105 active:scale-95 cursor-pointer ring-2 ring-amber-400/50"
          id="btn-floating-voice-assistant"
          title="Hands-Free Voice Control"
        >
          <Mic className="w-5 h-5 text-stone-950 animate-pulse" />
          <span className="hidden sm:inline">Voice Control</span>
        </button>

        {/* Chat Assistant Button */}
        <button
          onClick={() => setIsAgentOpen(true)}
          className="px-4 py-3.5 rounded-full bg-stone-900 hover:bg-stone-800 text-stone-100 border border-stone-700 font-bold text-sm flex items-center gap-2 shadow-2xl transition-all hover:scale-105 active:scale-95 cursor-pointer"
          id="btn-floating-agent-chat"
          title="Chat with CymbalMart Assistant"
        >
          <Bot className="w-5 h-5 text-amber-400" />
          <span className="hidden sm:inline">Assistant</span>
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
        </button>
      </div>

      {/* Voice Assistant Hands-Free Modal */}
      <VoiceAssistantModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        currentPlan={currentPlan}
        onAddItem={handleAddItem}
        onDeleteItem={handleDeleteItem}
        onToggleItemCheck={handleToggleItem}
        onUpdateBudget={(newLimit) => updateCurrentPlan((p) => ({ ...p, budgetLimit: newLimit }))}
        onSwitchTab={(tab) => setActiveTab(tab as ActiveTab)}
        onOpenAgentChat={() => setIsAgentOpen(true)}
        onOpenCountdown={() => setActiveTab("countdown")}
        onOpenMemoryShare={() => setIsMemoryModalOpen(true)}
        onOpenScratchGifts={() => setIsScratchGiftsOpen(true)}
        onOpenMobileMode={() => setIsMobileModeOpen(true)}
      />

      {/* Memory Sharing & QR Security Modal */}
      <MemoryShareModal
        isOpen={isMemoryModalOpen}
        onClose={() => setIsMemoryModalOpen(false)}
        currentPlan={currentPlan}
        onUpdateMemories={handleUpdateMemories}
      />

      {/* Scratch Gifts & Rewards Modal */}
      <ScratchGiftsModal
        isOpen={isScratchGiftsOpen}
        onClose={() => setIsScratchGiftsOpen(false)}
      />

      {/* Party Setup Wizard Modal */}
      <PartySetupModal
        isOpen={isSetupOpen}
        onClose={() => setIsSetupOpen(false)}
        onPlanGenerated={handlePlanGenerated}
        initialPlan={currentPlan}
      />

      {/* Agent Chat Drawer */}
      <AgentChatDrawer
        isOpen={isAgentOpen}
        onClose={() => setIsAgentOpen(false)}
        plan={currentPlan}
        messages={messages}
        onSendMessage={handleSendMessage}
        isThinking={isThinking}
        onApplyAgentAction={() => {}}
        presetPrompt={agentPresetPrompt}
        onClearPresetPrompt={() => setAgentPresetPrompt(undefined)}
      />

      {/* In-Store Mobile Mode Modal */}
      {isMobileModeOpen && (
        <MobileShoppingMode
          plan={currentPlan}
          onClose={() => setIsMobileModeOpen(false)}
          onToggleItem={handleToggleItem}
        />
      )}

      {/* Printable Output View (visible only during window.print()) */}
      <div className="hidden print:block p-8 bg-white text-black font-sans">
        <div className="text-xs uppercase tracking-wider text-gray-500 font-bold mb-1">CymbalMart Shopping Agent</div>
        <h1 className="text-2xl font-bold mb-1">{currentPlan.name}</h1>
        <p className="text-sm text-gray-600 mb-4">
          Theme: {currentPlan.theme} | {currentPlan.guestCount.total} Guests ({currentPlan.guestCount.adults} adults, {currentPlan.guestCount.kids} kids) | Budget: ${currentPlan.budgetLimit}
        </p>

        <h2 className="text-lg font-bold border-b pb-1 mb-2 mt-4">Shopping Checklist</h2>
        <div className="space-y-1">
          {currentPlan.items.map((item, i) => (
            <div key={i} className="flex items-center justify-between text-sm py-1 border-b border-gray-100">
              <div>
                <span className="inline-block w-4 h-4 border border-black mr-2 align-middle" />
                <strong>{item.name}</strong> - {item.quantity} {item.unit} ({item.storeType})
              </div>
              <div>${item.estimatedPriceMin} - ${item.estimatedPriceMax}</div>
            </div>
          ))}
        </div>

        <h2 className="text-lg font-bold border-b pb-1 mb-2 mt-6">Portion Guidelines</h2>
        <p className="text-sm text-gray-700">
          • Appetizers: {currentPlan.portionsBreakdown.appetizersTotalPieces} pieces (~{currentPlan.portionsBreakdown.appetizersPerPerson}/person)<br />
          • Alcoholic Drinks: {currentPlan.portionsBreakdown.alcoholicDrinksCount} drinks<br />
          • Soft Drinks: {currentPlan.portionsBreakdown.nonAlcoholicDrinksCount} cans/cups<br />
          • Party Ice: {currentPlan.portionsBreakdown.iceLbsNeeded} lbs ({Math.ceil(currentPlan.portionsBreakdown.iceLbsNeeded / 10)} bags)<br />
          • Tableware: {currentPlan.portionsBreakdown.cupsPlatesNapkinsCount} sets
        </p>
      </div>
    </div>
  );
}
