import { ItemCategory, StoreType } from "../types";

export interface CategoryMeta {
  id: ItemCategory;
  label: string;
  shortLabel: string;
  iconName: string;
  colorClass: string;
  borderClass: string;
  bgLightClass: string;
}

export const CATEGORY_DEFINITIONS: Record<ItemCategory, CategoryMeta> = {
  produce: {
    id: "produce",
    label: "Fresh Produce & Herbs",
    shortLabel: "Produce",
    iconName: "Apple",
    colorClass: "text-emerald-400",
    borderClass: "border-emerald-500/30",
    bgLightClass: "bg-emerald-500/10",
  },
  "meat-seafood": {
    id: "meat-seafood",
    label: "Meats, Poultry & Seafood",
    shortLabel: "Meat & Seafood",
    iconName: "Beef",
    colorClass: "text-rose-400",
    borderClass: "border-rose-500/30",
    bgLightClass: "bg-rose-500/10",
  },
  bakery: {
    id: "bakery",
    label: "Bakery, Buns & Breads",
    shortLabel: "Bakery",
    iconName: "Croissant",
    colorClass: "text-amber-400",
    borderClass: "border-amber-500/30",
    bgLightClass: "bg-amber-500/10",
  },
  "dairy-chilled": {
    id: "dairy-chilled",
    label: "Dairy, Cheeses & Dips",
    shortLabel: "Dairy & Chilled",
    iconName: "Milk",
    colorClass: "text-yellow-300",
    borderClass: "border-yellow-500/30",
    bgLightClass: "bg-yellow-500/10",
  },
  "pantry-dry": {
    id: "pantry-dry",
    label: "Pantry, Spices & Condiments",
    shortLabel: "Pantry",
    iconName: "Archive",
    colorClass: "text-orange-400",
    borderClass: "border-orange-500/30",
    bgLightClass: "bg-orange-500/10",
  },
  "beverages-alcohol": {
    id: "beverages-alcohol",
    label: "Beer, Wine & Spirits",
    shortLabel: "Alcohol & Bar",
    iconName: "Wine",
    colorClass: "text-purple-400",
    borderClass: "border-purple-500/30",
    bgLightClass: "bg-purple-500/10",
  },
  "beverages-soft": {
    id: "beverages-soft",
    label: "Sodas, Juices & Mocktails",
    shortLabel: "Soft Drinks",
    iconName: "Coffee",
    colorClass: "text-cyan-400",
    borderClass: "border-cyan-500/30",
    bgLightClass: "bg-cyan-500/10",
  },
  "snacks-sweets": {
    id: "snacks-sweets",
    label: "Chips, Nuts & Sweets",
    shortLabel: "Snacks",
    iconName: "Cookie",
    colorClass: "text-pink-400",
    borderClass: "border-pink-500/30",
    bgLightClass: "bg-pink-500/10",
  },
  "tableware-supplies": {
    id: "tableware-supplies",
    label: "Plates, Cups, Cutlery & Napkins",
    shortLabel: "Tableware",
    iconName: "Utensils",
    colorClass: "text-blue-400",
    borderClass: "border-blue-500/30",
    bgLightClass: "bg-blue-500/10",
  },
  "decor-lighting": {
    id: "decor-lighting",
    label: "Decorations, Balloons & Lights",
    shortLabel: "Decor",
    iconName: "Sparkles",
    colorClass: "text-fuchsia-400",
    borderClass: "border-fuchsia-500/30",
    bgLightClass: "bg-fuchsia-500/10",
  },
  "ice-coolers-cleaning": {
    id: "ice-coolers-cleaning",
    label: "Party Ice, Coolers & Cleanup",
    shortLabel: "Ice & Cleaning",
    iconName: "Snowflake",
    colorClass: "text-sky-300",
    borderClass: "border-sky-500/30",
    bgLightClass: "bg-sky-500/10",
  },
  "outdoor-gear": {
    id: "outdoor-gear",
    label: "Outdoor Seating, Shelter & Comfort",
    shortLabel: "Outdoor & Shelter",
    iconName: "Tent",
    colorClass: "text-emerald-300",
    borderClass: "border-emerald-500/30",
    bgLightClass: "bg-emerald-500/10",
  },
  "activities-favors": {
    id: "activities-favors",
    label: "Games, Favors & Activities",
    shortLabel: "Activities & Favors",
    iconName: "Gift",
    colorClass: "text-teal-400",
    borderClass: "border-teal-500/30",
    bgLightClass: "bg-teal-500/10",
  },
};

export const STORE_TYPE_OPTIONS: StoreType[] = [
  "Supermarket / Grocery",
  "Wholesale Club (Costco/Sam's)",
  "Liquor & Wine Store",
  "Party & Craft Store",
  "Dollar Store / Discount",
  "Bakery / Specialty",
  "Outdoor / Hardware Store",
];

export const DIETARY_OPTIONS = [
  "Vegetarian",
  "Vegan",
  "Gluten-Free",
  "Nut-Free",
  "Dairy-Free",
  "Halal",
  "Kosher",
  "Pescatarian",
  "Low Sugar / Keto",
];
