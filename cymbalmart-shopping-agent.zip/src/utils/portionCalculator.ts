import { PortionsBreakdown, ShoppingItem, BudgetAnalysis } from "../types";

export function recalculatePortions(
  adults: number,
  kids: number,
  durationHours: number,
  servingStyle: string = "buffet"
): PortionsBreakdown {
  const total = adults + kids;
  const isHeavyAppetizer = servingStyle === "finger-foods-only" || servingStyle === "cocktail";

  const appPerPerson = isHeavyAppetizer ? Math.max(8, durationHours * 2.5) : Math.max(4, durationHours * 1.3);
  const appetizersTotal = Math.round(total * appPerPerson);
  const mainServings = Math.round(adults + kids * 0.7);
  const sidesTotal = Math.round(total * 0.45);
  
  // Drinks math: 1.5 drinks first hour, 1 drink per hour after for adults
  const drinksPerAdult = Math.max(1, 1.5 + (durationHours - 1) * 0.9);
  const alcoholicDrinks = Math.round(adults * drinksPerAdult);
  const nonAlcoholicDrinks = Math.round(total * durationHours * 0.75 + kids * durationHours);
  
  // Ice math: 1.25 lbs per person + 0.25 lbs per extra hour
  const iceLbs = Math.max(10, Math.round(total * (1.1 + (durationHours - 2) * 0.15)));
  const desserts = Math.round(total * 1.1);
  const tableware = Math.round(total * 1.5);

  return {
    appetizersTotalPieces: appetizersTotal,
    appetizersPerPerson: Math.round(appPerPerson),
    mainCourseServings: mainServings,
    sidesTotalLbsOrServings: sidesTotal,
    alcoholicDrinksCount: alcoholicDrinks,
    nonAlcoholicDrinksCount: nonAlcoholicDrinks,
    iceLbsNeeded: iceLbs,
    dessertServings: desserts,
    cupsPlatesNapkinsCount: tableware,
    calculationExplanation: `Recalculated for ${total} guests (${adults} adults, ${kids} kids) over ${durationHours}h: ${appetizersTotal} appetizer bites, ${alcoholicDrinks} alcoholic beverages, ${nonAlcoholicDrinks} soft drinks, ${iceLbs} lbs party ice, and ${tableware} tableware sets.`,
  };
}

export function calculateBudgetAnalysis(
  items: ShoppingItem[],
  budgetLimit: number,
  totalGuests: number = 12
): BudgetAnalysis {
  let minTotal = 0;
  let maxTotal = 0;
  const categoryMap: Record<string, number> = {};

  items.forEach((item) => {
    const itemMin = (item.estimatedPriceMin || 0) * (item.quantity > 0 ? 1 : 0);
    const itemMax = (item.estimatedPriceMax || item.estimatedPriceMin || 0) * (item.quantity > 0 ? 1 : 0);
    
    minTotal += itemMin;
    maxTotal += itemMax;

    const mid = (itemMin + itemMax) / 2;
    categoryMap[item.category] = (categoryMap[item.category] || 0) + mid;
  });

  const guestCountSafe = Math.max(1, totalGuests);
  const avgCost = (minTotal + maxTotal) / 2;
  
  let budgetStatus: "under" | "on-target" | "over" = "on-target";
  if (maxTotal < budgetLimit * 0.9) {
    budgetStatus = "under";
  } else if (minTotal > budgetLimit) {
    budgetStatus = "over";
  }

  const savingsTips: string[] = [];
  if (categoryMap["beverages-alcohol"] > budgetLimit * 0.35) {
    savingsTips.push("Alcohol comprises >35% of your list. Swapping boutique wines for wholesale cases or offering 1 signature punch saves ~$40.");
  }
  if (categoryMap["tableware-supplies"] > 35) {
    savingsTips.push("Consider grabbing basic napkins, cups, and cutlery from a discount wholesale mart to save $15-20.");
  }
  if (categoryMap["meat-seafood"] > budgetLimit * 0.4) {
    savingsTips.push("Balance expensive protein cuts with hearty bulk sides (pasta salad, roasted potatoes, garlic bread) to lower meat costs safely.");
  }
  if (categoryMap["outdoor-gear"] > 60) {
    savingsTips.push("For outdoor gear (canopy, folding chairs), consider borrowing or renting to keep shopping costs strictly food-focused.");
  }
  if (savingsTips.length === 0) {
    savingsTips.push("Shop wholesale clubs for non-perishables and beverages 3 days early.");
    savingsTips.push("Buy produce and bakery items 24 hours in advance for prime freshness.");
    savingsTips.push("Stick to seasonal fruits and vegetables to maximize quality and cost savings.");
  }

  return {
    totalEstimatedCostMin: Math.round(minTotal),
    totalEstimatedCostMax: Math.round(maxTotal),
    costPerGuest: Math.round(avgCost / guestCountSafe),
    budgetStatus,
    savingsTips,
    categoryDistribution: categoryMap,
  };
}
