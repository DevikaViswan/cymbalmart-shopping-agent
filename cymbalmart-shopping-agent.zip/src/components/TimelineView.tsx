import React, { useState } from "react";
import { Clock, Calendar, CheckCircle2, Circle, AlertCircle, Sparkles } from "lucide-react";
import { TimelineStep, PartyPlan } from "../types";

interface TimelineViewProps {
  plan: PartyPlan;
}

export const TimelineView: React.FC<TimelineViewProps> = ({ plan }) => {
  const [completedTasks, setCompletedTasks] = useState<Record<string, boolean>>({});

  const toggleTask = (taskKey: string) => {
    setCompletedTasks((prev) => ({
      ...prev,
      [taskKey]: !prev[taskKey],
    }));
  };

  const timelineSteps = plan.timeline || [];

  return (
    <div className="bg-stone-900 border border-stone-800 rounded-2xl p-5 sm:p-6 shadow-lg space-y-6">
      <div className="flex items-center justify-between pb-4 border-b border-stone-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-stone-100 font-display">
              Shopping & Preparation Timeline
            </h3>
            <p className="text-xs text-stone-400">
              When to buy, what to marinate ahead, and day-of chilling checkpoints
            </p>
          </div>
        </div>
      </div>

      <div className="relative pl-4 sm:pl-6 space-y-8 before:absolute before:left-[19px] sm:before:left-[27px] before:top-3 before:bottom-3 before:w-0.5 before:bg-stone-800">
        {timelineSteps.map((step, idx) => {
          return (
            <div key={idx} className="relative flex items-start gap-4">
              {/* Step Node Marker */}
              <div className="w-6 h-6 rounded-full bg-stone-900 border-2 border-amber-500 flex items-center justify-center text-[10px] font-bold text-amber-400 z-10 flex-shrink-0">
                {idx + 1}
              </div>

              {/* Step Content Card */}
              <div className="flex-1 bg-stone-950/60 border border-stone-800/80 rounded-xl p-4 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-amber-400 font-display uppercase tracking-wider">
                      {step.timeframe}
                    </span>
                    <span className="text-stone-400">•</span>
                    <h4 className="text-sm font-semibold text-stone-100">{step.title}</h4>
                  </div>
                </div>

                <div className="space-y-2">
                  {step.tasks.map((task, tIdx) => {
                    const taskKey = `${idx}-${tIdx}`;
                    const isDone = !!completedTasks[taskKey];

                    return (
                      <button
                        type="button"
                        key={tIdx}
                        onClick={() => toggleTask(taskKey)}
                        className={`w-full text-left flex items-start gap-2.5 p-2 rounded-lg transition-colors ${
                          isDone ? "bg-stone-900/30 text-stone-400 line-through" : "hover:bg-stone-800/50 text-stone-300"
                        }`}
                      >
                        <span className="mt-0.5 flex-shrink-0">
                          {isDone ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400 fill-emerald-400/20" />
                          ) : (
                            <Circle className="w-4 h-4 text-stone-500 hover:text-amber-400" />
                          )}
                        </span>
                        <span className="text-xs leading-relaxed">{task}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
