import React, { useState, useRef, useEffect } from "react";
import {
  X,
  Send,
  Sparkles,
  Bot,
  User,
  PlusCircle,
  CheckCircle2,
  Lightbulb,
  ArrowRight,
  Trash2,
} from "lucide-react";
import { PartyPlan, AgentMessage, ShoppingItem } from "../types";

interface AgentChatDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  plan: PartyPlan;
  messages: AgentMessage[];
  onSendMessage: (text: string) => Promise<void>;
  isThinking: boolean;
  onApplyAgentAction: (action: any) => void;
  presetPrompt?: string;
  onClearPresetPrompt?: () => void;
}

const DEFAULT_CHIPS = [
  "How much ice & drinks do I need?",
  "Suggest budget-friendly party food",
  "Find dairy-free & vegan alternatives",
  "Help me trim $40 from this list",
  "What tableware items am I missing?",
  "Suggest a signature cocktail & mocktail",
  "Which stores should I visit first?",
];

export const AgentChatDrawer: React.FC<AgentChatDrawerProps> = ({
  isOpen,
  onClose,
  plan,
  messages,
  onSendMessage,
  isThinking,
  onApplyAgentAction,
  presetPrompt,
  onClearPresetPrompt,
}) => {
  const [inputText, setInputText] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (presetPrompt) {
      setInputText(presetPrompt);
      if (onClearPresetPrompt) onClearPresetPrompt();
    }
  }, [presetPrompt]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isThinking]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isThinking) return;
    const text = inputText.trim();
    setInputText("");
    await onSendMessage(text);
  };

  const handleChipClick = async (chip: string) => {
    if (isThinking) return;
    await onSendMessage(chip);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-stone-950/70 backdrop-blur-sm flex justify-end">
      <div className="w-full max-w-lg bg-stone-900 border-l border-stone-800 h-full shadow-2xl flex flex-col">
        {/* Header */}
        <div className="px-5 py-4 border-b border-stone-800 flex items-center justify-between bg-stone-900/90">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-md shadow-amber-500/20 text-stone-950 font-bold">
              <Bot className="w-5 h-5 text-stone-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-stone-100 font-display">
                  CymbalMart Assistant
                </h3>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
                  Customer Concierge
                </span>
              </div>
              <p className="text-[11px] text-stone-400">
                Helping with &ldquo;{plan.name}&rdquo; ({plan.guestCount.total} guests)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-100 hover:bg-stone-800 transition-colors cursor-pointer"
            id="btn-close-agent-drawer"
            title="Close CymbalMart Assistant"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message Thread */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
            >
              {msg.sender === "agent" && (
                <div className="w-7 h-7 rounded-lg bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 flex-shrink-0 mt-0.5">
                  <Sparkles className="w-3.5 h-3.5" />
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed space-y-2.5 ${
                  msg.sender === "user"
                    ? "bg-amber-500 text-stone-950 font-medium rounded-tr-none"
                    : "bg-stone-950 border border-stone-800 text-stone-200 rounded-tl-none shadow-sm"
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.text}</div>

                {/* Render Action Card if Agent performed a list update */}
                {msg.agentActions && msg.agentActions.length > 0 && (
                  <div className="space-y-2 pt-1 border-t border-stone-800/80">
                    {msg.agentActions.map((action, aIdx) => (
                      <div
                        key={aIdx}
                        className="bg-stone-900 border border-amber-500/30 rounded-xl p-2.5 text-xs text-stone-300 space-y-1.5"
                      >
                        <div className="flex items-center justify-between font-semibold text-amber-300">
                          <span className="flex items-center gap-1.5">
                            <PlusCircle className="w-3.5 h-3.5" />
                            {action.title}
                          </span>
                        </div>
                        {action.details && (
                          <div className="text-[11px] text-stone-400">{action.details}</div>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {/* Follow up suggestions */}
                {msg.suggestedFollowUps && msg.suggestedFollowUps.length > 0 && (
                  <div className="pt-2 flex flex-wrap gap-1.5">
                    {msg.suggestedFollowUps.map((chip, cIdx) => (
                      <button
                        key={cIdx}
                        type="button"
                        onClick={() => handleChipClick(chip)}
                        className="text-[11px] px-2.5 py-1 rounded-full bg-stone-900 hover:bg-stone-800 text-amber-300 border border-amber-500/30 transition-colors"
                      >
                        {chip}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {msg.sender === "user" && (
                <div className="w-7 h-7 rounded-lg bg-stone-800 flex items-center justify-center text-stone-300 flex-shrink-0 mt-0.5">
                  <User className="w-3.5 h-3.5" />
                </div>
              )}
            </div>
          ))}

          {isThinking && (
            <div className="flex gap-3 items-center">
              <div className="w-7 h-7 rounded-lg bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 flex-shrink-0">
                <Sparkles className="w-3.5 h-3.5 animate-spin" />
              </div>
              <div className="bg-stone-950 border border-stone-800 rounded-2xl rounded-tl-none px-4 py-3 text-xs text-stone-400 flex items-center gap-2">
                <span>CymbalMart Assistant is reviewing products & calculating...</span>
                <div className="flex gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-bounce" />
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-bounce delay-100" />
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-bounce delay-200" />
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Chips */}
        <div className="px-4 py-2 bg-stone-950/70 border-t border-stone-800/80">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {DEFAULT_CHIPS.map((chip, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleChipClick(chip)}
                className="flex-shrink-0 text-[11px] px-2.5 py-1 rounded-lg bg-stone-800 hover:bg-stone-700/80 text-stone-300 hover:text-amber-300 border border-stone-700/60 transition-colors"
              >
                {chip}
              </button>
            ))}
          </div>
        </div>

        {/* Input Bar */}
        <div className="p-4 bg-stone-900 border-t border-stone-800">
          <form onSubmit={handleSubmit} className="flex items-center gap-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Ask CymbalMart Assistant to find items, calculate portions, or adjust budget..."
              className="flex-1 px-4 py-2.5 rounded-xl bg-stone-800 border border-stone-700 text-stone-100 placeholder-stone-400 focus:outline-none focus:border-amber-500 text-xs sm:text-sm"
              id="input-agent-chat-text"
            />
            <button
              type="submit"
              disabled={!inputText.trim() || isThinking}
              className="p-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-stone-950 font-bold transition-all disabled:opacity-40"
              id="btn-send-agent-chat"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
