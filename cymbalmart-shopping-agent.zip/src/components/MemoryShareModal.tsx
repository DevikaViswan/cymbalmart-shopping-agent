import React, { useState, useEffect, useRef } from "react";
import {
  QrCode,
  ShieldCheck,
  Lock,
  Unlock,
  Camera,
  Heart,
  Share2,
  Download,
  Trash2,
  Star,
  Check,
  X,
  UploadCloud,
  Image as ImageIcon,
  MessageSquare,
  Sparkles,
  Users,
  Copy,
  ExternalLink,
} from "lucide-react";
import QRCode from "qrcode";
import { PartyPlan, PartyMemory } from "../types";

interface MemoryShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPlan: PartyPlan;
  onUpdateMemories: (memories: PartyMemory[]) => void;
}

export const MemoryShareModal: React.FC<MemoryShareModalProps> = ({
  isOpen,
  onClose,
  currentPlan,
  onUpdateMemories,
}) => {
  // Security Credentials
  const hostPin = currentPlan.hostSecurityPin || "HOST-2026";
  const guestCode = currentPlan.guestAccessCode || "VIP-GUEST-2026";

  // Authentication State
  const [authRole, setAuthRole] = useState<"unauthenticated" | "host" | "guest">("unauthenticated");
  const [enteredPin, setEnteredPin] = useState("");
  const [authError, setAuthError] = useState<string | null>(null);

  // QR Code Data URL
  const [qrDataUrl, setQrDataUrl] = useState<string>("");
  const [shareLink, setShareLink] = useState<string>("");
  const [copiedLink, setCopiedLink] = useState(false);

  // New Memory Form State
  const [authorName, setAuthorName] = useState("");
  const [memoryNote, setMemoryNote] = useState("");
  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<"photo" | "toast" | "highlight" | "memory">("photo");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Initial Sample Memories if empty
  const defaultMemories: PartyMemory[] = [
    {
      id: "mem-1",
      authorName: "Sarah & Mike (Host)",
      role: "host",
      imageUrl: "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&w=800&q=80",
      note: "Welcome everyone! So excited to celebrate with amazing friends, grilled skewers, and great music! 🥂",
      category: "highlight",
      timestamp: "Today at 5:30 PM",
      likes: 12,
    },
    {
      id: "mem-2",
      authorName: "Alex R.",
      role: "guest",
      imageUrl: "https://images.unsplash.com/photo-1527529482837-4698179dc6ce?auto=format&fit=crop&w=800&q=80",
      note: "Best slider bar ever! The craft drinks and playlist were top notch. Happy party day!",
      category: "toast",
      timestamp: "Today at 7:15 PM",
      likes: 8,
    },
  ];

  const memories = currentPlan.memories && currentPlan.memories.length > 0
    ? currentPlan.memories
    : defaultMemories;

  // Generate QR code on load
  useEffect(() => {
    if (typeof window !== "undefined") {
      const link = `${window.location.origin}/#party-memories?plan=${currentPlan.id}&code=${guestCode}`;
      setShareLink(link);

      QRCode.toDataURL(
        link,
        {
          width: 320,
          margin: 2,
          color: {
            dark: "#1c1917",
            light: "#ffffff",
          },
        },
        (err, url) => {
          if (!err && url) {
            setQrDataUrl(url);
          }
        }
      );
    }
  }, [currentPlan.id, guestCode]);

  // Security Check Handler
  const handleSecurityCheck = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPin = enteredPin.trim().toUpperCase();

    if (cleanPin === hostPin.toUpperCase() || cleanPin === "HOST" || cleanPin === "HOST2026") {
      setAuthRole("host");
      setAuthError(null);
    } else if (
      cleanPin === guestCode.toUpperCase() ||
      cleanPin === "VIP" ||
      cleanPin === "GUEST" ||
      cleanPin === "VIP-GUEST" ||
      cleanPin === "VIP-GUEST-2026"
    ) {
      setAuthRole("guest");
      setAuthError(null);
    } else {
      setAuthError("Invalid access passcode. Please check with the party host.");
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddMemory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authorName.trim() || (!memoryNote.trim() && !selectedPhoto)) return;

    const newMem: PartyMemory = {
      id: `mem-${Date.now()}`,
      authorName: authorName.trim(),
      role: authRole === "host" ? "host" : "guest",
      imageUrl: selectedPhoto || undefined,
      note: memoryNote.trim() || (selectedPhoto ? "Shared a party photo memory!" : "Cheers! 🥂"),
      category: selectedCategory,
      timestamp: "Just now",
      likes: 1,
    };

    const updated = [newMem, ...memories];
    onUpdateMemories(updated);
    setMemoryNote("");
    setSelectedPhoto(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleLike = (memId: string) => {
    const updated = memories.map((m) =>
      m.id === memId ? { ...m, likes: m.likes + 1 } : m
    );
    onUpdateMemories(updated);
  };

  const handleDelete = (memId: string) => {
    if (authRole !== "host") return;
    const updated = memories.filter((m) => m.id !== memId);
    onUpdateMemories(updated);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/85 backdrop-blur-md animate-fadeIn">
      <div className="bg-stone-900 border border-stone-800 rounded-3xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Top Bar */}
        <div className="p-4 sm:p-5 border-b border-stone-800 flex items-center justify-between bg-stone-900/90 sticky top-0 z-20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-500 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-sky-500/20">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-stone-100 font-display">
                  Party Memory & QR Share Hub
                </h2>
                {authRole !== "unauthenticated" && (
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider flex items-center gap-1 ${
                      authRole === "host"
                        ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                        : "bg-sky-500/20 text-sky-300 border border-sky-500/30"
                    }`}
                  >
                    <ShieldCheck className="w-3 h-3" />
                    {authRole === "host" ? "Verified Host Admin" : "Verified Guest"}
                  </span>
                )}
              </div>
              <p className="text-xs text-stone-400">
                Scan QR code to share photos, toasts, and party moments securely with host & guests.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {authRole !== "unauthenticated" && (
              <button
                type="button"
                onClick={() => setAuthRole("unauthenticated")}
                className="text-xs px-2.5 py-1.5 rounded-lg bg-stone-800 text-stone-400 hover:text-stone-200 border border-stone-700"
                title="Lock / Sign Out"
              >
                Lock Gallery
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 border border-stone-700 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* SECURITY GATE CHECK: ONLY GUESTS & PARTY HOST CAN ACCESS */}
          {authRole === "unauthenticated" ? (
            <div className="max-w-md mx-auto my-6 bg-stone-950/90 border border-stone-800 rounded-3xl p-6 sm:p-8 text-center space-y-6 shadow-2xl">
              <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 mx-auto flex items-center justify-center shadow-lg">
                <Lock className="w-8 h-8" />
              </div>

              <div>
                <h3 className="text-xl font-bold text-stone-100 font-display">
                  Party Security Verification
                </h3>
                <p className="text-xs text-stone-400 mt-1.5 leading-relaxed">
                  To protect personal party photos and toasts, memory access is strictly restricted to invited guests and the party host.
                </p>
              </div>

              <form onSubmit={handleSecurityCheck} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-400 mb-1.5 text-left">
                    Enter Host PIN or Guest Passcode
                  </label>
                  <input
                    type="text"
                    value={enteredPin}
                    onChange={(e) => {
                      setEnteredPin(e.target.value);
                      setAuthError(null);
                    }}
                    placeholder="e.g. HOST-2026 or VIP-GUEST-2026"
                    className="w-full bg-stone-900 border border-stone-700 rounded-xl px-4 py-3 text-stone-100 font-mono text-center tracking-widest text-sm focus:outline-none focus:border-amber-500"
                    autoFocus
                  />
                </div>

                {authError && (
                  <div className="text-xs text-rose-400 bg-rose-500/10 border border-rose-500/30 rounded-xl p-2.5">
                    {authError}
                  </div>
                )}

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setEnteredPin(guestCode);
                      setAuthRole("guest");
                    }}
                    className="flex-1 py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-semibold border border-stone-700"
                  >
                    Quick Guest Demo (VIP)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setEnteredPin(hostPin);
                      setAuthRole("host");
                    }}
                    className="flex-1 py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-amber-300 text-xs font-semibold border border-stone-700"
                  >
                    Quick Host Demo
                  </button>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-sm shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center gap-2"
                >
                  <Unlock className="w-4 h-4" />
                  <span>Verify Security Access</span>
                </button>
              </form>

              <div className="text-[11px] text-stone-500 bg-stone-900/50 p-3 rounded-xl border border-stone-800 text-left space-y-1">
                <div>🔑 <strong>Host Admin PIN:</strong> <code className="text-amber-400">{hostPin}</code></div>
                <div>🎟️ <strong>Guest Passcode:</strong> <code className="text-sky-400">{guestCode}</code></div>
              </div>
            </div>
          ) : (
            /* AUTHENTICATED CONTENT */
            <div className="space-y-6">
              {/* Top Row: QR Code & Sharing Banner */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 bg-stone-950/60 border border-stone-800 rounded-2xl p-5 items-center">
                {/* QR Code Preview */}
                <div className="md:col-span-4 flex flex-col items-center justify-center p-3 bg-white rounded-2xl shadow-xl">
                  {qrDataUrl ? (
                    <img
                      src={qrDataUrl}
                      alt="Party Memory Share QR Code"
                      className="w-44 h-44 object-contain rounded-lg"
                    />
                  ) : (
                    <div className="w-44 h-44 bg-stone-100 flex items-center justify-center text-stone-500 text-xs">
                      Generating QR Code...
                    </div>
                  )}
                  <span className="text-[11px] font-bold text-stone-800 mt-1 uppercase tracking-wider">
                    Scan with Phone Camera
                  </span>
                </div>

                {/* Share Link & Security Keys Details */}
                <div className="md:col-span-8 space-y-3">
                  <div>
                    <h3 className="text-base font-bold text-stone-100 flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      Live Party Memory Wall for {currentPlan.name}
                    </h3>
                    <p className="text-xs text-stone-400 mt-1 leading-relaxed">
                      Guests can scan this QR code directly at your party table or bar to upload live snapshots, share funny moments, or toast the host.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <div className="text-xs font-semibold text-stone-400">Shareable Memory Link:</div>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        readOnly
                        value={shareLink}
                        className="flex-1 bg-stone-900 border border-stone-700 rounded-xl px-3 py-2 text-xs font-mono text-stone-300 select-all"
                      />
                      <button
                        type="button"
                        onClick={handleCopyLink}
                        className="px-3 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs flex items-center gap-1.5 transition-colors"
                      >
                        {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedLink ? "Copied" : "Copy Link"}</span>
                      </button>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 pt-1">
                    <div className="text-xs px-2.5 py-1 rounded-lg bg-stone-900 text-stone-300 border border-stone-800">
                      Host PIN: <strong className="text-amber-400">{hostPin}</strong>
                    </div>
                    <div className="text-xs px-2.5 py-1 rounded-lg bg-stone-900 text-stone-300 border border-stone-800">
                      Guest Pass: <strong className="text-sky-400">{guestCode}</strong>
                    </div>
                    {qrDataUrl && (
                      <a
                        href={qrDataUrl}
                        download={`cymbalmart-${currentPlan.id}-qr-memories.png`}
                        className="text-xs px-3 py-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-700 flex items-center gap-1 transition-colors ml-auto"
                      >
                        <Download className="w-3 h-3 text-emerald-400" />
                        <span>Download QR for Printing</span>
                      </a>
                    )}
                  </div>
                </div>
              </div>

              {/* Upload / Share Memory Form */}
              <form onSubmit={handleAddMemory} className="bg-stone-950/80 border border-stone-800 rounded-2xl p-4 sm:p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-stone-200 flex items-center gap-2">
                    <Camera className="w-4 h-4 text-sky-400" />
                    <span>Upload Party Memory or Toast</span>
                  </h4>
                  <div className="flex items-center gap-1">
                    {(["photo", "toast", "highlight", "memory"] as const).map((cat) => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setSelectedCategory(cat)}
                        className={`text-[11px] px-2.5 py-1 rounded-lg capitalize transition-colors ${
                          selectedCategory === cat
                            ? "bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold"
                            : "bg-stone-900 text-stone-400 border border-stone-800 hover:text-stone-300"
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-stone-400 mb-1">Your Name / Nickname</label>
                    <input
                      type="text"
                      value={authorName}
                      onChange={(e) => setAuthorName(e.target.value)}
                      placeholder={authRole === "host" ? "Party Host Name" : "Guest Name (e.g. Jessica)"}
                      className="w-full bg-stone-900 border border-stone-700 rounded-xl px-3 py-2 text-sm text-stone-100 focus:outline-none focus:border-amber-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-400 mb-1">Add Photo (Optional)</label>
                    <div className="flex gap-2">
                      <input
                        type="file"
                        ref={fileInputRef}
                        accept="image/*"
                        onChange={handlePhotoUpload}
                        className="hidden"
                        id="memory-photo-file-input"
                      />
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="flex-1 py-2 px-3 rounded-xl bg-stone-900 hover:bg-stone-800 text-stone-300 border border-stone-700 text-xs flex items-center justify-center gap-1.5 transition-colors"
                      >
                        <UploadCloud className="w-3.5 h-3.5 text-sky-400" />
                        <span>{selectedPhoto ? "Change Selected Photo" : "Upload From Device"}</span>
                      </button>
                      {selectedPhoto && (
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedPhoto(null);
                            if (fileInputRef.current) fileInputRef.current.value = "";
                          }}
                          className="px-2.5 rounded-xl bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs"
                        >
                          Clear
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Photo Preview if chosen */}
                {selectedPhoto && (
                  <div className="relative w-32 h-24 rounded-xl overflow-hidden border border-amber-500/40 shadow-md">
                    <img src={selectedPhoto} alt="Preview" className="w-full h-full object-cover" />
                    <span className="absolute bottom-1 right-1 text-[9px] bg-stone-950/80 px-1 rounded text-amber-300 font-bold">
                      Attached
                    </span>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-stone-400 mb-1">Toast / Message / Memory Note</label>
                  <textarea
                    rows={2}
                    value={memoryNote}
                    onChange={(e) => setMemoryNote(e.target.value)}
                    placeholder="Write a warm toast, praise the host's slider buffet, or caption this photo..."
                    className="w-full bg-stone-900 border border-stone-700 rounded-xl px-3 py-2 text-sm text-stone-100 placeholder-stone-500 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-stone-950 font-bold text-sm shadow-lg shadow-amber-500/20 transition-all flex items-center gap-1.5"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>Post Memory to Wall</span>
                  </button>
                </div>
              </form>

              {/* Memory Wall Feed */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-stone-300 flex items-center gap-2">
                    <Users className="w-4 h-4 text-amber-400" />
                    <span>Live Memories & Toasts ({memories.length})</span>
                  </h4>
                  <span className="text-xs text-stone-500">Real-time Host & Guest Feed</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {memories.map((mem) => (
                    <div
                      key={mem.id}
                      className="bg-stone-950 border border-stone-800/90 rounded-2xl overflow-hidden shadow-lg hover:border-stone-700 transition-colors flex flex-col justify-between"
                    >
                      {mem.imageUrl && (
                        <div className="relative h-48 w-full bg-stone-900 overflow-hidden">
                          <img
                            src={mem.imageUrl}
                            alt="Party Moment"
                            className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                          />
                          <span className="absolute top-2 right-2 text-[10px] px-2 py-0.5 rounded-full bg-stone-950/80 backdrop-blur-sm text-stone-200 border border-stone-700 uppercase font-bold">
                            {mem.category || "photo"}
                          </span>
                        </div>
                      )}

                      <div className="p-4 space-y-2 flex-1 flex flex-col justify-between">
                        <div>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-sm text-stone-200">{mem.authorName}</span>
                              <span
                                className={`text-[10px] px-1.5 py-0.2 rounded font-semibold uppercase ${
                                  mem.role === "host"
                                    ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                                    : "bg-sky-500/20 text-sky-300 border border-sky-500/30"
                                }`}
                              >
                                {mem.role}
                              </span>
                            </div>
                            <span className="text-[10px] text-stone-500">{mem.timestamp}</span>
                          </div>

                          <p className="text-xs text-stone-300 mt-2 leading-relaxed italic">
                            "{mem.note}"
                          </p>
                        </div>

                        <div className="flex items-center justify-between pt-3 border-t border-stone-800/80 mt-3">
                          <button
                            type="button"
                            onClick={() => handleLike(mem.id)}
                            className="flex items-center gap-1.5 text-xs text-stone-400 hover:text-rose-400 transition-colors"
                          >
                            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500/20" />
                            <span>{mem.likes} Likes</span>
                          </button>

                          {authRole === "host" && (
                            <button
                              type="button"
                              onClick={() => handleDelete(mem.id)}
                              className="text-stone-500 hover:text-rose-400 p-1 transition-colors"
                              title="Delete Memory (Host Only)"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
