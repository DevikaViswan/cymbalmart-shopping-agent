import React, { useState } from "react";
import {
  X,
  CheckCircle2,
  Circle,
  Store,
  ArrowLeft,
  DollarSign,
  Sparkles,
  ShoppingBag,
  Eye,
  EyeOff,
  Filter,
} from "lucide-react";
import { PartyPlan, ShoppingItem, StoreType } from "../types";
import { CATEGORY_DEFINITIONS } from "../utils/categoryHelpers";
import confetti from "canvas-confetti";

interface MobileShoppingModeProps {
  plan: PartyPlan;
  onClose: () => void;
  onToggleItem: (id: string) => void;
}

export const MobileShoppingMode: React.FC<MobileShoppingModeProps> = ({
  plan,
  onClose,
  onToggleItem,
}) => {
  const [selectedStore, setSelectedStore] = useState<string>("all");
  const [hideCompleted, setHideCompleted] = useState<boolean>(false);

  // Group items by store
  const storeMap: Record<string, ShoppingItem[]> = {};
  plan.items.forEach((item) => {
    const s = item.storeType || "Supermarket / Grocery";
    if (!storeMap[s]) storeMap[s] = [];
    storeMap[s].push(item);
  });

  const totalItems = plan.items.length;
  const checkedItems = plan.items.filter((i) => i.checked).length;
  const progressPercent = totalItems > 0 ? Math.round((checkedItems / totalItems) * 100) : 0;

  const handleToggle = (id: string, currentChecked: boolean) => {
    onToggleItem(id);
    if (!currentChecked) {
      const remaining = plan.items.filter((i) => !i.checked && i.id !== id);
      if (remaining.length === 0) {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.5 },
        });
      }
    }
  };

  const storesList = Object.keys(storeMap);

  return (
    <div className="fixed inset-0 z-50 bg-stone-950 text-stone-100 flex flex-col overflow-hidden">
      {/* Top Header */}
      <div className="bg-stone-900 border-b border-stone-800 px-4 py-3.5 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-stone-800 text-stone-300 hover:text-white"
            title="Back to planner"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-base font-bold text-stone-100 font-display truncate max-w-[200px] sm:max-w-md">
              In-Store Shopping Mode
            </h2>
            <p className="text-xs text-stone-400">
              {checkedItems} of {totalItems} items in cart ({progressPercent}%)
            </p>
          </div>
        </div>

        <button
          onClick={() => setHideCompleted(!hideCompleted)}
          className={`px-3 py-1.5 rounded-xl border text-xs font-medium flex items-center gap-1.5 transition-colors ${
            hideCompleted
              ? "bg-amber-500/20 text-amber-300 border-amber-500/40"
              : "bg-stone-800 text-stone-300 border-stone-700"
          }`}
        >
          {hideCompleted ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
          <span className="hidden sm:inline">
            {hideCompleted ? "Show Done" : "Hide Done"}
          </span>
        </button>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-stone-900 h-1.5 relative overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-amber-500 to-emerald-500 transition-all duration-300"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      {/* Store Filter Tabs */}
      <div className="bg-stone-900/80 px-4 py-2 border-b border-stone-800 flex items-center gap-2 overflow-x-auto scrollbar-none">
        <button
          onClick={() => setSelectedStore("all")}
          className={`flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
            selectedStore === "all"
              ? "bg-amber-500 text-stone-950"
              : "bg-stone-800 text-stone-400 hover:text-stone-200"
          }`}
        >
          All Stores ({totalItems})
        </button>
        {storesList.map((storeName) => {
          const count = storeMap[storeName].length;
          const doneCount = storeMap[storeName].filter((i) => i.checked).length;

          return (
            <button
              key={storeName}
              onClick={() => setSelectedStore(storeName)}
              className={`flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                selectedStore === storeName
                  ? "bg-amber-500 text-stone-950"
                  : "bg-stone-800 text-stone-400 hover:text-stone-200"
              }`}
            >
              <span>{storeName.split("/")[0].trim()}</span>
              <span className="text-[10px] opacity-75">
                ({doneCount}/{count})
              </span>
            </button>
          );
        })}
      </div>

      {/* Content Checklist */}
      <div className="flex-1 overflow-y-auto p-4 space-y-5 max-w-3xl mx-auto w-full">
        {storesList
          .filter((st) => selectedStore === "all" || selectedStore === st)
          .map((storeName) => {
            const items = storeMap[storeName] || [];
            const displayItems = hideCompleted ? items.filter((i) => !i.checked) : items;

            if (displayItems.length === 0 && hideCompleted) {
              return null;
            }

            return (
              <div
                key={storeName}
                className="bg-stone-900 border border-stone-800 rounded-2xl overflow-hidden shadow-md"
              >
                {/* Store Header */}
                <div className="px-4 py-3 bg-stone-800/80 border-b border-stone-700/80 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Store className="w-4 h-4 text-amber-400" />
                    <h3 className="text-sm font-bold text-stone-100 font-display">{storeName}</h3>
                  </div>
                  <span className="text-xs text-stone-400">
                    {items.filter((i) => i.checked).length}/{items.length} items checked
                  </span>
                </div>

                {/* Items in Store */}
                <div className="divide-y divide-stone-800">
                  {displayItems.map((item) => {
                    const meta = CATEGORY_DEFINITIONS[item.category];

                    return (
                      <div
                        key={item.id}
                        onClick={() => handleToggle(item.id, item.checked)}
                        className={`p-4 flex items-center justify-between gap-4 cursor-pointer select-none transition-colors active:bg-stone-800/70 ${
                          item.checked ? "bg-stone-950/60 opacity-60" : "hover:bg-stone-800/40"
                        }`}
                      >
                        <div className="flex items-start gap-3.5 flex-1 min-w-0">
                          <div className="mt-0.5 flex-shrink-0">
                            {item.checked ? (
                              <CheckCircle2 className="w-6 h-6 text-emerald-400 fill-emerald-400/20" />
                            ) : (
                              <Circle className="w-6 h-6 text-stone-500" />
                            )}
                          </div>

                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <span
                                className={`text-base font-medium ${
                                  item.checked ? "line-through text-stone-400" : "text-stone-100"
                                }`}
                              >
                                {item.name}
                              </span>

                              <span className="text-xs font-bold px-2 py-0.5 rounded bg-stone-800 text-amber-300 border border-stone-700">
                                {item.quantity} {item.unit}
                              </span>
                            </div>

                            {(item.notesOrBrand || item.substitutionAdvice) && (
                              <p className="text-xs text-stone-400 mt-1 line-clamp-1">
                                {item.notesOrBrand || item.substitutionAdvice}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Price Tag */}
                        <div className="text-right flex-shrink-0">
                          <div className="text-sm font-bold text-stone-300">
                            ${item.estimatedPriceMin}
                            {item.estimatedPriceMax && item.estimatedPriceMax !== item.estimatedPriceMin
                              ? ` - $${item.estimatedPriceMax}`
                              : ""}
                          </div>
                          <span className={`text-[10px] ${meta?.colorClass || "text-stone-400"}`}>
                            {meta?.shortLabel || item.category}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}

        {progressPercent === 100 && (
          <div className="p-8 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 text-center space-y-2 my-4">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
            <h3 className="text-lg font-bold text-emerald-200 font-display">
              All Items Purchased!
            </h3>
            <p className="text-xs text-emerald-400/80">
              Your party cart is 100% complete and ready for celebration prep.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
