import React, { useState } from "react";
import {
  Search,
  Filter,
  Plus,
  Minus,
  Sparkles,
  CheckCircle2,
  Circle,
  Trash2,
  Edit2,
  ChevronDown,
  ChevronUp,
  Tag,
  Store,
  HelpCircle,
  Check,
  RotateCcw,
  SlidersHorizontal,
  DollarSign,
  Info,
  TrendingDown,
  TrendingUp,
  ShieldAlert,
  Tent,
} from "lucide-react";
import { ShoppingItem, ItemCategory, StoreType, ItemPriority, PartyPlan } from "../types";
import { CATEGORY_DEFINITIONS, STORE_TYPE_OPTIONS } from "../utils/categoryHelpers";
import confetti from "canvas-confetti";

interface ShoppingListViewProps {
  plan: PartyPlan;
  onToggleItem: (id: string) => void;
  onDeleteItem: (id: string) => void;
  onAddItem: (item: ShoppingItem) => void;
  onUpdateItem: (item: ShoppingItem) => void;
  onBulkCheck: (checked: boolean) => void;
}

export const ShoppingListView: React.FC<ShoppingListViewProps> = ({
  plan,
  onToggleItem,
  onDeleteItem,
  onAddItem,
  onUpdateItem,
  onBulkCheck,
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<ItemCategory | "all">("all");
  const [selectedStore, setSelectedStore] = useState<StoreType | "all">("all");
  const [statusFilter, setStatusFilter] = useState<"all" | "pending" | "completed">("all");
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});

  // Inline Quick Add state
  const [quickAddName, setQuickAddName] = useState("");
  const [quickAddCategory, setQuickAddCategory] = useState<ItemCategory>("snacks-sweets");
  const [isAiSuggesting, setIsAiSuggesting] = useState(false);
  const [editingItemId, setEditingItemId] = useState<string | null>(null);

  // Edit item form state
  const [editFormData, setEditFormData] = useState<Partial<ShoppingItem>>({});

  // Filter items
  const filteredItems = plan.items.filter((item) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = item.name.toLowerCase().includes(q);
      const matchNotes = (item.notesOrBrand || "").toLowerCase().includes(q);
      const matchStore = (item.storeType || "").toLowerCase().includes(q);
      if (!matchName && !matchNotes && !matchStore) return false;
    }

    if (selectedCategory !== "all" && item.category !== selectedCategory) {
      return false;
    }

    if (selectedStore !== "all" && item.storeType !== selectedStore) {
      return false;
    }

    if (statusFilter === "pending" && item.checked) return false;
    if (statusFilter === "completed" && !item.checked) return false;

    return true;
  });

  // Group items by category
  const groupedByCategory: Record<ItemCategory, ShoppingItem[]> = {} as any;
  filteredItems.forEach((item) => {
    if (!groupedByCategory[item.category]) {
      groupedByCategory[item.category] = [];
    }
    groupedByCategory[item.category].push(item);
  });

  const toggleCategoryExpand = (cat: string) => {
    setExpandedCategories((prev) => ({
      ...prev,
      [cat]: prev[cat] === undefined ? false : !prev[cat],
    }));
  };

  const handleToggle = (id: string, currentChecked: boolean) => {
    onToggleItem(id);
    if (!currentChecked) {
      // Check if all items are now checked
      const remainingUnchecked = plan.items.filter((i) => !i.checked && i.id !== id);
      if (remainingUnchecked.length === 0) {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      }
    }
  };

  const handleAdjustQuantity = (item: ShoppingItem, delta: number) => {
    const currentQty = item.quantity || 1;
    const newQty = Math.max(1, Math.round((currentQty + delta) * 10) / 10);
    if (newQty === currentQty) return;
    const ratio = newQty / currentQty;
    const updatedItem: ShoppingItem = {
      ...item,
      quantity: newQty,
      estimatedPriceMin: Math.max(1, Math.round(item.estimatedPriceMin * ratio * 100) / 100),
      estimatedPriceMax: Math.max(1, Math.round((item.estimatedPriceMax || item.estimatedPriceMin) * ratio * 100) / 100),
    };
    onUpdateItem(updatedItem);
  };

  const handleAiSmartSuggest = async () => {
    if (!quickAddName.trim()) return;
    setIsAiSuggesting(true);

    try {
      const res = await fetch("/api/agent/suggest-item", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: quickAddName,
          partyTheme: plan.theme,
          guestCount: plan.guestCount.total,
        }),
      });

      const data = await res.json();
      const newItem: ShoppingItem = {
        id: `item-${Date.now()}`,
        name: data.name || quickAddName,
        category: data.category || quickAddCategory,
        quantity: data.quantity || 1,
        unit: data.unit || "pack",
        estimatedPriceMin: data.estimatedPriceMin || 5,
        estimatedPriceMax: data.estimatedPriceMax || 10,
        storeType: data.storeType || "Supermarket / Grocery",
        dietaryTags: data.dietaryTags || [],
        isPerishable: data.isPerishable ?? false,
        priority: data.priority || "recommended",
        checked: false,
        notesOrBrand: data.notesOrBrand || "",
        substitutionAdvice: data.substitutionAdvice || "",
      };

      onAddItem(newItem);
      setQuickAddName("");
    } catch (error) {
      console.error("AI suggest error:", error);
      // Fallback add
      onAddItem({
        id: `item-${Date.now()}`,
        name: quickAddName,
        category: quickAddCategory,
        quantity: 1,
        unit: "pack",
        estimatedPriceMin: 5,
        estimatedPriceMax: 10,
        storeType: "Supermarket / Grocery",
        dietaryTags: [],
        isPerishable: false,
        priority: "recommended",
        checked: false,
      });
      setQuickAddName("");
    } finally {
      setIsAiSuggesting(false);
    }
  };

  const handleManualQuickAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickAddName.trim()) return;

    onAddItem({
      id: `item-${Date.now()}`,
      name: quickAddName,
      category: quickAddCategory,
      quantity: 1,
      unit: "pack",
      estimatedPriceMin: 4,
      estimatedPriceMax: 8,
      storeType: "Supermarket / Grocery",
      dietaryTags: [],
      isPerishable: false,
      priority: "recommended",
      checked: false,
    });
    setQuickAddName("");
  };

  const startEditing = (item: ShoppingItem) => {
    setEditingItemId(item.id);
    setEditFormData({ ...item });
  };

  const saveEditing = () => {
    if (editingItemId && editFormData) {
      onUpdateItem(editFormData as ShoppingItem);
      setEditingItemId(null);
    }
  };

  const totalItemsCount = plan.items.length;
  const completedCount = plan.items.filter((i) => i.checked).length;
  const budgetSpentAvg = (plan.budgetAnalysis.totalEstimatedCostMin + plan.budgetAnalysis.totalEstimatedCostMax) / 2;
  const percentBudgetUsed = Math.min(100, Math.round((budgetSpentAvg / Math.max(1, plan.budgetLimit)) * 100));

  return (
    <div className="space-y-4">
      {/* Live Recalculated Budget Summary Bar */}
      <div className="bg-gradient-to-r from-stone-900 via-stone-900 to-amber-950/20 border border-stone-800 rounded-2xl p-4 shadow-lg">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-stone-400">Live Auto-Recalculated Budget</span>
              <span
                className={`text-[11px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                  plan.budgetAnalysis.budgetStatus === "under"
                    ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                    : plan.budgetAnalysis.budgetStatus === "on-target"
                    ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                    : "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                }`}
              >
                {plan.budgetAnalysis.budgetStatus === "under"
                  ? "Under Budget"
                  : plan.budgetAnalysis.budgetStatus === "on-target"
                  ? "On Target"
                  : "Over Budget"}
              </span>
            </div>

            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl sm:text-3xl font-extrabold text-stone-100 font-display">
                ${plan.budgetAnalysis.totalEstimatedCostMin} – ${plan.budgetAnalysis.totalEstimatedCostMax}
              </span>
              <span className="text-xs text-stone-400">
                of <strong className="text-amber-300 font-bold">${plan.budgetLimit}</strong> target limit
              </span>
              <span className="text-xs text-stone-400 ml-2 hidden sm:inline">
                (~${plan.budgetAnalysis.costPerGuest}/guest across {plan.guestCount.total} guests)
              </span>
            </div>
          </div>

          {/* Quick Stats & Progress */}
          <div className="w-full md:w-64 space-y-1.5">
            <div className="flex justify-between text-xs text-stone-400">
              <span>Budget Allocation</span>
              <span className="font-bold text-amber-300">{percentBudgetUsed}% Used</span>
            </div>
            <div className="w-full h-2 rounded-full bg-stone-800 overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-300 ${
                  percentBudgetUsed > 100
                    ? "bg-rose-500"
                    : percentBudgetUsed > 85
                    ? "bg-amber-500"
                    : "bg-emerald-500"
                }`}
                style={{ width: `${Math.min(100, percentBudgetUsed)}%` }}
              />
            </div>
            <div className="text-[11px] text-stone-400 text-right">
              {plan.budgetLimit >= plan.budgetAnalysis.totalEstimatedCostMax ? (
                <span className="text-emerald-400 font-medium">
                  +${plan.budgetLimit - plan.budgetAnalysis.totalEstimatedCostMax} buffer remaining
                </span>
              ) : (
                <span className="text-rose-400 font-medium">
                  ${plan.budgetAnalysis.totalEstimatedCostMin - plan.budgetLimit} over limit
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
      {/* Search & Filter Toolbar */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 shadow-lg space-y-3">
        <div className="flex flex-col md:flex-row items-center gap-3">
          {/* Search Input */}
          <div className="relative w-full md:flex-1">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search items, brands, notes or stores..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-stone-800 border border-stone-700 text-stone-100 placeholder-stone-400 focus:outline-none focus:border-amber-500 text-sm"
              id="input-search-items"
            />
          </div>

          {/* Status Tabs */}
          <div className="flex items-center gap-1 bg-stone-950/70 p-1 rounded-xl border border-stone-800 w-full md:w-auto">
            <button
              onClick={() => setStatusFilter("all")}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                statusFilter === "all"
                  ? "bg-amber-500/20 text-amber-300 font-semibold"
                  : "text-stone-400 hover:text-stone-200"
              }`}
            >
              All ({totalItemsCount})
            </button>
            <button
              onClick={() => setStatusFilter("pending")}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                statusFilter === "pending"
                  ? "bg-amber-500/20 text-amber-300 font-semibold"
                  : "text-stone-400 hover:text-stone-200"
              }`}
            >
              To Buy ({totalItemsCount - completedCount})
            </button>
            <button
              onClick={() => setStatusFilter("completed")}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                statusFilter === "completed"
                  ? "bg-emerald-500/20 text-emerald-300 font-semibold"
                  : "text-stone-400 hover:text-stone-200"
              }`}
            >
              Purchased ({completedCount})
            </button>
          </div>

          {/* Bulk Actions Menu */}
          <div className="flex items-center gap-1.5 self-end md:self-auto">
            <button
              onClick={() => onBulkCheck(true)}
              className="px-2.5 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 border border-stone-700 text-xs text-stone-300 hover:text-white transition-colors"
              title="Check all items"
            >
              Check All
            </button>
            <button
              onClick={() => onBulkCheck(false)}
              className="px-2.5 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 border border-stone-700 text-xs text-stone-300 hover:text-white transition-colors"
              title="Uncheck all items"
            >
              Reset
            </button>
          </div>
        </div>

        {/* Filter Dropdowns / Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none pt-1">
          <span className="text-xs text-stone-400 font-medium flex items-center gap-1 flex-shrink-0">
            <SlidersHorizontal className="w-3.5 h-3.5 text-stone-400" />
            Filter:
          </span>

          {/* Category Selector */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value as any)}
            className="px-2.5 py-1 rounded-lg bg-stone-800 border border-stone-700 text-xs text-stone-300 focus:outline-none focus:border-amber-500"
          >
            <option value="all">All Categories</option>
            {Object.entries(CATEGORY_DEFINITIONS).map(([key, val]) => (
              <option key={key} value={key}>
                {val.label}
              </option>
            ))}
          </select>

          {/* Store Selector */}
          <select
            value={selectedStore}
            onChange={(e) => setSelectedStore(e.target.value as any)}
            className="px-2.5 py-1 rounded-lg bg-stone-800 border border-stone-700 text-xs text-stone-300 focus:outline-none focus:border-amber-500"
          >
            <option value="all">All Stores</option>
            {STORE_TYPE_OPTIONS.map((st) => (
              <option key={st} value={st}>
                {st}
              </option>
            ))}
          </select>

          {/* Reset Filters button if active */}
          {(selectedCategory !== "all" || selectedStore !== "all" || searchQuery) && (
            <button
              onClick={() => {
                setSelectedCategory("all");
                setSelectedStore("all");
                setSearchQuery("");
              }}
              className="text-xs text-amber-400 hover:text-amber-300 underline underline-offset-2 ml-auto flex-shrink-0"
            >
              Clear filters
            </button>
          )}
        </div>
      </div>

      {/* Quick Add Bar with AI auto-fill */}
      <div className="bg-gradient-to-r from-stone-900 via-stone-900 to-amber-950/30 border border-stone-800 rounded-2xl p-3.5 shadow-md">
        <form onSubmit={handleManualQuickAdd} className="flex flex-col sm:flex-row items-center gap-2">
          <div className="relative flex-1 w-full">
            <input
              type="text"
              value={quickAddName}
              onChange={(e) => setQuickAddName(e.target.value)}
              placeholder="Add item (e.g. Sriracha Mayo, Jalapeño Chips, Prosecco, Eco Napkins)..."
              className="w-full px-3.5 py-2 rounded-xl bg-stone-800/90 border border-stone-700 text-stone-100 placeholder-stone-400 focus:outline-none focus:border-amber-500 text-xs sm:text-sm"
              id="input-quick-add-item"
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <select
              value={quickAddCategory}
              onChange={(e) => setQuickAddCategory(e.target.value as ItemCategory)}
              className="px-2.5 py-2 rounded-xl bg-stone-800 border border-stone-700 text-xs text-stone-300 focus:outline-none focus:border-amber-500 flex-1 sm:flex-initial"
            >
              {Object.entries(CATEGORY_DEFINITIONS).map(([k, v]) => (
                <option key={k} value={k}>
                  {v.shortLabel}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={handleAiSmartSuggest}
              disabled={!quickAddName.trim() || isAiSuggesting}
              className="px-3 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-semibold flex items-center gap-1.5 transition-all disabled:opacity-40"
              title="AI auto-fills portion size, price & store"
              id="btn-ai-suggest-item"
            >
              {isAiSuggesting ? (
                <div className="w-3.5 h-3.5 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
              ) : (
                <Sparkles className="w-3.5 h-3.5" />
              )}
              <span className="hidden sm:inline">AI Fill & Add</span>
            </button>

            <button
              type="submit"
              disabled={!quickAddName.trim()}
              className="px-3 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-700 text-xs font-medium flex items-center gap-1 transition-all disabled:opacity-40"
            >
              <Plus className="w-4 h-4" />
              <span>Add</span>
            </button>
          </div>
        </form>
      </div>

      {/* Categorized Item Accordions */}
      {Object.keys(groupedByCategory).length === 0 ? (
        <div className="bg-stone-900/60 border border-stone-800 rounded-2xl p-12 text-center">
          <div className="w-12 h-12 rounded-2xl bg-stone-800 flex items-center justify-center text-stone-400 mx-auto mb-3">
            <Search className="w-6 h-6" />
          </div>
          <h4 className="text-base font-bold text-stone-200 font-display">No shopping items found</h4>
          <p className="text-xs text-stone-400 mt-1 max-w-md mx-auto">
            Try adjusting your search filter, or use the bar above or the AI Agent to add items to your list.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {Object.entries(groupedByCategory).map(([catKey, items]) => {
            const meta = CATEGORY_DEFINITIONS[catKey as ItemCategory] || {
              label: catKey,
              colorClass: "text-stone-300",
              borderClass: "border-stone-700",
              bgLightClass: "bg-stone-800",
            };

            const isCollapsed = expandedCategories[catKey] === false;
            const checkedCount = items.filter((i) => i.checked).length;
            const catSubtotalMin = items.reduce((acc, i) => acc + (i.estimatedPriceMin || 0), 0);
            const catSubtotalMax = items.reduce((acc, i) => acc + (i.estimatedPriceMax || i.estimatedPriceMin || 0), 0);

            return (
              <div
                key={catKey}
                className="bg-stone-900 border border-stone-800 rounded-2xl overflow-hidden shadow-sm transition-all"
              >
                {/* Category Header Bar */}
                <div
                  onClick={() => toggleCategoryExpand(catKey)}
                  className="px-4 py-3.5 bg-stone-900/80 hover:bg-stone-800/60 flex items-center justify-between cursor-pointer select-none border-b border-stone-800/60 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <span className={`w-2.5 h-2.5 rounded-full ${meta.bgLightClass} border ${meta.borderClass}`} />
                    <span className={`text-sm font-bold font-display ${meta.colorClass}`}>
                      {meta.label}
                    </span>
                    <span className="text-xs text-stone-400 font-medium">
                      ({checkedCount}/{items.length})
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-xs font-semibold text-stone-300">
                      ${catSubtotalMin} - ${catSubtotalMax}
                    </span>
                    <div className="text-stone-400">
                      {isCollapsed ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
                    </div>
                  </div>
                </div>

                {/* Items List */}
                {!isCollapsed && (
                  <div className="divide-y divide-stone-800/60">
                    {items.map((item) => {
                      const isEditing = editingItemId === item.id;

                      if (isEditing) {
                        return (
                          <div key={item.id} className="p-4 bg-stone-950/60 space-y-3">
                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                              <input
                                type="text"
                                value={editFormData.name || ""}
                                onChange={(e) => setEditFormData({ ...editFormData, name: e.target.value })}
                                className="px-3 py-1.5 rounded-lg bg-stone-800 border border-stone-700 text-xs text-stone-100 sm:col-span-2"
                                placeholder="Item name"
                              />
                              <div className="flex items-center gap-1.5">
                                <input
                                  type="number"
                                  min="0.1"
                                  step="0.5"
                                  value={editFormData.quantity || 1}
                                  onChange={(e) =>
                                    setEditFormData({ ...editFormData, quantity: parseFloat(e.target.value) || 1 })
                                  }
                                  className="w-16 px-2 py-1.5 rounded-lg bg-stone-800 border border-stone-700 text-xs text-stone-100 text-center"
                                />
                                <input
                                  type="text"
                                  value={editFormData.unit || ""}
                                  onChange={(e) => setEditFormData({ ...editFormData, unit: e.target.value })}
                                  className="w-24 px-2 py-1.5 rounded-lg bg-stone-800 border border-stone-700 text-xs text-stone-100"
                                  placeholder="unit (e.g. lbs, packs)"
                                />
                              </div>
                            </div>

                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                              <div>
                                <label className="text-[10px] text-stone-400 block mb-0.5">Est. Min ($)</label>
                                <input
                                  type="number"
                                  value={editFormData.estimatedPriceMin || 0}
                                  onChange={(e) =>
                                    setEditFormData({ ...editFormData, estimatedPriceMin: parseFloat(e.target.value) || 0 })
                                  }
                                  className="w-full px-2.5 py-1.5 rounded-lg bg-stone-800 border border-stone-700 text-xs text-stone-100"
                                />
                              </div>
                              <div>
                                <label className="text-[10px] text-stone-400 block mb-0.5">Est. Max ($)</label>
                                <input
                                  type="number"
                                  value={editFormData.estimatedPriceMax || 0}
                                  onChange={(e) =>
                                    setEditFormData({ ...editFormData, estimatedPriceMax: parseFloat(e.target.value) || 0 })
                                  }
                                  className="w-full px-2.5 py-1.5 rounded-lg bg-stone-800 border border-stone-700 text-xs text-stone-100"
                                />
                              </div>
                              <div className="col-span-2">
                                <label className="text-[10px] text-stone-400 block mb-0.5">Store / Market</label>
                                <select
                                  value={editFormData.storeType || "Supermarket / Grocery"}
                                  onChange={(e) =>
                                    setEditFormData({ ...editFormData, storeType: e.target.value as StoreType })
                                  }
                                  className="w-full px-2.5 py-1.5 rounded-lg bg-stone-800 border border-stone-700 text-xs text-stone-100"
                                >
                                  {STORE_TYPE_OPTIONS.map((s) => (
                                    <option key={s} value={s}>
                                      {s}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            </div>

                            <div>
                              <input
                                type="text"
                                value={editFormData.notesOrBrand || ""}
                                onChange={(e) =>
                                  setEditFormData({ ...editFormData, notesOrBrand: e.target.value })
                                }
                                placeholder="Brand recommendation or notes..."
                                className="w-full px-3 py-1.5 rounded-lg bg-stone-800 border border-stone-700 text-xs text-stone-100 placeholder-stone-400"
                              />
                            </div>

                            <div className="flex items-center justify-end gap-2 pt-1">
                              <button
                                type="button"
                                onClick={() => setEditingItemId(null)}
                                className="px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs"
                              >
                                Cancel
                              </button>
                              <button
                                type="button"
                                onClick={saveEditing}
                                className="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs flex items-center gap-1"
                              >
                                <Check className="w-3.5 h-3.5" />
                                <span>Save</span>
                              </button>
                            </div>
                          </div>
                        );
                      }

                      return (
                        <div
                          key={item.id}
                          className={`p-3.5 sm:px-4 sm:py-3 flex items-center justify-between gap-3 transition-colors ${
                            item.checked ? "bg-stone-950/40 opacity-70" : "hover:bg-stone-800/40"
                          }`}
                        >
                          {/* Checkbox & Item Details */}
                          <div className="flex items-start gap-3 flex-1 min-w-0">
                            <button
                              type="button"
                              onClick={() => handleToggle(item.id, item.checked)}
                              className="mt-0.5 text-stone-400 hover:text-amber-400 transition-colors flex-shrink-0"
                              aria-label={item.checked ? "Mark as unpurchased" : "Mark as purchased"}
                            >
                              {item.checked ? (
                                <CheckCircle2 className="w-5 h-5 text-emerald-400 fill-emerald-400/20" />
                              ) : (
                                <Circle className="w-5 h-5 hover:text-amber-400" />
                              )}
                            </button>

                            <div className="min-w-0 flex-1">
                              <div className="flex flex-wrap items-center gap-2">
                                <span
                                  className={`text-sm font-medium ${
                                    item.checked ? "line-through text-stone-400" : "text-stone-100"
                                  }`}
                                >
                                  {item.name}
                                </span>

                                <div className="inline-flex items-center rounded-lg bg-stone-800 border border-stone-700/80 overflow-hidden shadow-inner">
                                  <button
                                    type="button"
                                    onClick={() => handleAdjustQuantity(item, -1)}
                                    className="px-1.5 py-0.5 text-stone-400 hover:text-amber-300 hover:bg-stone-700/50 transition-colors"
                                    title="Decrease quantity"
                                  >
                                    <Minus className="w-3 h-3" />
                                  </button>
                                  <span className="text-xs font-semibold px-2 py-0.5 text-amber-300">
                                    {item.quantity} {item.unit}
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => handleAdjustQuantity(item, 1)}
                                    className="px-1.5 py-0.5 text-stone-400 hover:text-amber-300 hover:bg-stone-700/50 transition-colors"
                                    title="Increase quantity"
                                  >
                                    <Plus className="w-3 h-3" />
                                  </button>
                                </div>

                                {item.priority === "must-have" && (
                                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-rose-500/15 text-rose-300 border border-rose-500/30">
                                    Must-Have
                                  </span>
                                )}

                                {item.dietaryTags && item.dietaryTags.length > 0 && (
                                  <div className="hidden sm:flex items-center gap-1">
                                    {item.dietaryTags.map((dt) => (
                                      <span
                                        key={dt}
                                        className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/20"
                                      >
                                        {dt}
                                      </span>
                                    ))}
                                  </div>
                                )}
                              </div>

                              {/* Brand/Notes and Substitution Advice */}
                              {(item.notesOrBrand || item.substitutionAdvice) && (
                                <div className="mt-1 flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3 text-xs text-stone-400">
                                  {item.notesOrBrand && (
                                    <span className="truncate">
                                      <span className="text-stone-400">Tip:</span> {item.notesOrBrand}
                                    </span>
                                  )}
                                  {item.substitutionAdvice && (
                                    <span className="text-amber-400/90 text-[11px] truncate">
                                      💡 Swap: {item.substitutionAdvice}
                                    </span>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Right: Store Pill, Price & Actions */}
                          <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
                            {/* Store Pill */}
                            <span className="hidden md:inline-flex items-center gap-1 text-[11px] px-2 py-1 rounded-lg bg-stone-800/80 text-stone-300 border border-stone-700/60 max-w-[140px] truncate">
                              <Store className="w-3 h-3 text-amber-400" />
                              <span className="truncate">{item.storeType}</span>
                            </span>

                            {/* Price */}
                            <div className="text-right">
                              <div className="text-xs sm:text-sm font-bold text-stone-200">
                                ${item.estimatedPriceMin}
                                {item.estimatedPriceMax && item.estimatedPriceMax !== item.estimatedPriceMin
                                  ? ` - $${item.estimatedPriceMax}`
                                  : ""}
                              </div>
                            </div>

                            {/* Edit & Delete Buttons */}
                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => startEditing(item)}
                                className="p-1.5 rounded-lg text-stone-400 hover:text-stone-200 hover:bg-stone-800 transition-colors"
                                title="Edit item"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => onDeleteItem(item.id)}
                                className="p-1.5 rounded-lg text-stone-400 hover:text-rose-400 hover:bg-stone-800 transition-colors"
                                title="Remove item"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
