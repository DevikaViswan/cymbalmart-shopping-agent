import React, { useState, useRef, useEffect } from "react";
import {
  Gift,
  Sparkles,
  Percent,
  Crown,
  ShoppingBag,
  Cake,
  Truck,
  Copy,
  Check,
  X,
  ExternalLink,
  Flame,
  CheckCircle2,
  PartyPopper,
} from "lucide-react";
import confetti from "canvas-confetti";
import { ScratchReward } from "../types";

interface ScratchGiftsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const DEFAULT_REWARDS: ScratchReward[] = [
  {
    id: "reward-1",
    title: "25% Off Next Party Booking",
    badge: "Host Special",
    provider: "CymbalMart",
    headline: "25% OFF PARTY CATERING",
    discountDescription: "Enjoy 25% discount on your next CymbalMart party booking, custom catering platter, or private event setup.",
    promoCode: "CYMBAL25PARTY",
    expiryDate: "Valid for 60 days",
    isScratched: false,
    terms: "Applies to orders over $50. Cannot be combined with other manufacturer coupons.",
    iconType: "percent",
    colorTheme: "from-amber-500 to-orange-600",
  },
  {
    id: "reward-2",
    title: "Flipkart Gift Voucher",
    badge: "Partner Reward",
    provider: "Flipkart",
    headline: "₹500 / $25 SHOPPING VOUCHER",
    discountDescription: "Redeemable across all Flipkart categories, electronics, fashion, party gear, and home essentials.",
    promoCode: "FLIP-GIFT-500",
    expiryDate: "Valid for 90 days",
    isScratched: false,
    terms: "Single-use voucher code. Add to Flipkart Gift Card balance at checkout.",
    iconType: "gift",
    colorTheme: "from-blue-600 to-cyan-500",
  },
  {
    id: "reward-3",
    title: "1 Month Free CymbalMart Plus",
    badge: "Free Subscription",
    provider: "CymbalPlus",
    headline: "1 MONTH FREE VIP MEMBERSHIP",
    discountDescription: "Unlimited free 1-hour grocery delivery, 5% cash back at checkout, and dedicated personal shopping agent support.",
    promoCode: "PLUS1MONTHFREE",
    expiryDate: "Valid for 30 days",
    isScratched: false,
    terms: "Renews at standard monthly rate unless cancelled in account settings.",
    iconType: "crown",
    colorTheme: "from-purple-600 to-pink-500",
  },
  {
    id: "reward-4",
    title: "Free Celebration Cake or Dessert",
    badge: "Sweet Surprise",
    provider: "BakeryVault",
    headline: "FREE CUSTOM BAKERY TREAT",
    discountDescription: "Claim a complimentary 8-inch custom decorated party cake or 2-dozen gourmet cupcakes with any grocery order.",
    promoCode: "SWEETCAKE2026",
    expiryDate: "Valid for 45 days",
    isScratched: false,
    terms: "Order 48 hours in advance for custom lettering and decoration.",
    iconType: "cake",
    colorTheme: "from-rose-500 to-amber-500",
  },
];

// Single Scratch Card Component with Canvas
const InteractiveScratchCard: React.FC<{
  reward: ScratchReward;
  onReveal: (id: string) => void;
}> = ({ reward, onReveal }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isScratched, setIsScratched] = useState(reward.isScratched);
  const [isDrawing, setIsDrawing] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (isScratched) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set canvas dimensions
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width || 320;
    canvas.height = rect.height || 180;

    // Draw metallic scratch overlay
    const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    gradient.addColorStop(0, "#d97706");
    gradient.addColorStop(0.3, "#fbbf24");
    gradient.addColorStop(0.7, "#f59e0b");
    gradient.addColorStop(1, "#b45309");

    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Add scratch texture / sparkle icons
    ctx.fillStyle = "rgba(255, 255, 255, 0.25)";
    ctx.font = "bold 14px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("✨ SCRATCH WITH MOUSE / TOUCH ✨", canvas.width / 2, canvas.height / 2 - 10);
    ctx.font = "12px sans-serif";
    ctx.fillText("Scratch to Reveal Prize!", canvas.width / 2, canvas.height / 2 + 15);
  }, [isScratched]);

  const scratch = (clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;

    ctx.globalCompositeOperation = "destination-out";
    ctx.beginPath();
    ctx.arc(x, y, 24, 0, Math.PI * 2);
    ctx.fill();

    // Check how much has been cleared
    try {
      const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      let transparentPixels = 0;
      for (let i = 3; i < imgData.data.length; i += 4) {
        if (imgData.data[i] === 0) transparentPixels++;
      }
      const percent = (transparentPixels / (imgData.data.length / 4)) * 100;
      if (percent > 40 && !isScratched) {
        revealPrize();
      }
    } catch (e) {}
  };

  const revealPrize = () => {
    setIsScratched(true);
    onReveal(reward.id);
    confetti({
      particleCount: 80,
      spread: 60,
      origin: { y: 0.7 },
      colors: ["#f59e0b", "#3b82f6", "#10b981", "#ec4899"],
    });
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(reward.promoCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-stone-950 border border-stone-800 rounded-3xl overflow-hidden shadow-xl flex flex-col justify-between relative group hover:border-amber-500/40 transition-all">
      {/* Card Header */}
      <div className="p-4 border-b border-stone-800/80 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className={`w-7 h-7 rounded-lg bg-gradient-to-br ${reward.colorTheme} flex items-center justify-center text-white text-xs font-bold`}>
            {reward.iconType === "percent" && <Percent className="w-4 h-4" />}
            {reward.iconType === "gift" && <Gift className="w-4 h-4" />}
            {reward.iconType === "crown" && <Crown className="w-4 h-4" />}
            {reward.iconType === "cake" && <Cake className="w-4 h-4" />}
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
              {reward.provider}
            </span>
            <h4 className="text-xs font-bold text-stone-200">{reward.title}</h4>
          </div>
        </div>

        <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30 font-semibold">
          {reward.badge}
        </span>
      </div>

      {/* Scratch / Prize Surface */}
      <div className="relative min-h-[160px] flex items-center justify-center p-4 bg-gradient-to-br from-stone-900 via-stone-900 to-amber-950/20">
        {/* Revealed Content underneath */}
        <div className="text-center space-y-2 w-full">
          <div className="text-[11px] font-black text-amber-400 tracking-wider uppercase">
            🎉 CONGRATULATIONS!
          </div>
          <div className="text-base sm:text-lg font-black text-stone-100 font-display">
            {reward.headline}
          </div>
          <p className="text-xs text-stone-400 px-2 leading-relaxed">
            {reward.discountDescription}
          </p>

          {/* Promo Code Box */}
          <div className="pt-2">
            <div className="inline-flex items-center gap-2 bg-stone-950 border border-amber-500/50 rounded-xl px-3 py-1.5 shadow-inner">
              <span className="text-xs text-stone-400 font-medium">Code:</span>
              <code className="text-sm font-black text-amber-300 font-mono tracking-wider">
                {reward.promoCode}
              </code>
              <button
                type="button"
                onClick={handleCopyCode}
                className="p-1 rounded-lg bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-stone-950 transition-colors"
                title="Copy Code"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Scratchable Canvas Overlay if not revealed */}
        {!isScratched && (
          <canvas
            ref={canvasRef}
            onMouseDown={(e) => {
              setIsDrawing(true);
              scratch(e.clientX, e.clientY);
            }}
            onMouseMove={(e) => {
              if (isDrawing) scratch(e.clientX, e.clientY);
            }}
            onMouseUp={() => setIsDrawing(false)}
            onMouseLeave={() => setIsDrawing(false)}
            onTouchStart={(e) => {
              setIsDrawing(true);
              const touch = e.touches[0];
              scratch(touch.clientX, touch.clientY);
            }}
            onTouchMove={(e) => {
              if (isDrawing) {
                const touch = e.touches[0];
                scratch(touch.clientX, touch.clientY);
              }
            }}
            onTouchEnd={() => setIsDrawing(false)}
            className="absolute inset-0 w-full h-full cursor-crosshair z-10 touch-none"
          />
        )}
      </div>

      {/* Card Footer */}
      <div className="p-3 bg-stone-950/90 border-t border-stone-800/80 flex items-center justify-between text-[11px] text-stone-400">
        <span>{reward.expiryDate}</span>
        {!isScratched ? (
          <button
            type="button"
            onClick={revealPrize}
            className="text-amber-400 hover:text-amber-300 font-semibold underline text-[11px]"
          >
            Quick Scratch
          </button>
        ) : (
          <span className="text-emerald-400 font-semibold flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" /> Unlocked
          </span>
        )}
      </div>
    </div>
  );
};

export const ScratchGiftsModal: React.FC<ScratchGiftsModalProps> = ({ isOpen, onClose }) => {
  const [rewards, setRewards] = useState<ScratchReward[]>(DEFAULT_REWARDS);

  const handleReveal = (id: string) => {
    setRewards((prev) =>
      prev.map((r) => (r.id === id ? { ...r, isScratched: true } : r))
    );
  };

  const handleRevealAll = () => {
    setRewards((prev) => prev.map((r) => ({ ...r, isScratched: true })));
    confetti({
      particleCount: 150,
      spread: 90,
      origin: { y: 0.6 },
      colors: ["#f59e0b", "#f97316", "#3b82f6", "#10b981"],
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/85 backdrop-blur-md animate-fadeIn">
      <div className="bg-stone-900 border border-stone-800 rounded-3xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Top Bar */}
        <div className="p-4 sm:p-5 border-b border-stone-800 flex items-center justify-between bg-stone-900/95 sticky top-0 z-20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-rose-600 flex items-center justify-center text-stone-950 shadow-lg shadow-amber-500/20">
              <Gift className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-stone-100 font-display">
                  Party Host & Guest Scratch Gifts
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold uppercase">
                  Exclusive
                </span>
              </div>
              <p className="text-xs text-stone-400">
                Scratch to reveal 25% off booking discounts, Flipkart vouchers, and free 1-month subscriptions!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleRevealAll}
              className="text-xs px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 font-semibold transition-colors flex items-center gap-1"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Scratch All Cards</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 border border-stone-700 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scratch Cards Grid */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {rewards.map((reward) => (
              <InteractiveScratchCard
                key={reward.id}
                reward={reward}
                onReveal={handleReveal}
              />
            ))}
          </div>

          {/* Redemption Terms & Info */}
          <div className="bg-stone-950/60 border border-stone-800 rounded-2xl p-4 text-xs text-stone-400 space-y-2">
            <div className="font-bold text-stone-300 flex items-center gap-1.5">
              <PartyPopper className="w-4 h-4 text-amber-400" />
              <span>How to Redeem Your Party Rewards:</span>
            </div>
            <ul className="list-disc list-inside space-y-1 text-stone-400">
              <li><strong>25% Off Booking:</strong> Enter promo code <code className="text-amber-300">CYMBAL25PARTY</code> at CymbalMart checkout or catering booking.</li>
              <li><strong>Flipkart Voucher:</strong> Apply code <code className="text-sky-300">FLIP-GIFT-500</code> under "Gift Cards" section in Flipkart mobile app/website.</li>
              <li><strong>1 Month Free Plus:</strong> Redeem on CymbalMart Plus subscription settings for instant free delivery.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
