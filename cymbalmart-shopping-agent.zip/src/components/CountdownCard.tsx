import React, { useState, useEffect } from "react";
import {
  Clock,
  Calendar,
  Sparkles,
  PartyPopper,
  Flame,
  CheckCircle2,
  Bell,
  CalendarCheck,
  Music,
  Share2,
} from "lucide-react";
import confetti from "canvas-confetti";
import { PartyPlan } from "../types";

interface CountdownCardProps {
  currentPlan: PartyPlan;
  onUpdateEventDate: (newDateStr: string) => void;
  onOpenMemoryShare?: () => void;
  onOpenScratchGifts?: () => void;
}

export const CountdownCard: React.FC<CountdownCardProps> = ({
  currentPlan,
  onUpdateEventDate,
  onOpenMemoryShare,
  onOpenScratchGifts,
}) => {
  // Default to upcoming Saturday at 18:00 if not set
  const getDefaultDate = () => {
    const d = new Date();
    const dayOfWeek = d.getDay();
    const daysUntilSat = (6 - dayOfWeek + 7) % 7 || 7;
    d.setDate(d.getDate() + daysUntilSat);
    d.setHours(18, 0, 0, 0);
    return d.toISOString();
  };

  const targetDateStr = currentPlan.eventDate || getDefaultDate();
  const [targetDate, setTargetDate] = useState<string>(targetDateStr);
  const [timeLeft, setTimeLeft] = useState<{
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
    isPast: boolean;
  }>({ days: 0, hours: 0, minutes: 0, seconds: 0, isPast: false });

  const [isEditingDate, setIsEditingDate] = useState(false);

  useEffect(() => {
    const calculateTime = () => {
      const target = new Date(targetDate).getTime();
      const now = new Date().getTime();
      const diff = target - now;

      if (diff <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0, isPast: true });
      } else {
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);
        setTimeLeft({ days, hours, minutes, seconds, isPast: false });
      }
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);
    return () => clearInterval(interval);
  }, [targetDate]);

  const handleFireConfetti = () => {
    confetti({
      particleCount: 120,
      spread: 70,
      origin: { y: 0.6 },
      colors: ["#f59e0b", "#f97316", "#ef4444", "#10b981", "#6366f1"],
    });
  };

  const handleSaveDate = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateEventDate(targetDate);
    setIsEditingDate(false);
    handleFireConfetti();
  };

  const formattedDate = new Date(targetDate).toLocaleDateString("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });

  return (
    <div className="bg-gradient-to-br from-stone-900 via-stone-900 to-amber-950/30 border border-stone-800 rounded-3xl p-6 shadow-2xl space-y-6 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-0 right-0 -mr-24 -mt-24 w-72 h-72 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 relative z-10">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-stone-950 shadow-lg shadow-amber-500/20 flex-shrink-0">
            <Clock className="w-6 h-6 animate-spin-slow" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                Live Party Countdown
              </span>
              <span
                className={`text-[11px] px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                  timeLeft.isPast
                    ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 animate-pulse"
                    : "bg-stone-800 text-stone-300 border border-stone-700"
                }`}
              >
                {timeLeft.isPast ? "🎉 Party is Today!" : "Planning Phase"}
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-stone-100 font-display">
              {currentPlan.name}
            </h2>
            <div className="text-xs text-stone-400 flex items-center gap-2 mt-0.5">
              <Calendar className="w-3.5 h-3.5 text-stone-500" />
              <span>Event Date: <strong className="text-amber-300 font-semibold">{formattedDate}</strong></span>
              <button
                type="button"
                onClick={() => setIsEditingDate(!isEditingDate)}
                className="text-[11px] text-amber-400 hover:text-amber-300 underline ml-1"
              >
                {isEditingDate ? "Cancel" : "Change Date"}
              </button>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            type="button"
            onClick={handleFireConfetti}
            className="flex-1 sm:flex-none px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-lg shadow-amber-500/20 transition-all active:scale-95"
            id="countdown-confetti-btn"
          >
            <PartyPopper className="w-4 h-4" />
            <span>Celebrate!</span>
          </button>

          {onOpenMemoryShare && (
            <button
              type="button"
              onClick={onOpenMemoryShare}
              className="px-3 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 hover:text-white border border-stone-700 text-xs sm:text-sm flex items-center gap-1.5 transition-colors"
            >
              <Share2 className="w-4 h-4 text-sky-400" />
              <span className="hidden sm:inline">Guest QR Code</span>
            </button>
          )}

          {onOpenScratchGifts && (
            <button
              type="button"
              onClick={onOpenScratchGifts}
              className="px-3 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 hover:text-white border border-stone-700 text-xs sm:text-sm flex items-center gap-1.5 transition-colors"
            >
              <Flame className="w-4 h-4 text-orange-400" />
              <span className="hidden sm:inline">Scratch Gifts</span>
            </button>
          )}
        </div>
      </div>

      {/* Date Picker Form */}
      {isEditingDate && (
        <form onSubmit={handleSaveDate} className="bg-stone-950/80 border border-stone-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center gap-3 relative z-10 animate-fadeIn">
          <div className="flex-1 w-full">
            <label className="block text-xs font-semibold text-stone-400 mb-1">
              Select Party Date & Start Time
            </label>
            <input
              type="datetime-local"
              value={targetDate.slice(0, 16)}
              onChange={(e) => setTargetDate(new Date(e.target.value).toISOString())}
              className="w-full bg-stone-900 border border-stone-700 rounded-xl px-3 py-2 text-sm text-stone-100 focus:outline-none focus:border-amber-500"
            />
          </div>
          <button
            type="submit"
            className="w-full sm:w-auto mt-auto px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-stone-950 font-bold text-sm transition-colors flex items-center justify-center gap-1.5"
          >
            <CalendarCheck className="w-4 h-4" />
            <span>Update Party Date</span>
          </button>
        </form>
      )}

      {/* Digital Countdown Timer Clock Blocks */}
      <div className="grid grid-cols-4 gap-2 sm:gap-4 relative z-10">
        {[
          { label: "DAYS", value: timeLeft.days, color: "text-amber-400" },
          { label: "HOURS", value: timeLeft.hours, color: "text-orange-400" },
          { label: "MINUTES", value: timeLeft.minutes, color: "text-rose-400" },
          { label: "SECONDS", value: timeLeft.seconds, color: "text-emerald-400" },
        ].map((block, idx) => (
          <div
            key={idx}
            className="bg-stone-950/80 border border-stone-800/90 rounded-2xl p-3 sm:p-5 text-center shadow-inner relative overflow-hidden group hover:border-amber-500/40 transition-colors"
          >
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-amber-500/30 to-transparent" />
            <div className={`text-2xl sm:text-4xl md:text-5xl font-black font-mono tracking-tight ${block.color}`}>
              {String(block.value).padStart(2, "0")}
            </div>
            <div className="text-[10px] sm:text-xs font-bold text-stone-400 tracking-wider mt-1">
              {block.label}
            </div>
          </div>
        ))}
      </div>

      {/* Preparation Milestones / Readiness Status */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 relative z-10 pt-2 border-t border-stone-800">
        <div className="bg-stone-950/50 border border-stone-800/80 rounded-xl p-3 flex items-start gap-2.5">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
          <div>
            <div className="text-xs font-bold text-stone-200">Shopping Readiness</div>
            <div className="text-[11px] text-stone-400">
              {currentPlan.items.filter((i) => i.checked).length} of {currentPlan.items.length} items purchased (
              {Math.round((currentPlan.items.filter((i) => i.checked).length / Math.max(1, currentPlan.items.length)) * 100)}%)
            </div>
          </div>
        </div>

        <div className="bg-stone-950/50 border border-stone-800/80 rounded-xl p-3 flex items-start gap-2.5">
          <Bell className="w-4 h-4 text-amber-400 mt-0.5 flex-shrink-0" />
          <div>
            <div className="text-xs font-bold text-stone-200">Next Prep Trigger</div>
            <div className="text-[11px] text-stone-400">
              {timeLeft.days > 2
                ? "Buy dry goods & non-perishables"
                : timeLeft.days > 0
                ? "Chill drinks & pick up fresh meats/produce"
                : "Morning of party: Pick up ice and prep buffet"}
            </div>
          </div>
        </div>

        <div className="bg-stone-950/50 border border-stone-800/80 rounded-xl p-3 flex items-start gap-2.5">
          <Music className="w-4 h-4 text-purple-400 mt-0.5 flex-shrink-0" />
          <div>
            <div className="text-xs font-bold text-stone-200">Guest Experience</div>
            <div className="text-[11px] text-stone-400">
              QR Code Memory Sharing is Active & VIP Security Gated
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
