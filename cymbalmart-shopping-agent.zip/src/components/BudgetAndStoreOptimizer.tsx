import React from "react";
import {
  DollarSign,
  TrendingDown,
  Store,
  Sparkles,
  ShoppingBag,
  ArrowRight,
  Lightbulb,
  CheckCircle2,
  AlertTriangle,
  BadgePercent,
  Layers,
} from "lucide-react";
import { PartyPlan, StoreRoute } from "../types";
import { CATEGORY_DEFINITIONS } from "../utils/categoryHelpers";

interface BudgetAndStoreOptimizerProps {
  plan: PartyPlan;
  onOpenAgentWithPrompt: (prompt: string) => void;
}

export const BudgetAndStoreOptimizer: React.FC<BudgetAndStoreOptimizerProps> = ({
  plan,
  onOpenAgentWithPrompt,
}) => {
  const ba = plan.budgetAnalysis;
  const budgetLimit = plan.budgetLimit;
  const totalMin = ba.totalEstimatedCostMin;
  const totalMax = ba.totalEstimatedCostMax;
  const totalMid = (totalMin + totalMax) / 2;
  const budgetPercent = Math.min(100, Math.round((totalMid / budgetLimit) * 100));

  // Determine budget status color
  const isOver = totalMin > budgetLimit;
  const isUnder = totalMax <= budgetLimit * 0.85;

  // Compute store breakdown from active items
  const storeMap: Record<string, { count: number; costMin: number; costMax: number; items: string[] }> = {};
  plan.items.forEach((item) => {
    const s = item.storeType || "Supermarket / Grocery";
    if (!storeMap[s]) {
      storeMap[s] = { count: 0, costMin: 0, costMax: 0, items: [] };
    }
    storeMap[s].count += 1;
    storeMap[s].costMin += item.estimatedPriceMin || 0;
    storeMap[s].costMax += item.estimatedPriceMax || item.estimatedPriceMin || 0;
    storeMap[s].items.push(item.name);
  });

  return (
    <div className="space-y-6">
      {/* Budget Summary & Meter Card */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl p-5 sm:p-6 shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-stone-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-stone-100 font-display">
                  Budget Optimization & Breakdown
                </h3>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full font-medium border ${
                    isOver
                      ? "bg-rose-500/15 text-rose-300 border-rose-500/30"
                      : isUnder
                      ? "bg-emerald-500/15 text-emerald-300 border-emerald-500/30"
                      : "bg-amber-500/15 text-amber-300 border-amber-500/30"
                  }`}
                >
                  {isOver ? "Over Budget Target" : isUnder ? "Under Budget Cap" : "On Target"}
                </span>
              </div>
              <p className="text-xs text-stone-400">
                Target Cap: ${budgetLimit} | Approx. ${ba.costPerGuest || Math.round(totalMid / plan.guestCount.total)} per guest
              </p>
            </div>
          </div>

          <div className="text-right flex items-center gap-4">
            <div>
              <div className="text-xs text-stone-400">Estimated Total</div>
              <div className="text-xl font-extrabold text-stone-100 font-display">
                ${totalMin} - ${totalMax}
              </div>
            </div>
          </div>
        </div>

        {/* Budget Progress Bar */}
        <div className="mt-5 space-y-2">
          <div className="flex items-center justify-between text-xs font-medium">
            <span className="text-stone-400">Allocated Budget Progress</span>
            <span className={isOver ? "text-rose-400 font-bold" : "text-stone-300"}>
              {budgetPercent}% (${Math.round(totalMid)} / ${budgetLimit})
            </span>
          </div>

          <div className="w-full h-3 rounded-full bg-stone-800 overflow-hidden relative">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                isOver
                  ? "bg-gradient-to-r from-rose-500 to-red-600"
                  : "bg-gradient-to-r from-amber-500 to-orange-500"
              }`}
              style={{ width: `${Math.min(100, budgetPercent)}%` }}
            />
          </div>
        </div>

        {/* Category Spend Distribution Bars */}
        <div className="mt-6">
          <h4 className="text-xs font-semibold text-stone-400 uppercase tracking-wider mb-3">
            Spending by Category
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {Object.entries(ba.categoryDistribution || {}).map(([catKey, amount]) => {
              const amountVal = typeof amount === "number" ? amount : Number(amount) || 0;
              if (amountVal <= 0) return null;
              const meta = CATEGORY_DEFINITIONS[catKey as keyof typeof CATEGORY_DEFINITIONS];
              const pct = Math.round((amountVal / Math.max(1, totalMid)) * 100);

              return (
                <div
                  key={catKey}
                  className="bg-stone-950/50 border border-stone-800/80 rounded-xl p-3 flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="font-medium text-stone-300 truncate">
                      {meta?.shortLabel || catKey}
                    </span>
                    <span className="text-stone-200 font-bold font-display">${amountVal}</span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-stone-800 overflow-hidden">
                    <div
                      className={`h-full rounded-full ${meta?.bgLightClass ? "bg-amber-400" : "bg-stone-400"}`}
                      style={{ width: `${Math.min(100, pct)}%` }}
                    />
                  </div>
                  <div className="text-[10px] text-stone-400 mt-1">{pct}% of list total</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* AI Savings Tips & Deal Recommendations */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl p-5 sm:p-6 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Lightbulb className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-stone-100 font-display">
                AI Cost-Saving & Substitution Advice
              </h4>
              <p className="text-xs text-stone-400">Smart hacks to save 15-30% on your shopping run</p>
            </div>
          </div>

          <button
            onClick={() => onOpenAgentWithPrompt("Help me cut $30 from my total without sacrificing taste")}
            className="px-3 py-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 text-xs font-semibold flex items-center gap-1.5 transition-all"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Trim Budget with AI</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {(ba.savingsTips || []).map((tip, idx) => (
            <div
              key={idx}
              className="bg-stone-950/60 border border-stone-800/80 rounded-xl p-3.5 text-xs text-stone-300 flex items-start gap-2.5 leading-relaxed"
            >
              <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 font-bold flex items-center justify-center flex-shrink-0 text-[10px]">
                {idx + 1}
              </span>
              <span>{tip}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Store Routing & Aisle Optimization */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl p-5 sm:p-6 shadow-lg">
        <div className="flex items-center gap-2.5 mb-4">
          <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
            <Store className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-stone-100 font-display">
              Optimized Store Routing & Aisle Plan
            </h4>
            <p className="text-xs text-stone-400">
              Grouped trips so you hit fewer stores and shop by aisle efficiency
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {plan.storeRoutes && plan.storeRoutes.length > 0 ? (
            plan.storeRoutes.map((route, i) => {
              const liveData = storeMap[route.storeType] || { count: route.itemCount, costMin: route.estimatedCost, costMax: route.estimatedCost };

              return (
                <div
                  key={i}
                  className="bg-stone-950/60 border border-stone-800/80 rounded-xl p-4 flex flex-col justify-between space-y-3"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-stone-800 text-amber-300 border border-stone-700">
                        Stop #{i + 1}
                      </span>
                      <span className="text-xs font-bold text-stone-200">
                        ${liveData.costMin} - ${liveData.costMax}
                      </span>
                    </div>

                    <h5 className="text-sm font-bold text-stone-100 font-display">
                      {route.recommendedStoreName}
                    </h5>
                    <div className="text-xs text-stone-400 mt-0.5">
                      {liveData.count} items ({route.storeType})
                    </div>

                    {/* Key Aisles */}
                    {route.keyAisles && route.keyAisles.length > 0 && (
                      <div className="mt-3">
                        <div className="text-[10px] text-stone-400 uppercase tracking-wider font-semibold mb-1">
                          Key Aisles:
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {route.keyAisles.map((aisle, aIdx) => (
                            <span
                              key={aIdx}
                              className="text-[10px] px-2 py-0.5 rounded bg-stone-800/80 text-stone-300 border border-stone-700/60"
                            >
                              {aisle}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Pro Tip */}
                  {route.proTip && (
                    <div className="text-[11px] text-amber-300/90 bg-amber-500/10 border border-amber-500/20 rounded-lg p-2.5 leading-relaxed">
                      💡 <span className="font-semibold">Pro Tip:</span> {route.proTip}
                    </div>
                  )}
                </div>
              );
            })
          ) : (
            <div className="col-span-3 text-xs text-stone-400 text-center py-4">
              Store routing is active for your shopping list.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
