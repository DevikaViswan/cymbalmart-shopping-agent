import React from "react";
import {
  Sparkles,
  Calendar,
  DollarSign,
  CheckCircle2,
  Share2,
  Printer,
  FileSpreadsheet,
  Copy,
  Bot,
  Smartphone,
  PlusCircle,
  Settings2,
  PartyPopper,
  Users,
  Mic,
  Clock,
  QrCode,
  Gift,
} from "lucide-react";
import { PartyPlan } from "../types";

interface HeaderProps {
  currentPlan: PartyPlan;
  onOpenSetup: () => void;
  onOpenAgentChat: () => void;
  onOpenMobileMode: () => void;
  onOpenVoiceControl: () => void;
  onOpenCountdown: () => void;
  onOpenMemoryShare: () => void;
  onOpenScratchGifts: () => void;
  onExportCSV: () => void;
  onCopyText: () => void;
  onPrint: () => void;
  savedPlans: PartyPlan[];
  onSelectPlan: (plan: PartyPlan) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentPlan,
  onOpenSetup,
  onOpenAgentChat,
  onOpenMobileMode,
  onOpenVoiceControl,
  onOpenCountdown,
  onOpenMemoryShare,
  onOpenScratchGifts,
  onExportCSV,
  onCopyText,
  onPrint,
  savedPlans,
  onSelectPlan,
}) => {
  const [showExportMenu, setShowExportMenu] = React.useState(false);
  const [showPlanMenu, setShowPlanMenu] = React.useState(false);
  const [copied, setCopied] = React.useState(false);

  const totalItems = currentPlan.items.length;
  const checkedItems = currentPlan.items.filter((i) => i.checked).length;
  const progressPercent = totalItems > 0 ? Math.round((checkedItems / totalItems) * 100) : 0;

  const handleCopy = () => {
    onCopyText();
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    setShowExportMenu(false);
  };

  return (
    <header className="sticky top-0 z-30 bg-stone-900/95 backdrop-blur-md border-b border-stone-800 shadow-xl no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18 py-3">
          {/* Logo & Party Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-lg shadow-amber-500/20 text-white flex-shrink-0">
              <PartyPopper className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-amber-400/90 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-amber-400" />
                  CymbalMart Shopping Agent
                </span>
              </div>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <button
                    onClick={() => setShowPlanMenu(!showPlanMenu)}
                    className="flex items-center gap-1.5 text-base sm:text-lg font-bold text-stone-100 hover:text-amber-400 transition-colors font-display text-left"
                    id="header-party-selector-btn"
                  >
                    <span className="truncate max-w-[180px] sm:max-w-[260px] md:max-w-[320px]">
                      {currentPlan.name}
                    </span>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30 hidden sm:inline-block font-sans font-normal">
                      {currentPlan.eventType}
                    </span>
                  </button>

                  {/* Saved Plans Dropdown */}
                  {showPlanMenu && (
                    <div className="absolute left-0 mt-2 w-72 rounded-xl bg-stone-800 border border-stone-700 shadow-2xl py-2 z-50">
                      <div className="px-3 py-1.5 text-xs font-semibold text-stone-400 uppercase tracking-wider">
                        Switch Party Plan
                      </div>
                      {savedPlans.map((plan) => (
                        <button
                          key={plan.id}
                          onClick={() => {
                            onSelectPlan(plan);
                            setShowPlanMenu(false);
                          }}
                          className={`w-full text-left px-3 py-2 text-sm flex items-center justify-between hover:bg-stone-700/60 transition-colors ${
                            plan.id === currentPlan.id ? "text-amber-400 font-medium bg-stone-700/30" : "text-stone-300"
                          }`}
                        >
                          <span className="truncate">{plan.name}</span>
                          <span className="text-xs text-stone-400">{plan.guestCount.total} guests</span>
                        </button>
                      ))}
                      <div className="border-t border-stone-700 mt-1 pt-1">
                        <button
                          onClick={() => {
                            setShowPlanMenu(false);
                            onOpenSetup();
                          }}
                          className="w-full text-left px-3 py-2 text-sm text-amber-400 hover:bg-amber-500/10 flex items-center gap-2"
                        >
                          <PlusCircle className="w-4 h-4" />
                          <span>Create New Party Plan...</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-3 text-xs text-stone-400">
                <span className="flex items-center gap-1">
                  <Users className="w-3.5 h-3.5 text-stone-400" />
                  {currentPlan.guestCount.adults} Adults
                  {currentPlan.guestCount.kids > 0 ? `, ${currentPlan.guestCount.kids} Kids` : ""}
                </span>
                <span className="hidden sm:inline-block">•</span>
                <span className="hidden sm:flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-stone-400" />
                  {currentPlan.durationHours} hrs ({currentPlan.venueType})
                </span>
              </div>
            </div>
          </div>

          {/* Center Quick Stats (Desktop) */}
          <div className="hidden lg:flex items-center gap-4 bg-stone-800/80 border border-stone-700/70 rounded-xl px-4 py-2">
            {/* Checklist Progress */}
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-semibold text-xs">
                {progressPercent}%
              </div>
              <div>
                <div className="text-xs text-stone-400 font-medium">Purchased</div>
                <div className="text-sm font-bold text-stone-200">
                  {checkedItems} / {totalItems} items
                </div>
              </div>
            </div>

            <div className="w-px h-7 bg-stone-700" />

            {/* Budget Meter */}
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-semibold text-xs">
                <DollarSign className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs text-stone-400 font-medium">Est. Budget</div>
                <div className="text-sm font-bold text-stone-200">
                  ${currentPlan.budgetAnalysis.totalEstimatedCostMin} - ${currentPlan.budgetAnalysis.totalEstimatedCostMax}
                  <span className="text-xs font-normal text-stone-400 ml-1">
                    / ${currentPlan.budgetLimit}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Actions */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Hands-Free Voice Control Button */}
            <button
              onClick={onOpenVoiceControl}
              className="px-2.5 sm:px-3 py-2 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/40 text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-all shadow-sm group hover:scale-[1.02] active:scale-[0.98]"
              title="Hands-Free Voice Control"
              id="header-voice-control-btn"
            >
              <Mic className="w-4 h-4 text-amber-400 group-hover:animate-pulse" />
              <span className="hidden md:inline">Voice AI</span>
            </button>

            {/* Countdown Button */}
            <button
              onClick={onOpenCountdown}
              className="px-2.5 sm:px-3 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 hover:text-white border border-stone-700 text-xs sm:text-sm font-medium flex items-center gap-1.5 transition-all shadow-sm"
              title="Party Countdown & Timeline"
              id="header-countdown-btn"
            >
              <Clock className="w-4 h-4 text-orange-400" />
              <span className="hidden xl:inline">Countdown</span>
            </button>

            {/* QR Memory Sharing Button */}
            <button
              onClick={onOpenMemoryShare}
              className="px-2.5 sm:px-3 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 hover:text-white border border-stone-700 text-xs sm:text-sm font-medium flex items-center gap-1.5 transition-all shadow-sm"
              title="Guest QR Memories & Toasts"
              id="header-qr-memories-btn"
            >
              <QrCode className="w-4 h-4 text-sky-400" />
              <span className="hidden xl:inline">QR Memories</span>
            </button>

            {/* Scratch Gifts & Rewards Button */}
            <button
              onClick={onOpenScratchGifts}
              className="px-2.5 sm:px-3 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 hover:text-white border border-stone-700 text-xs sm:text-sm font-medium flex items-center gap-1.5 transition-all shadow-sm"
              title="Scratch & Win Gifts"
              id="header-scratch-gifts-btn"
            >
              <Gift className="w-4 h-4 text-rose-400" />
              <span className="hidden sm:inline">Gifts & 25% Off</span>
            </button>

            {/* Mobile Shopping Mode Button */}
            <button
              onClick={onOpenMobileMode}
              className="px-2.5 sm:px-3 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 hover:text-white border border-stone-700 text-xs sm:text-sm font-medium flex items-center gap-1.5 transition-all shadow-sm"
              title="In-Store Shopping Mode"
              id="header-mobile-mode-btn"
            >
              <Smartphone className="w-4 h-4 text-emerald-400" />
              <span className="hidden md:inline">Store Mode</span>
            </button>

            {/* Edit / Setup Button */}
            <button
              onClick={onOpenSetup}
              className="px-2.5 sm:px-3 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 hover:text-white border border-stone-700 text-xs sm:text-sm font-medium flex items-center gap-1.5 transition-all shadow-sm"
              id="header-party-settings-btn"
            >
              <Settings2 className="w-4 h-4 text-amber-400" />
              <span className="hidden lg:inline">Plan Details</span>
            </button>

            {/* Export Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowExportMenu(!showExportMenu)}
                className="p-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-700 text-sm transition-all"
                title="Export & Share Options"
                id="header-export-btn"
              >
                <Share2 className="w-4 h-4" />
              </button>

              {showExportMenu && (
                <div className="absolute right-0 mt-2 w-52 rounded-xl bg-stone-800 border border-stone-700 shadow-2xl py-2 z-50">
                  <button
                    onClick={handleCopy}
                    className="w-full text-left px-3 py-2 text-sm text-stone-200 hover:bg-stone-700 flex items-center gap-2.5"
                  >
                    <Copy className="w-4 h-4 text-amber-400" />
                    <span>{copied ? "Copied to Clipboard!" : "Copy Full Checklist"}</span>
                  </button>
                  <button
                    onClick={() => {
                      onExportCSV();
                      setShowExportMenu(false);
                    }}
                    className="w-full text-left px-3 py-2 text-sm text-stone-200 hover:bg-stone-700 flex items-center gap-2.5"
                  >
                    <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                    <span>Download CSV Spreadsheet</span>
                  </button>
                  <button
                    onClick={() => {
                      setShowExportMenu(false);
                      onPrint();
                    }}
                    className="w-full text-left px-3 py-2 text-sm text-stone-200 hover:bg-stone-700 flex items-center gap-2.5"
                  >
                    <Printer className="w-4 h-4 text-blue-400" />
                    <span>Print Shopping Checklist</span>
                  </button>
                </div>
              )}
            </div>

            {/* CymbalMart Assistant Chat Trigger Button */}
            <button
              onClick={onOpenAgentChat}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-stone-950 font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-amber-500/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
              id="header-agent-chat-btn"
              title="Open CymbalMart Assistant"
            >
              <Bot className="w-4 h-4" />
              <span className="whitespace-nowrap">CymbalMart Assistant</span>
              <span className="w-2 h-2 rounded-full bg-emerald-950 animate-pulse hidden sm:inline-block" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
