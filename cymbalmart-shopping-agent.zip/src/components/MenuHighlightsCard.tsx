import React from "react";
import { UtensilsCrossed, Wine, Sparkles, ChevronDown, ChevronUp } from "lucide-react";
import { PartyPlan, MenuHighlight } from "../types";

interface MenuHighlightsCardProps {
  plan: PartyPlan;
  onOpenAgentForRecipe: (dishName: string) => void;
}

export const MenuHighlightsCard: React.FC<MenuHighlightsCardProps> = ({
  plan,
  onOpenAgentForRecipe,
}) => {
  const [isExpanded, setIsExpanded] = React.useState(true);
  const highlights = plan.menuHighlights || [];

  if (highlights.length === 0) return null;

  return (
    <div className="bg-stone-900 border border-stone-800 rounded-2xl p-5 shadow-lg space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/30 flex items-center justify-center text-orange-400">
            <UtensilsCrossed className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-stone-100 font-display">
              Curated Party Menu & Signature Bar
            </h3>
            <p className="text-xs text-stone-400">
              Dishes & drink pairings that generated this shopping list
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="p-1.5 rounded-lg text-stone-400 hover:text-stone-200 hover:bg-stone-800 transition-colors"
        >
          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
      </div>

      {isExpanded && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 pt-1">
          {highlights.map((dish, idx) => (
            <div
              key={idx}
              className="bg-stone-950/60 border border-stone-800/80 rounded-xl p-3.5 flex flex-col justify-between space-y-2.5 hover:border-amber-500/40 transition-colors group"
            >
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-stone-800 text-amber-300 border border-stone-700/80 uppercase tracking-wider">
                    {dish.course}
                  </span>
                  {dish.dietaryTags && dish.dietaryTags.length > 0 && (
                    <span className="text-[10px] text-emerald-400">
                      {dish.dietaryTags.join(", ")}
                    </span>
                  )}
                </div>

                <h4 className="text-sm font-bold text-stone-100 font-display group-hover:text-amber-300 transition-colors">
                  {dish.dishName}
                </h4>
                <p className="text-xs text-stone-400 mt-1 leading-relaxed line-clamp-2">
                  {dish.description}
                </p>
              </div>

              <button
                type="button"
                onClick={() =>
                  onOpenAgentForRecipe(
                    `Give me the recipe breakdown, prep steps, and verify ingredients for: "${dish.dishName}"`
                  )
                }
                className="text-[11px] text-stone-400 group-hover:text-amber-400 font-medium flex items-center gap-1 self-start transition-colors pt-1"
              >
                <Sparkles className="w-3 h-3 text-amber-400" />
                <span>Recipe & Prep Advice →</span>
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
