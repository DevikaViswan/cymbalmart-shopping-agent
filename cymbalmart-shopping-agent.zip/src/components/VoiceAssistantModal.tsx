import React, { useState, useEffect, useRef } from "react";
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Sparkles,
  CheckCircle2,
  X,
  MessageSquare,
  HelpCircle,
  Clock,
  QrCode,
  Gift,
  ShoppingCart,
  DollarSign,
  Send,
  Radio,
} from "lucide-react";
import { PartyPlan, ShoppingItem } from "../types";

interface VoiceAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPlan: PartyPlan;
  onAddItem: (item: Partial<ShoppingItem>) => void;
  onToggleItemCheck: (itemId: string) => void;
  onUpdateBudget: (newBudget: number) => void;
  onOpenCountdown: () => void;
  onOpenMemoryShare: () => void;
  onOpenScratchGifts: () => void;
  onSwitchTab: (tab: "items" | "budget" | "timeline") => void;
  onOpenAgentChatWithMessage?: (message: string) => void;
}

export const VoiceAssistantModal: React.FC<VoiceAssistantModalProps> = ({
  isOpen,
  onClose,
  currentPlan,
  onAddItem,
  onToggleItemCheck,
  onUpdateBudget,
  onOpenCountdown,
  onOpenMemoryShare,
  onOpenScratchGifts,
  onSwitchTab,
  onOpenAgentChatWithMessage,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [lastActionFeedback, setLastActionFeedback] = useState<string | null>(null);
  const [ttsEnabled, setTtsEnabled] = useState(true);
  const [textInput, setTextInput] = useState("");
  const [commandHistory, setCommandHistory] = useState<
    { text: string; response: string; type: "success" | "info" | "error"; time: string }[]
  >([]);

  const recognitionRef = useRef<any>(null);

  // Helper for text to speech
  const speakFeedback = (text: string) => {
    if (!ttsEnabled || typeof window === "undefined" || !("speechSynthesis" in window)) return;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.05;
      utterance.pitch = 1.0;
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn("TTS not available:", e);
    }
  };

  // Initialize Web Speech API
  useEffect(() => {
    if (typeof window !== "undefined") {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.lang = "en-US";

        recognition.onresult = (event: any) => {
          let current = "";
          for (let i = event.resultIndex; i < event.results.length; i++) {
            current += event.results[i][0].transcript;
          }
          setTranscript(current);

          // If result is final
          if (event.results[event.results.length - 1].isFinal) {
            handleProcessCommand(current);
          }
        };

        recognition.onerror = (event: any) => {
          console.warn("Speech recognition error:", event.error);
          if (event.error === "not-allowed") {
            setIsListening(false);
            setLastActionFeedback("Microphone access was denied. Please allow microphone permissions.");
          }
        };

        recognition.onend = () => {
          if (isListening) {
            try {
              recognition.start();
            } catch (err) {
              setIsListening(false);
            }
          }
        };

        recognitionRef.current = recognition;
      }
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }
    };
  }, [isListening, currentPlan]);

  const toggleListening = () => {
    if (isListening) {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }
      setIsListening(false);
    } else {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.start();
          setIsListening(true);
          setLastActionFeedback("Listening... Say a command like 'Add 2 bags of chips' or 'Show countdown'");
        } catch (e) {
          console.error("Failed to start speech recognition:", e);
          setIsListening(true);
        }
      } else {
        setIsListening(true);
        setLastActionFeedback("Speech recognition not supported in this browser. You can type commands below!");
      }
    }
  };

  const addHistory = (text: string, response: string, type: "success" | "info" | "error" = "success") => {
    const time = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    setCommandHistory((prev) => [{ text, response, type, time }, ...prev.slice(0, 7)]);
  };

  const handleProcessCommand = (commandText: string) => {
    const raw = commandText.trim();
    if (!raw) return;
    const lower = raw.toLowerCase();

    // 1. OPEN COUNTDOWN
    if (lower.includes("countdown") || lower.includes("time left") || lower.includes("how much time")) {
      const response = "Opening party countdown timer!";
      setLastActionFeedback(response);
      speakFeedback(response);
      addHistory(raw, response, "success");
      onOpenCountdown();
      return;
    }

    // 2. OPEN MEMORY SHARE / QR CODE
    if (
      lower.includes("memory") ||
      lower.includes("memories") ||
      lower.includes("qr") ||
      lower.includes("photo") ||
      lower.includes("toast")
    ) {
      const response = "Opening secure QR code and party memory sharing hub!";
      setLastActionFeedback(response);
      speakFeedback(response);
      addHistory(raw, response, "success");
      onOpenMemoryShare();
      return;
    }

    // 3. OPEN SCRATCH GIFTS / REWARDS
    if (
      lower.includes("gift") ||
      lower.includes("reward") ||
      lower.includes("scratch") ||
      lower.includes("flipkart") ||
      lower.includes("discount") ||
      lower.includes("voucher") ||
      lower.includes("subscription")
    ) {
      const response = "Opening your exclusive Scratch & Win gift cards!";
      setLastActionFeedback(response);
      speakFeedback(response);
      addHistory(raw, response, "success");
      onOpenScratchGifts();
      return;
    }

    // 4. SWITCH TABS
    if (lower.includes("budget") || lower.includes("cost") || lower.includes("store")) {
      const response = "Switched to Budget & Store Optimizer view.";
      setLastActionFeedback(response);
      speakFeedback(response);
      addHistory(raw, response, "info");
      onSwitchTab("budget");
      return;
    }
    if (lower.includes("timeline") || lower.includes("schedule") || lower.includes("step")) {
      const response = "Switched to Shopping & Preparation Timeline.";
      setLastActionFeedback(response);
      speakFeedback(response);
      addHistory(raw, response, "info");
      onSwitchTab("timeline");
      return;
    }
    if (lower.includes("shopping list") || lower.includes("show items") || lower.includes("list view")) {
      const response = "Switched to Shopping List view.";
      setLastActionFeedback(response);
      speakFeedback(response);
      addHistory(raw, response, "info");
      onSwitchTab("items");
      return;
    }

    // 5. CHECK / MARK ITEM AS PURCHASED
    if (lower.startsWith("check") || lower.startsWith("mark") || lower.includes("bought") || lower.includes("purchased")) {
      const targetQuery = lower
        .replace(/^(check off|check|mark off|mark|i bought|purchased|done with)\s+/i, "")
        .replace(/\s+(as done|as purchased|off the list)$/i, "")
        .trim();

      const matchedItem = currentPlan.items.find((item) =>
        item.name.toLowerCase().includes(targetQuery)
      );

      if (matchedItem) {
        onToggleItemCheck(matchedItem.id);
        const response = `Marked "${matchedItem.name}" as ${matchedItem.checked ? "unpurchased" : "purchased"}!`;
        setLastActionFeedback(response);
        speakFeedback(response);
        addHistory(raw, response, "success");
        return;
      }
    }

    // 6. ADD ITEM HANDS-FREE: e.g. "Add 3 boxes of juice pouches", "Add salsa", "Add 2 packs of buns"
    if (lower.startsWith("add ") || lower.includes("add to list")) {
      let itemClause = lower.replace(/^add\s+/i, "").replace(/\s+to list$/i, "").trim();

      // Extract quantity if present
      const qtyMatch = itemClause.match(/^(\d+(?:\.\d+)?)\s*(lbs|packs|boxes|bags|bottles|cans|items|tents|chairs)?\s*(?:of\s+)?(.*)$/i);

      let quantity = 1;
      let unit = "items";
      let name = itemClause;

      if (qtyMatch) {
        quantity = parseFloat(qtyMatch[1]) || 1;
        unit = qtyMatch[2] || "packs";
        name = qtyMatch[3] || itemClause;
      }

      // Titleize name
      name = name.charAt(0).toUpperCase() + name.slice(1);

      // Estimate category and price
      let category = "pantry-dry";
      let estimatedMin = Math.max(3, quantity * 4);
      let estimatedMax = Math.max(5, quantity * 6);
      let storeType = "Supermarket / Grocery";

      if (/juice|drink|water|coke|soda|beer|wine|seltzer/i.test(name)) {
        category = /beer|wine|cocktail/i.test(name) ? "beverages-alcohol" : "beverages-soft";
        storeType = /beer|wine/i.test(name) ? "Liquor & Wine Store" : "Supermarket / Grocery";
      } else if (/chip|dip|snack|salsa|guacamole|pretzel|cookie|candy/i.test(name)) {
        category = "snacks-sweets";
      } else if (/plate|cup|napkin|fork|spoon|tablecloth/i.test(name)) {
        category = "tableware-supplies";
        storeType = "Dollar Store / Discount";
      } else if (/meat|beef|chicken|burger|hot dog|pork|fish|shrimp/i.test(name)) {
        category = "meat-seafood";
        estimatedMin = quantity * 7;
        estimatedMax = quantity * 11;
      } else if (/ice/i.test(name)) {
        category = "ice-coolers-cleaning";
        unit = "bags (10 lbs)";
      } else if (/canopy|tent|chair|sunscreen|bug spray|citronella/i.test(name)) {
        category = "outdoor-gear";
        storeType = "Outdoor / Hardware Store";
      }

      onAddItem({
        name,
        quantity,
        unit,
        category: category as any,
        storeType: storeType as any,
        estimatedPriceMin: estimatedMin,
        estimatedPriceMax: estimatedMax,
        priority: "must-have",
        checked: false,
        isPerishable: category === "meat-seafood" || category === "dairy-chilled" || category === "produce",
        dietaryTags: [],
      });

      const response = `Added ${quantity} ${unit} of "${name}" to your CymbalMart shopping list!`;
      setLastActionFeedback(response);
      speakFeedback(response);
      addHistory(raw, response, "success");
      return;
    }

    // 7. UPDATE BUDGET: e.g. "Set budget to 400"
    const budgetMatch = lower.match(/(?:budget|limit)\s+(?:to|is)\s+\$?(\d+)/i);
    if (budgetMatch) {
      const amount = parseInt(budgetMatch[1], 10);
      if (amount > 0) {
        onUpdateBudget(amount);
        const response = `Updated party budget limit to $${amount}!`;
        setLastActionFeedback(response);
        speakFeedback(response);
        addHistory(raw, response, "success");
        return;
      }
    }

    // 8. GENERAL AI ASSISTANT QUERY
    if (onOpenAgentChatWithMessage) {
      const response = `Consulting CymbalMart AI Assistant: "${raw}"`;
      setLastActionFeedback(response);
      speakFeedback(`Let me find the best answer for that.`);
      addHistory(raw, "Sent to CymbalMart Assistant", "info");
      onOpenAgentChatWithMessage(raw);
      onClose();
      return;
    }

    // Fallback unrecognized
    const response = `Recognized: "${raw}". Try saying "Add 2 boxes of sparkling water", "Show countdown", "Share memories", or "Scratch gift".`;
    setLastActionFeedback(response);
    speakFeedback("I didn't quite catch that action. Try asking to add an item, show countdown, or claim gifts.");
    addHistory(raw, response, "info");
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!textInput.trim()) return;
    handleProcessCommand(textInput);
    setTextInput("");
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-stone-900 border border-stone-800 rounded-3xl max-w-xl w-full p-6 shadow-2xl space-y-6 relative overflow-hidden">
        {/* Glowing Ambient Background */}
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-64 h-64 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-center justify-between relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-stone-950 shadow-lg shadow-amber-500/20">
              <Radio className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-stone-100 font-display flex items-center gap-2">
                Hands-Free Voice Control
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Live AI
                </span>
              </h2>
              <p className="text-xs text-stone-400">
                Complete your entire CymbalMart party shopping workflow hands-free.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setTtsEnabled(!ttsEnabled)}
              className={`p-2.5 rounded-xl border transition-colors ${
                ttsEnabled
                  ? "bg-amber-500/15 border-amber-500/40 text-amber-300"
                  : "bg-stone-800 border-stone-700 text-stone-400"
              }`}
              title={ttsEnabled ? "Voice Feedback Enabled (TTS)" : "Voice Feedback Muted"}
            >
              {ttsEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 border border-stone-700 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Voice Pulse / Visualizer */}
        <div className="relative z-10 flex flex-col items-center justify-center py-6 bg-stone-950/60 border border-stone-800/80 rounded-2xl p-6 text-center space-y-4">
          <button
            type="button"
            onClick={toggleListening}
            className={`w-24 h-24 rounded-full flex items-center justify-center transition-all transform active:scale-95 shadow-xl relative ${
              isListening
                ? "bg-gradient-to-tr from-amber-500 to-rose-500 text-stone-950 ring-8 ring-amber-500/25 scale-105"
                : "bg-stone-800 hover:bg-stone-700 text-amber-400 border border-stone-700"
            }`}
            id="voice-mic-main-button"
          >
            {isListening ? (
              <Mic className="w-10 h-10 animate-bounce" />
            ) : (
              <MicOff className="w-10 h-10 text-stone-400" />
            )}
            {isListening && (
              <span className="absolute inset-0 rounded-full animate-ping bg-amber-400/20 pointer-events-none" />
            )}
          </button>

          <div>
            <div className="text-sm font-semibold text-stone-200">
              {isListening ? "Listening... Speak your command now" : "Microphone Paused — Click to Listen"}
            </div>
            <p className="text-xs text-stone-400 mt-1 max-w-sm">
              Say commands like <strong className="text-amber-300">"Add 3 bags of ice"</strong>,{" "}
              <strong className="text-amber-300">"Show countdown"</strong>,{" "}
              <strong className="text-amber-300">"Share memories"</strong>, or{" "}
              <strong className="text-amber-300">"Claim gift voucher"</strong>.
            </p>
          </div>

          {/* Live Transcript / Feedback Banner */}
          {(transcript || lastActionFeedback) && (
            <div className="w-full bg-stone-900/90 border border-amber-500/30 rounded-xl p-3 text-left animate-fadeIn">
              {transcript && (
                <div className="text-xs text-stone-400 mb-1 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>Hearing:</span>
                  <span className="text-stone-200 font-medium italic">"{transcript}"</span>
                </div>
              )}
              {lastActionFeedback && (
                <div className="text-xs text-amber-300 font-semibold flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                  <span>{lastActionFeedback}</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Quick Voice Command Chips */}
        <div className="space-y-2 relative z-10">
          <div className="text-xs font-semibold text-stone-400 uppercase tracking-wider flex items-center gap-1.5">
            <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
            <span>Try Quick Voice Commands</span>
          </div>

          <div className="flex flex-wrap gap-2">
            {[
              { label: "➕ Add 2 bags of chips", text: "Add 2 bags of chips" },
              { label: "⏰ Show countdown", text: "Show countdown" },
              { label: "📸 Share memories via QR", text: "Share memories" },
              { label: "🎁 Scratch gift & discounts", text: "Claim reward" },
              { label: "💰 View store optimizer", text: "Show budget" },
              { label: "🧊 Add 30 lbs of ice", text: "Add 30 lbs of ice" },
            ].map((chip, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setTranscript(chip.text);
                  handleProcessCommand(chip.text);
                }}
                className="text-xs px-3 py-1.5 rounded-lg bg-stone-800/80 hover:bg-stone-700 text-stone-300 hover:text-amber-300 border border-stone-700/80 transition-colors flex items-center gap-1"
              >
                {chip.label}
              </button>
            ))}
          </div>
        </div>

        {/* Manual Text Command Fallback */}
        <form onSubmit={handleManualSubmit} className="relative z-10 flex gap-2">
          <input
            type="text"
            value={textInput}
            onChange={(e) => setTextInput(e.target.value)}
            placeholder="Or type a voice command (e.g., 'Add 2 packs of buns')..."
            className="flex-1 bg-stone-950 border border-stone-800 rounded-xl px-4 py-2.5 text-sm text-stone-100 placeholder-stone-500 focus:outline-none focus:border-amber-500 transition-colors"
          />
          <button
            type="submit"
            className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-sm transition-colors flex items-center gap-1.5"
          >
            <Send className="w-4 h-4" />
            <span>Send</span>
          </button>
        </form>

        {/* Command Execution Log */}
        {commandHistory.length > 0 && (
          <div className="relative z-10 bg-stone-950/60 border border-stone-800 rounded-xl p-3 max-h-32 overflow-y-auto space-y-1.5 text-xs text-stone-400">
            <div className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
              Recent Voice Actions
            </div>
            {commandHistory.map((h, i) => (
              <div key={i} className="flex items-center justify-between text-stone-300">
                <span className="truncate">"{h.text}" → <strong className="text-amber-300 font-normal">{h.response}</strong></span>
                <span className="text-[10px] text-stone-500 ml-2">{h.time}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
