import React from "react";
import {
  Utensils,
  Wine,
  Snowflake,
  Coffee,
  Sparkles,
  Layers,
  ChevronDown,
  ChevronUp,
  Info,
  HelpCircle,
} from "lucide-react";
import { PortionsBreakdown, PartyPlan } from "../types";

interface PortionEstimatorCardProps {
  plan: PartyPlan;
  onUpdateGuests: (adults: number, kids: number, duration: number) => void;
}

export const PortionEstimatorCard: React.FC<PortionEstimatorCardProps> = ({
  plan,
  onUpdateGuests,
}) => {
  const [isExpanded, setIsExpanded] = React.useState(true);
  const pb = plan.portionsBreakdown;
  const totalGuests = plan.guestCount.total;

  return (
    <div className="bg-stone-900 border border-stone-800 rounded-2xl p-5 shadow-lg relative overflow-hidden">
      {/* Top Banner */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Utensils className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-stone-100 font-display">
                Portion & Quantity Engine
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 font-medium">
                AI Precision Sized
              </span>
            </div>
            <p className="text-xs text-stone-400">
              Catering math tailored for {totalGuests} guests over {plan.durationHours} hours
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="p-1.5 rounded-lg text-stone-400 hover:text-stone-200 hover:bg-stone-800 transition-colors"
          title="Toggle Portion Details"
        >
          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
      </div>

      {isExpanded && (
        <div className="mt-5 space-y-4">
          {/* 5 Core Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {/* Appetizers */}
            <div className="bg-stone-950/60 border border-stone-800/80 rounded-xl p-3">
              <div className="flex items-center justify-between text-stone-400 text-xs mb-1">
                <span className="flex items-center gap-1 font-medium">
                  <Utensils className="w-3.5 h-3.5 text-amber-400" />
                  Appetizers
                </span>
                <span className="text-[10px] text-stone-400">
                  ~{pb.appetizersPerPerson}/person
                </span>
              </div>
              <div className="text-xl font-bold text-stone-100 font-display">
                {pb.appetizersTotalPieces}{" "}
                <span className="text-xs font-normal text-stone-400">bites</span>
              </div>
              <div className="text-[10px] text-stone-400 mt-1">
                Finger foods, dips & skewers
              </div>
            </div>

            {/* Alcoholic Drinks */}
            <div className="bg-stone-950/60 border border-stone-800/80 rounded-xl p-3">
              <div className="flex items-center justify-between text-stone-400 text-xs mb-1">
                <span className="flex items-center gap-1 font-medium">
                  <Wine className="w-3.5 h-3.5 text-purple-400" />
                  Alcohol Bar
                </span>
                <span className="text-[10px] text-stone-400">
                  ~1.2/hr/adult
                </span>
              </div>
              <div className="text-xl font-bold text-stone-100 font-display">
                {pb.alcoholicDrinksCount}{" "}
                <span className="text-xs font-normal text-stone-400">servings</span>
              </div>
              <div className="text-[10px] text-stone-400 mt-1">
                Beer, wine & cocktail mix
              </div>
            </div>

            {/* Soft Drinks / Mocktails */}
            <div className="bg-stone-950/60 border border-stone-800/80 rounded-xl p-3">
              <div className="flex items-center justify-between text-stone-400 text-xs mb-1">
                <span className="flex items-center gap-1 font-medium">
                  <Coffee className="w-3.5 h-3.5 text-cyan-400" />
                  Soft Drinks
                </span>
                <span className="text-[10px] text-stone-400">
                  Water & Sodas
                </span>
              </div>
              <div className="text-xl font-bold text-stone-100 font-display">
                {pb.nonAlcoholicDrinksCount}{" "}
                <span className="text-xs font-normal text-stone-400">cans/cups</span>
              </div>
              <div className="text-[10px] text-stone-400 mt-1">
                Sparkling, juice & mixers
              </div>
            </div>

            {/* Party Ice Bags */}
            <div className="bg-stone-950/60 border border-stone-800/80 rounded-xl p-3">
              <div className="flex items-center justify-between text-stone-400 text-xs mb-1">
                <span className="flex items-center gap-1 font-medium">
                  <Snowflake className="w-3.5 h-3.5 text-sky-400" />
                  Party Ice
                </span>
                <span className="text-[10px] text-stone-400">
                  1.2 lbs/guest
                </span>
              </div>
              <div className="text-xl font-bold text-stone-100 font-display">
                {pb.iceLbsNeeded}{" "}
                <span className="text-xs font-normal text-stone-400">lbs</span>
                <span className="text-xs font-normal text-stone-400 ml-1">
                  ({Math.ceil(pb.iceLbsNeeded / 10)} bags)
                </span>
              </div>
              <div className="text-[10px] text-stone-400 mt-1">
                For drink buckets + cups
              </div>
            </div>

            {/* Tableware & Buffer */}
            <div className="bg-stone-950/60 border border-stone-800/80 rounded-xl p-3 col-span-2 sm:col-span-1">
              <div className="flex items-center justify-between text-stone-400 text-xs mb-1">
                <span className="flex items-center gap-1 font-medium">
                  <Layers className="w-3.5 h-3.5 text-blue-400" />
                  Tableware
                </span>
                <span className="text-[10px] text-stone-400">+50% buffer</span>
              </div>
              <div className="text-xl font-bold text-stone-100 font-display">
                {pb.cupsPlatesNapkinsCount}{" "}
                <span className="text-xs font-normal text-stone-400">sets</span>
              </div>
              <div className="text-[10px] text-stone-400 mt-1">
                Plates, cups, cutlery
              </div>
            </div>
          </div>

          {/* AI Explanation Pill */}
          <div className="bg-stone-950/40 border border-stone-800/60 rounded-xl p-3 text-xs text-stone-300 flex items-start gap-2.5">
            <Info className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <span className="font-semibold text-stone-200">Formula Rule: </span>
              {pb.calculationExplanation ||
                `Calculated specifically for ${totalGuests} guests over ${plan.durationHours} hours to avoid underbuying or wasteful surplus.`}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
