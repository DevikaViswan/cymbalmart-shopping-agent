import React, { useState } from "react";
import {
  X,
  Sparkles,
  Users,
  Clock,
  DollarSign,
  MapPin,
  UtensilsCrossed,
  Layers,
  Wand2,
  Check,
  AlertCircle,
  HelpCircle,
} from "lucide-react";
import { PartyPlan, EventType, PartyVibe, VenueType } from "../types";
import { DIETARY_OPTIONS } from "../utils/categoryHelpers";
import { PRESET_PARTY_PLANS } from "../data/presets";

interface PartySetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPlanGenerated: (plan: PartyPlan) => void;
  initialPlan?: PartyPlan;
}

const EVENT_TYPE_SUGGESTIONS: EventType[] = [
  "Birthday Party",
  "BBQ & Cookout",
  "Cocktail & Mixer",
  "Dinner Party",
  "Kids Birthday",
  "Game Night & Snacks",
  "Taco & Margarita Fiesta",
  "Brunch & Mimosas",
  "Holiday / Seasonal",
  "Casual Hangout",
];

const VIBE_OPTIONS: { id: PartyVibe; label: string; desc: string }[] = [
  { id: "casual", label: "Casual & Relaxed", desc: "Easy grazing, self-serve drinks & comfort foods" },
  { id: "festive", label: "Lively & Festive", desc: "Upbeat energy, cocktail bar & crowd pleasers" },
  { id: "chic-upscale", label: "Chic & Gourmet", desc: "Artisanal cheeses, fine wines & styled platters" },
  { id: "family-friendly", label: "Family & Kids Friendly", desc: "Kid-friendly portions, juice boxes & fun snacks" },
  { id: "budget-saver", label: "Maximum Budget Saver", desc: "High-value bulk buying & smart low-cost recipes" },
  { id: "themed-immersive", label: "Themed & Immersive", desc: "Decor-heavy, custom punch & themed treats" },
];

const VENUE_OPTIONS: { id: VenueType; label: string }[] = [
  { id: "indoor-home", label: "Indoor Living / Kitchen" },
  { id: "backyard", label: "Backyard / Patio / Grill" },
  { id: "park-outdoor", label: "Public Park / Pavilion" },
  { id: "rented-venue", label: "Rented Hall / Studio" },
  { id: "rooftop", label: "Rooftop / Balcony" },
  { id: "beach", label: "Beach / Lakefront" },
];

export const PartySetupModal: React.FC<PartySetupModalProps> = ({
  isOpen,
  onClose,
  onPlanGenerated,
  initialPlan,
}) => {
  const [name, setName] = useState(initialPlan?.name || "Saturday Night Gathering");
  const [eventType, setEventType] = useState<string>(initialPlan?.eventType || "Cocktail & Mixer");
  const [theme, setTheme] = useState(initialPlan?.theme || "Craft Cocktails & Gourmet Tapas");
  const [vibe, setVibe] = useState<PartyVibe>(initialPlan?.vibe || "festive");
  const [adults, setAdults] = useState<number>(initialPlan?.guestCount.adults || 12);
  const [kids, setKids] = useState<number>(initialPlan?.guestCount.kids || 0);
  const [durationHours, setDurationHours] = useState<number>(initialPlan?.durationHours || 3);
  const [budgetLimit, setBudgetLimit] = useState<number>(initialPlan?.budgetLimit || 250);
  const [venueType, setVenueType] = useState<VenueType>(initialPlan?.venueType || "indoor-home");
  const [dietaryRestrictions, setDietaryRestrictions] = useState<string[]>(
    initialPlan?.dietaryRestrictions || ["Vegetarian Option"]
  );
  const [customNotes, setCustomNotes] = useState<string>(
    initialPlan?.customNotes || ""
  );
  const [servingStyle, setServingStyle] = useState<string>("buffet");
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const toggleDietary = (item: string) => {
    if (dietaryRestrictions.includes(item)) {
      setDietaryRestrictions(dietaryRestrictions.filter((d) => d !== item));
    } else {
      setDietaryRestrictions([...dietaryRestrictions, item]);
    }
  };

  const handleApplyPreset = (preset: PartyPlan) => {
    setName(preset.name);
    setEventType(preset.eventType);
    setTheme(preset.theme);
    setVibe(preset.vibe);
    setAdults(preset.guestCount.adults);
    setKids(preset.guestCount.kids);
    setDurationHours(preset.durationHours);
    setBudgetLimit(preset.budgetLimit);
    setVenueType(preset.venueType);
    setDietaryRestrictions(preset.dietaryRestrictions);
    setCustomNotes(preset.customNotes || "");
  };

  const handleGeneratePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsGenerating(true);
    setErrorMsg(null);

    try {
      const payload = {
        name,
        eventType,
        theme,
        vibe,
        adults: Number(adults),
        kids: Number(kids),
        durationHours: Number(durationHours),
        budgetLimit: Number(budgetLimit),
        venueType,
        dietaryRestrictions,
        customNotes,
        servingStyle,
      };

      const response = await fetch("/api/agent/generate-plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const generatedData: PartyPlan = await response.json();
      // ensure unique id and timestamp
      generatedData.id = initialPlan?.id || `plan-${Date.now()}`;
      generatedData.createdAt = new Date().toISOString();

      onPlanGenerated(generatedData);
      onClose();
    } catch (err: any) {
      console.error("Failed to generate party plan:", err);
      setErrorMsg("Failed to generate with AI. Trying fallback generator...");
      // Auto-fallback handled on server or can apply preset
      const fallback = PRESET_PARTY_PLANS[0];
      onPlanGenerated({
        ...fallback,
        id: `plan-${Date.now()}`,
        name,
        theme,
        guestCount: { adults, kids, total: adults + kids },
        budgetLimit,
      });
      onClose();
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="relative w-full max-w-3xl rounded-2xl bg-stone-900 border border-stone-800 shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-5 border-b border-stone-800 flex items-center justify-between bg-stone-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Wand2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-stone-100 font-display">
                {initialPlan ? "Configure Party Logistics" : "Plan Your Party & Shopping List"}
              </h2>
              <p className="text-xs text-stone-400">
                Let the CymbalMart Shopping Agent calculate exact food, drink & tableware portions.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-100 hover:bg-stone-800 transition-colors"
            id="modal-close-btn"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Presets Carousel */}
        <div className="bg-stone-950/60 px-6 py-3 border-b border-stone-800/80">
          <div className="text-xs font-semibold text-stone-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Quick Start Templates</span>
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            {PRESET_PARTY_PLANS.map((preset) => (
              <button
                key={preset.id}
                type="button"
                onClick={() => handleApplyPreset(preset)}
                className="flex-shrink-0 px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700/80 border border-stone-700 text-xs text-stone-300 hover:text-amber-300 transition-all flex items-center gap-2"
              >
                <span>{preset.name}</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-stone-900 text-stone-400">
                  {preset.guestCount.total} guests • ${preset.budgetLimit}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleGeneratePlan} className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Party Name & Event Type */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-stone-300 mb-1.5">
                Party / Celebration Name
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Maya's 30th Birthday Fiesta"
                className="w-full px-3.5 py-2.5 rounded-xl bg-stone-800 border border-stone-700 text-stone-100 placeholder-stone-500 focus:outline-none focus:border-amber-500 text-sm"
                id="input-party-name"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-300 mb-1.5">
                Event Type
              </label>
              <select
                value={eventType}
                onChange={(e) => setEventType(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-stone-800 border border-stone-700 text-stone-100 focus:outline-none focus:border-amber-500 text-sm"
                id="select-event-type"
              >
                {EVENT_TYPE_SUGGESTIONS.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Theme & Atmosphere */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-stone-300 mb-1.5">
                Theme / Cuisine Focus
              </label>
              <input
                type="text"
                value={theme}
                onChange={(e) => setTheme(e.target.value)}
                placeholder="e.g. Rustic Italian Pasta Bar, Neon 80s Disco, Taco Tuesday"
                className="w-full px-3.5 py-2.5 rounded-xl bg-stone-800 border border-stone-700 text-stone-100 placeholder-stone-500 focus:outline-none focus:border-amber-500 text-sm"
                id="input-party-theme"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-300 mb-1.5">
                Venue & Location
              </label>
              <select
                value={venueType}
                onChange={(e) => setVenueType(e.target.value as VenueType)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-stone-800 border border-stone-700 text-stone-100 focus:outline-none focus:border-amber-500 text-sm"
                id="select-venue-type"
              >
                {VENUE_OPTIONS.map((venue) => (
                  <option key={venue.id} value={venue.id}>
                    {venue.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Numbers: Adults, Kids, Duration, Budget */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-stone-950/40 p-4 rounded-xl border border-stone-800/80">
            <div>
              <label className="block text-[11px] font-medium text-stone-400 mb-1 flex items-center gap-1">
                <Users className="w-3 h-3 text-amber-400" />
                Adults
              </label>
              <input
                type="number"
                min="1"
                max="300"
                value={adults}
                onChange={(e) => setAdults(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full px-3 py-2 rounded-lg bg-stone-800 border border-stone-700 text-stone-100 font-bold text-center text-sm"
                id="input-adults-count"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-stone-400 mb-1 flex items-center gap-1">
                <Users className="w-3 h-3 text-cyan-400" />
                Kids
              </label>
              <input
                type="number"
                min="0"
                max="200"
                value={kids}
                onChange={(e) => setKids(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full px-3 py-2 rounded-lg bg-stone-800 border border-stone-700 text-stone-100 font-bold text-center text-sm"
                id="input-kids-count"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-stone-400 mb-1 flex items-center gap-1">
                <Clock className="w-3 h-3 text-purple-400" />
                Duration (hrs)
              </label>
              <input
                type="number"
                min="1"
                max="12"
                step="0.5"
                value={durationHours}
                onChange={(e) => setDurationHours(Math.max(1, parseFloat(e.target.value) || 1))}
                className="w-full px-3 py-2 rounded-lg bg-stone-800 border border-stone-700 text-stone-100 font-bold text-center text-sm"
                id="input-duration-hours"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-stone-400 mb-1 flex items-center gap-1">
                <DollarSign className="w-3 h-3 text-emerald-400" />
                Budget Cap ($)
              </label>
              <input
                type="number"
                min="20"
                max="10000"
                step="10"
                value={budgetLimit}
                onChange={(e) => setBudgetLimit(Math.max(20, parseInt(e.target.value) || 100))}
                className="w-full px-3 py-2 rounded-lg bg-stone-800 border border-stone-700 text-stone-100 font-bold text-center text-sm"
                id="input-budget-limit"
              />
            </div>
          </div>

          {/* Vibe Selection */}
          <div>
            <label className="block text-xs font-medium text-stone-300 mb-2">
              Atmosphere & Host Vibe
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {VIBE_OPTIONS.map((v) => (
                <button
                  type="button"
                  key={v.id}
                  onClick={() => setVibe(v.id)}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    vibe === v.id
                      ? "bg-amber-500/15 border-amber-500/50 text-stone-100 shadow-sm"
                      : "bg-stone-800/60 border-stone-700/60 text-stone-400 hover:text-stone-200 hover:bg-stone-800"
                  }`}
                >
                  <div className="text-xs font-semibold flex items-center justify-between">
                    <span>{v.label}</span>
                    {vibe === v.id && <Check className="w-3.5 h-3.5 text-amber-400" />}
                  </div>
                  <div className="text-[11px] text-stone-400 mt-1 line-clamp-2 leading-relaxed">
                    {v.desc}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Dietary Restrictions */}
          <div>
            <label className="block text-xs font-medium text-stone-300 mb-2">
              Dietary Restrictions & Allergies
            </label>
            <div className="flex flex-wrap gap-1.5">
              {DIETARY_OPTIONS.map((tag) => {
                const isSelected = dietaryRestrictions.includes(tag);
                return (
                  <button
                    type="button"
                    key={tag}
                    onClick={() => toggleDietary(tag)}
                    className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                      isSelected
                        ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                        : "bg-stone-800 text-stone-400 border border-stone-700/60 hover:text-stone-200"
                    }`}
                  >
                    {isSelected ? "✓ " : "+ "}
                    {tag}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Custom Notes */}
          <div>
            <label className="block text-xs font-medium text-stone-300 mb-1.5">
              Special Instructions or Must-Have Dishes
            </label>
            <textarea
              rows={2}
              value={customNotes}
              onChange={(e) => setCustomNotes(e.target.value)}
              placeholder="e.g. Include a signature sparkling mocktail, need extra ice bags for cooler, guest of honor loves key lime pie..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-stone-800 border border-stone-700 text-stone-100 placeholder-stone-500 focus:outline-none focus:border-amber-500 text-xs leading-relaxed"
              id="textarea-custom-notes"
            />
          </div>

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isGenerating}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-stone-950 font-bold text-sm flex items-center justify-center gap-2 shadow-xl shadow-amber-500/25 transition-all disabled:opacity-50"
              id="btn-generate-party-plan"
            >
              {isGenerating ? (
                <>
                  <div className="w-4 h-4 border-2 border-stone-950 border-t-transparent rounded-full animate-spin" />
                  <span>Agent Calculating Portions & Shopping List...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Generate Full Shopping Plan with AI</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
